from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import PurePosixPath
from typing import Any, Iterable, Mapping, Sequence

from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.expression_utils import matching_pairs, significant_tokens, split_top_level, tokens_to_compact_text
from core.source_context import ClassInfo, FunctionInfo, ProjectContext, SourceFileContext
from core.tokenizer import Token, TokenKind

from .rules import (
    BUILTIN_ALLOCATORS,
    BUILTIN_RELEASES,
    DELETE_ARRAY_KIND,
    DELETE_KIND,
    NEW_ARRAY_KIND,
    NEW_KIND,
    CustomMemoryAPI,
    expected_release,
    parse_custom_apis,
)


_CPP_EXTENSIONS = {".c", ".cc", ".cpp", ".cxx"}
_EXIT_KEYWORDS = {"return", "throw"}
_NULL_VALUES = {"nullptr", "NULL"}


@dataclass(frozen=True, slots=True)
class Target:
    text: str
    base: str
    family: bool
    explicit_this: bool = False


@dataclass(frozen=True, slots=True)
class AllocationSite:
    key: str
    target: Target
    kind: str
    expected_release: str
    line: int
    column: int
    file: str
    owner_scope: str  # local | class
    owner_name: str
    in_loop: bool = False


@dataclass(frozen=True, slots=True)
class MemoryEvent:
    kind: str  # alloc | release | alias | clear
    line: int
    column: int
    target: Target | None = None
    allocation_kind: str | None = None
    release_kind: str | None = None
    source_target: Target | None = None
    in_loop: bool = False


@dataclass(slots=True)
class FlowState:
    bindings: dict[str, frozenset[str]] = field(default_factory=dict)
    active: frozenset[str] = frozenset()
    freed: frozenset[str] = frozenset()

    def clone(self) -> "FlowState":
        return FlowState(dict(self.bindings), frozenset(self.active), frozenset(self.freed))

    def signature(self) -> tuple:
        return (
            tuple(sorted((name, tuple(sorted(ids))) for name, ids in self.bindings.items())),
            tuple(sorted(self.active)),
            tuple(sorted(self.freed)),
        )


class Statement:
    pass


@dataclass(slots=True)
class Block(Statement):
    statements: list[Statement]


@dataclass(slots=True)
class Simple(Statement):
    tokens: list[Token]


@dataclass(slots=True)
class Exit(Statement):
    tokens: list[Token]
    line: int


@dataclass(slots=True)
class IfStatement(Statement):
    then_branch: Statement
    else_branch: Statement | None


@dataclass(slots=True)
class LoopStatement(Statement):
    kind: str
    body: Statement


@dataclass(slots=True)
class UnknownControl(Statement):
    body: Statement | None


@dataclass(slots=True)
class FunctionOwnership:
    function: FunctionInfo
    source: SourceFileContext
    local_names: set[str]
    parameter_names: set[str]
    field_names: set[str]

    def classify(self, target: Target) -> str:
        if target.explicit_this and target.base in self.field_names:
            return "class"
        if target.base in self.local_names:
            return "local"
        if target.base in self.parameter_names:
            return "borrowed"
        if target.base in self.field_names:
            return "class"
        return "unknown"


class _StatementParser:
    def __init__(self, tokens: Sequence[Token]) -> None:
        self.tokens = list(tokens)
        self.parens = matching_pairs(self.tokens, "(", ")")
        self.braces = matching_pairs(self.tokens, "{", "}")

    def parse(self) -> Block:
        statements, _ = self._sequence(0, len(self.tokens))
        return Block(statements)

    def _sequence(self, start: int, end: int) -> tuple[list[Statement], int]:
        out: list[Statement] = []
        i = start
        while i < end:
            if self.tokens[i].value == "}":
                break
            stmt, next_i = self._one(i, end)
            if stmt is not None:
                out.append(stmt)
            i = max(next_i, i + 1)
        return out, i

    def _one(self, i: int, end: int) -> tuple[Statement | None, int]:
        token = self.tokens[i]
        value = token.value

        if value == "{":
            close = self.braces.get(i)
            if close is None or close >= end:
                return Simple(self.tokens[i:end]), end
            children, _ = self._sequence(i + 1, close)
            return Block(children), close + 1

        if value == "if":
            open_paren = self._next_value(i + 1, end, "(")
            if open_paren is None:
                return self._simple(i, end)
            close_paren = self.parens.get(open_paren)
            if close_paren is None:
                return self._simple(i, end)
            then_stmt, next_i = self._one(close_paren + 1, end)
            else_stmt = None
            if next_i < end and self.tokens[next_i].value == "else":
                else_stmt, next_i = self._one(next_i + 1, end)
            if then_stmt is None:
                then_stmt = Block([])
            return IfStatement(then_stmt, else_stmt), next_i

        if value in {"for", "while"}:
            open_paren = self._next_value(i + 1, end, "(")
            if open_paren is None:
                return self._simple(i, end)
            close_paren = self.parens.get(open_paren)
            if close_paren is None:
                return self._simple(i, end)
            body, next_i = self._one(close_paren + 1, end)
            return LoopStatement(value, body or Block([])), next_i

        if value == "do":
            body, next_i = self._one(i + 1, end)
            if next_i < end and self.tokens[next_i].value == "while":
                open_paren = self._next_value(next_i + 1, end, "(")
                if open_paren is not None and open_paren in self.parens:
                    next_i = self.parens[open_paren] + 1
                    if next_i < end and self.tokens[next_i].value == ";":
                        next_i += 1
            return LoopStatement("do", body or Block([])), next_i

        if value in {"switch", "try", "catch"}:
            cursor = i + 1
            if value in {"switch", "catch"}:
                open_paren = self._next_value(cursor, end, "(")
                if open_paren is not None and open_paren in self.parens:
                    cursor = self.parens[open_paren] + 1
            body, next_i = self._one(cursor, end)
            return UnknownControl(body), next_i

        if value in _EXIT_KEYWORDS:
            tokens, next_i = self._through_semicolon(i, end)
            return Exit(tokens, token.line), next_i

        if value in {"case", "default"}:
            colon = self._next_value(i + 1, end, ":")
            return (None, colon + 1) if colon is not None else (None, i + 1)

        return self._simple(i, end)

    def _simple(self, i: int, end: int) -> tuple[Statement | None, int]:
        tokens, next_i = self._through_semicolon(i, end)
        if not tokens:
            return None, next_i
        return Simple(tokens), next_i

    def _through_semicolon(self, i: int, end: int) -> tuple[list[Token], int]:
        round_depth = square_depth = 0
        j = i
        while j < end:
            v = self.tokens[j].value
            if v == "(":
                round_depth += 1
            elif v == ")" and round_depth:
                round_depth -= 1
            elif v == "[":
                square_depth += 1
            elif v == "]" and square_depth:
                square_depth -= 1
            elif v == ";" and round_depth == square_depth == 0:
                return self.tokens[i:j], j + 1
            elif v == "{" and round_depth == square_depth == 0:
                # Unknown statement followed by a block. Preserve prefix as a simple
                # statement and let the next iteration parse the block.
                return self.tokens[i:j], j
            elif v == "}" and round_depth == square_depth == 0:
                return self.tokens[i:j], j
            j += 1
        return self.tokens[i:end], end

    def _next_value(self, start: int, end: int, value: str) -> int | None:
        for i in range(start, end):
            if self.tokens[i].value == value:
                return i
            if self.tokens[i].value in {";", "{"}:
                return None
        return None


class MemoryAnalyzer:
    def __init__(self, config: Mapping[str, Any]) -> None:
        self.config = config
        self.custom_apis = parse_custom_apis(config)
        self.custom_allocators = {api.allocator: api for api in self.custom_apis}
        self.custom_deallocators = {api.deallocator: api for api in self.custom_apis}
        self.findings: list[Finding] = []
        self.sites: dict[str, AllocationSite] = {}
        self.class_allocations: dict[tuple[str, str], list[AllocationSite]] = {}
        self.class_releases: dict[tuple[str, str], list[MemoryEvent]] = {}
        self._reported: set[tuple[str, str, int, str]] = set()
        self.max_states = max(4, int(config.get("max_path_states", 64)))

    def analyze(self, context: ProjectContext) -> list[Finding]:
        targets, resolution_finding = self._resolve_target_sources(context)
        if resolution_finding is not None:
            return [resolution_finding]

        classes_by_name = self._classes_by_name(context)
        target_paths = {source.relative_path for source in targets}
        functions = [
            fn for fn in context.function_definitions
            if fn.file in target_paths
        ]

        for fn in functions:
            source = context.source_file(fn.file)
            if source is None or fn.body_start_token < 0 or fn.body_end_token < 0:
                continue
            cls = classes_by_name.get(fn.owner_class) if fn.owner_class else None
            ownership = self._ownership_for(fn, source, cls)
            self._analyze_function(ownership)

        self._finalize_class_ownership()
        return self.findings

    def _resolve_target_sources(
        self, context: ProjectContext
    ) -> tuple[list[SourceFileContext], Finding | None]:
        cpp_files = [f for f in context.files if f.path.suffix.lower() in _CPP_EXTENSIONS]
        requested = self.config.get("target_cpp")

        if requested:
            raw_items = requested if isinstance(requested, list) else [requested]
            selected: list[SourceFileContext] = []
            unresolved: list[str] = []
            for raw in raw_items:
                text = str(raw).replace("\\", "/").strip()
                if not text:
                    continue
                text_lower = text.lower()
                matches = [
                    f for f in cpp_files
                    if f.relative_path.lower() == text_lower
                    or PurePosixPath(f.relative_path).name.lower() == text_lower
                    or PurePosixPath(f.relative_path).stem.lower() == text_lower
                ]
                if len(matches) == 1:
                    if matches[0] not in selected:
                        selected.append(matches[0])
                else:
                    unresolved.append(text)
            if selected and not unresolved:
                return selected, None
            detail = "Could not uniquely resolve target_cpp: " + ", ".join(unresolved or map(str, raw_items))
            return [], self._configuration_finding(context, detail)

        if len(cpp_files) == 1:
            return cpp_files, None

        main_named = [f for f in cpp_files if PurePosixPath(f.relative_path).name.lower() == "main.cpp"]
        if len(main_named) == 1:
            return main_named, None

        main_defs = []
        for source in cpp_files:
            if any(fn.is_definition and fn.name == "main" for fn in source.functions):
                main_defs.append(source)
        if len(main_defs) == 1:
            return main_defs, None

        return [], self._configuration_finding(
            context,
            "Multiple implementation files are present and no unique target could be inferred. "
            "Set checks.memory.target_cpp to the .cpp path, filename, or unique stem.",
        )

    def _configuration_finding(self, context: ProjectContext, details: str) -> Finding:
        file = context.files[0].relative_path if context.files else "<project>"
        return Finding(
            checker="memory",
            rule="MEM000",
            severity=Severity.INFO,
            confidence=Confidence.CERTAIN,
            location=SourceLocation(file=file, line=1, column=1),
            message="Memory ownership analysis was skipped because the target implementation file is ambiguous.",
            details=details,
            suggestion='Set "checks.memory.target_cpp" in checker_config.json.',
            tags=["configuration", "memory"],
        )

    @staticmethod
    def _classes_by_name(context: ProjectContext) -> dict[str, ClassInfo]:
        result: dict[str, ClassInfo] = {}
        for cls in context.classes:
            result.setdefault(cls.name, cls)
        return result

    @staticmethod
    def _ownership_for(
        fn: FunctionInfo,
        source: SourceFileContext,
        cls: ClassInfo | None,
    ) -> FunctionOwnership:
        local_names = {
            v.name for v in fn.local_variables
            if v.category == "local"
        }
        parameter_names = {
            v.name for v in fn.local_variables
            if v.category == "parameter"
        }
        field_names = {v.name for v in cls.fields} if cls else set()
        return FunctionOwnership(fn, source, local_names, parameter_names, field_names)

    def _analyze_function(self, ownership: FunctionOwnership) -> None:
        fn = ownership.function
        source = ownership.source
        raw = source.tokens[fn.body_start_token + 1:fn.body_end_token]
        tokens = significant_tokens(raw)
        tree = _StatementParser(tokens).parse()

        initial = FlowState()
        if fn.is_constructor:
            initializer_events = self._events_from_constructor_initializer(ownership)
            for event in initializer_events:
                self._apply_event(initial, event, ownership)
        active_states, exits = self._eval_statement(tree, [initial], ownership, loop_depth=0)

        for state, exit_line in exits:
            self._report_live_locals(state, ownership, exit_line, "function exits here")
        for state in active_states:
            self._report_live_locals(state, ownership, fn.end_line, "function reaches its end")

    def _eval_statement(
        self,
        stmt: Statement,
        states: list[FlowState],
        ownership: FunctionOwnership,
        *,
        loop_depth: int,
    ) -> tuple[list[FlowState], list[tuple[FlowState, int]]]:
        if not states:
            return [], []

        if isinstance(stmt, Block):
            active = states
            exits: list[tuple[FlowState, int]] = []
            for child in stmt.statements:
                active, child_exits = self._eval_statement(
                    child, active, ownership, loop_depth=loop_depth
                )
                exits.extend(child_exits)
                if not active:
                    break
            return self._dedupe_states(active), exits

        if isinstance(stmt, Exit):
            return [], [(state.clone(), stmt.line) for state in states]

        if isinstance(stmt, Simple):
            result: list[FlowState] = []
            for state in states:
                updated = state.clone()
                events = self._events_from_simple(stmt.tokens, ownership, in_loop=loop_depth > 0)
                for event in events:
                    self._apply_event(updated, event, ownership)
                result.append(updated)
            return self._dedupe_states(result), []

        if isinstance(stmt, IfStatement):
            then_states, then_exits = self._eval_statement(
                stmt.then_branch,
                [state.clone() for state in states],
                ownership,
                loop_depth=loop_depth,
            )
            if stmt.else_branch is None:
                else_states = [state.clone() for state in states]
                else_exits: list[tuple[FlowState, int]] = []
            else:
                else_states, else_exits = self._eval_statement(
                    stmt.else_branch,
                    [state.clone() for state in states],
                    ownership,
                    loop_depth=loop_depth,
                )
            return self._dedupe_states(then_states + else_states), then_exits + else_exits

        if isinstance(stmt, LoopStatement):
            # Evaluate zero/one/two iterations. The second pass catches scalar
            # allocations overwritten by another iteration. Indexed families are
            # intentionally allowed to represent many elements from one site.
            zero = [state.clone() for state in states] if stmt.kind != "do" else []
            one, exits1 = self._eval_statement(
                stmt.body,
                [state.clone() for state in states],
                ownership,
                loop_depth=loop_depth + 1,
            )
            two, exits2 = self._eval_statement(
                stmt.body,
                [state.clone() for state in one],
                ownership,
                loop_depth=loop_depth + 1,
            ) if one else ([], [])

            combined = zero + one + two
            # If a loop contains release of an indexed family, treat it as the
            # cleanup loop for that family. This is specifically for the common
            # `for (...) delete[] a[i];` pattern after an allocation loop.
            release_targets = self._family_releases_in_statement(stmt.body, ownership)
            if release_targets:
                for state in combined:
                    for target, release_kind in release_targets:
                        self._apply_family_cleanup(state, target, release_kind, ownership)
            return self._dedupe_states(combined), exits1 + exits2

        if isinstance(stmt, UnknownControl):
            if stmt.body is None:
                return states, []
            body_states, body_exits = self._eval_statement(
                stmt.body,
                [state.clone() for state in states],
                ownership,
                loop_depth=loop_depth,
            )
            # Unknown control is conservatively optional so we do not claim a
            # release definitely happened merely because it exists syntactically.
            return self._dedupe_states(states + body_states), body_exits

        return states, []

    def _family_releases_in_statement(
        self, stmt: Statement, ownership: FunctionOwnership
    ) -> set[tuple[str, str]]:
        result: set[tuple[str, str]] = set()
        if isinstance(stmt, Simple):
            for event in self._events_from_simple(stmt.tokens, ownership, in_loop=True):
                if event.kind == "release" and event.target and event.target.family and event.release_kind:
                    result.add((event.target.text, event.release_kind))
        elif isinstance(stmt, Block):
            for child in stmt.statements:
                result.update(self._family_releases_in_statement(child, ownership))
        elif isinstance(stmt, IfStatement):
            # Conditional release is not considered a complete cleanup loop.
            return result
        elif isinstance(stmt, LoopStatement):
            result.update(self._family_releases_in_statement(stmt.body, ownership))
        elif isinstance(stmt, UnknownControl) and stmt.body is not None:
            return result
        return result

    def _apply_family_cleanup(
        self,
        state: FlowState,
        target_text: str,
        release_kind: str,
        ownership: FunctionOwnership,
    ) -> None:
        ids = set(state.bindings.get(target_text, frozenset()))
        for allocation_id in list(ids):
            site = self.sites.get(allocation_id)
            if site is None or not site.target.family or allocation_id not in state.active:
                continue
            if site.expected_release != release_kind:
                self._report_mismatch(site, release_kind, ownership.source.relative_path, site.line)
                continue
            state.active = frozenset(set(state.active) - {allocation_id})
            state.freed = frozenset(set(state.freed) | {allocation_id})

    def _events_from_constructor_initializer(
        self, ownership: FunctionOwnership
    ) -> list[MemoryEvent]:
        fn = ownership.function
        if fn.signature_end_token < 0 or fn.body_start_token <= fn.signature_end_token:
            return []
        suffix = significant_tokens(
            ownership.source.tokens[fn.signature_end_token + 1:fn.body_start_token]
        )
        colon = next((i for i, token in enumerate(suffix) if token.value == ":"), None)
        if colon is None:
            return []

        events: list[MemoryEvent] = []
        for group in split_top_level(suffix[colon + 1:], ","):
            if not group:
                continue
            field_index = next(
                (i for i, token in enumerate(group)
                 if token.kind == TokenKind.IDENTIFIER and token.value in ownership.field_names),
                None,
            )
            if field_index is None:
                continue
            target = self._target_from_tokens(group[field_index:field_index + 1], ownership)
            if target is None:
                continue

            expr: list[Token] = []
            if field_index + 1 < len(group) and group[field_index + 1].value in {"(", "{"}:
                opener = group[field_index + 1].value
                closer = ")" if opener == "(" else "}"
                pairs = matching_pairs(group, opener, closer)
                close = pairs.get(field_index + 1)
                if close is not None:
                    expr = list(group[field_index + 2:close])
            elif field_index + 1 < len(group) and group[field_index + 1].value == "=":
                expr = list(group[field_index + 2:])
            if not expr:
                continue

            alloc_kind = self._allocation_kind_from_rhs(expr)
            if alloc_kind is not None:
                events.append(
                    MemoryEvent(
                        "alloc",
                        expr[0].line,
                        expr[0].column,
                        target=target,
                        allocation_kind=alloc_kind,
                        in_loop=False,
                    )
                )
                continue
            custom_return = self._custom_return_allocator_from_rhs(expr)
            if custom_return is not None:
                api, call_token = custom_return
                events.append(
                    MemoryEvent(
                        "alloc", call_token.line, call_token.column,
                        target=target, allocation_kind=api.allocation_kind, in_loop=False,
                    )
                )
        return events

    def _events_from_simple(
        self,
        tokens: Sequence[Token],
        ownership: FunctionOwnership,
        *,
        in_loop: bool,
    ) -> list[MemoryEvent]:
        tokens = list(tokens)
        if not tokens:
            return []
        events: list[MemoryEvent] = []

        # delete / delete[] expressions.
        i = 0
        while i < len(tokens):
            if tokens[i].value != "delete":
                i += 1
                continue
            line, column = tokens[i].line, tokens[i].column
            j = i + 1
            release_kind = DELETE_KIND
            if j + 1 < len(tokens) and tokens[j].value == "[" and tokens[j + 1].value == "]":
                release_kind = DELETE_ARRAY_KIND
                j += 2
            target = self._target_from_tokens(tokens[j:], ownership)
            if target:
                events.append(MemoryEvent("release", line, column, target=target, release_kind=release_kind, in_loop=in_loop))
            break

        # Ordinary/custom function calls, including malloc/calloc/free and out-param APIs.
        for call_name, args, call_token in self._find_calls(tokens):
            short_name = call_name.split("::")[-1].split(".")[-1].split("->")[-1]
            if short_name in BUILTIN_RELEASES:
                if args:
                    target = self._target_from_tokens(args[0], ownership, strip_address=True)
                    if target:
                        events.append(
                            MemoryEvent(
                                "release", call_token.line, call_token.column,
                                target=target, release_kind=BUILTIN_RELEASES[short_name], in_loop=in_loop,
                            )
                        )
            api = self.custom_deallocators.get(call_name) or self.custom_deallocators.get(short_name)
            if api and api.deallocator_target_arg < len(args):
                target = self._target_from_tokens(args[api.deallocator_target_arg], ownership, strip_address=True)
                if target:
                    events.append(
                        MemoryEvent(
                            "release", call_token.line, call_token.column,
                            target=target, release_kind=api.release_kind, in_loop=in_loop,
                        )
                    )

            alloc_api = self.custom_allocators.get(call_name) or self.custom_allocators.get(short_name)
            if alloc_api and alloc_api.allocation_mode == "out_arg" and alloc_api.target_arg < len(args):
                target = self._target_from_tokens(args[alloc_api.target_arg], ownership, strip_address=True)
                if target:
                    events.append(
                        MemoryEvent(
                            "alloc", call_token.line, call_token.column,
                            target=target, allocation_kind=alloc_api.allocation_kind, in_loop=in_loop,
                        )
                    )

        # Assignments/declaration initializers. Split top-level comma declarations
        # so `T *a = malloc(...), *b = malloc(...);` can produce two ownership events.
        groups = split_top_level(tokens, ",") or [list(tokens)]
        for group in groups:
            eq = self._top_level_assignment(group)
            if eq is None:
                continue
            lhs, rhs = group[:eq], group[eq + 1:]
            target = self._target_from_tokens(lhs, ownership)
            if target is None:
                continue

            alloc_kind = self._allocation_kind_from_rhs(rhs)
            if alloc_kind is not None:
                events.append(
                    MemoryEvent(
                        "alloc",
                        rhs[0].line if rhs else target and group[0].line,
                        rhs[0].column if rhs else group[0].column,
                        target=target,
                        allocation_kind=alloc_kind,
                        in_loop=in_loop,
                    )
                )
                continue

            custom_return = self._custom_return_allocator_from_rhs(rhs)
            if custom_return is not None:
                api, call_token = custom_return
                events.append(
                    MemoryEvent(
                        "alloc", call_token.line, call_token.column,
                        target=target, allocation_kind=api.allocation_kind, in_loop=in_loop,
                    )
                )
                continue

            if self._rhs_is_null(rhs):
                events.append(
                    MemoryEvent("clear", group[eq].line, group[eq].column, target=target, in_loop=in_loop)
                )
                continue

            source_target = self._target_from_tokens(rhs, ownership)
            if source_target is not None and self._rhs_is_simple_target(rhs, source_target):
                events.append(
                    MemoryEvent(
                        "alias", group[eq].line, group[eq].column,
                        target=target, source_target=source_target, in_loop=in_loop,
                    )
                )

        return self._dedupe_events(events)

    def _allocation_kind_from_rhs(self, rhs: Sequence[Token]) -> str | None:
        # new / new[]: [] after the type means an array allocation. Parenthesized
        # constructor arguments do not count as array allocation.
        for i, token in enumerate(rhs):
            if token.value == "new":
                if any(t.value == "[" for t in rhs[i + 1:]):
                    return NEW_ARRAY_KIND
                return NEW_KIND

        for call_name, _args, _token in self._find_calls(rhs):
            short = call_name.split("::")[-1].split(".")[-1].split("->")[-1]
            if short in BUILTIN_ALLOCATORS:
                return BUILTIN_ALLOCATORS[short][0]
        return None

    def _custom_return_allocator_from_rhs(
        self, rhs: Sequence[Token]
    ) -> tuple[CustomMemoryAPI, Token] | None:
        for call_name, _args, token in self._find_calls(rhs):
            short = call_name.split("::")[-1].split(".")[-1].split("->")[-1]
            api = self.custom_allocators.get(call_name) or self.custom_allocators.get(short)
            if api and api.allocation_mode == "return":
                return api, token
        return None

    @staticmethod
    def _rhs_is_null(rhs: Sequence[Token]) -> bool:
        significant = [t.value for t in rhs if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}]
        if len(significant) == 1 and significant[0] in _NULL_VALUES:
            return True
        return len(significant) == 1 and significant[0] == "0"

    @staticmethod
    def _rhs_is_simple_target(rhs: Sequence[Token], target: Target) -> bool:
        text = tokens_to_compact_text(rhs).replace(" ", "")
        return text in {target.text.replace(" ", ""), f"&{target.text.replace(' ', '')}"}

    def _apply_event(
        self, state: FlowState, event: MemoryEvent, ownership: FunctionOwnership
    ) -> None:
        target = event.target
        if target is None:
            return
        category = ownership.classify(target)

        if event.kind == "alloc":
            if category not in {"local", "class"}:
                # Allocation into borrowed/unknown external state violates the
                # checker ownership model, but is intentionally ignored here to
                # avoid treating dependency state as owned by this target file.
                return
            allocation_kind = event.allocation_kind or "unknown"
            release = expected_release(allocation_kind, self.custom_apis)
            if release is None:
                return
            site_key = (
                f"{ownership.source.relative_path}:{ownership.function.qualified_name}:"
                f"{event.line}:{event.column}:{target.text}:{allocation_kind}"
            )
            site = self.sites.get(site_key)
            if site is None:
                site = AllocationSite(
                    key=site_key,
                    target=target,
                    kind=allocation_kind,
                    expected_release=release,
                    line=event.line,
                    column=event.column,
                    file=ownership.source.relative_path,
                    owner_scope=category,
                    owner_name=ownership.function.owner_class or ownership.function.qualified_name,
                    in_loop=event.in_loop,
                )
                self.sites[site_key] = site

            if category == "class" and ownership.function.owner_class:
                self.class_allocations.setdefault((ownership.function.owner_class, target.text), []).append(site)

            currently_bound = set(state.bindings.get(target.text, frozenset()))
            alive_bound = currently_bound & set(state.active)
            # Dynamic indexed targets represent an ownership family. Different
            # runtime indices may hold independent allocations, so never claim a
            # scalar overwrite merely because the normalized family name matches.
            should_report_overwrite = bool(alive_bound) and not target.family
            if should_report_overwrite:
                for old_id in alive_bound:
                    old = self.sites.get(old_id)
                    if old is not None:
                        self._report_overwrite(old, event, ownership)

            bindings = dict(state.bindings)
            if target.family:
                bindings[target.text] = frozenset(currently_bound | {site_key})
            else:
                bindings[target.text] = frozenset({site_key})
            state.bindings = bindings
            state.active = frozenset(set(state.active) | {site_key})
            state.freed = frozenset(set(state.freed) - {site_key})
            return

        if event.kind == "release":
            if category == "borrowed":
                self._report_borrowed_release(event, ownership)
                return
            if category == "class" and ownership.function.owner_class:
                self.class_releases.setdefault((ownership.function.owner_class, target.text), []).append(event)

            bound = set(state.bindings.get(target.text, frozenset()))
            if not bound:
                # Class memory may have been allocated by a different method; the
                # cross-method pairing is checked after all target methods run.
                return
            alive = bound & set(state.active)
            if not alive:
                if bound & set(state.freed):
                    self._report_double_release(event, ownership)
                return
            release_candidates = set(alive)
            if target.family and not event.in_loop and len(release_candidates) > 1:
                # A single dynamic-index release cannot prove that every member of
                # a family was destroyed. Keep the family active rather than
                # silently accepting an ambiguous partial cleanup.
                return
            for allocation_id in release_candidates:
                site = self.sites.get(allocation_id)
                if site is None:
                    continue
                if event.release_kind != site.expected_release:
                    self._report_mismatch(site, event.release_kind or "unknown", ownership.source.relative_path, event.line)
                    # A mismatched release is not accepted as satisfying ownership.
                    continue
                state.active = frozenset(set(state.active) - {allocation_id})
                state.freed = frozenset(set(state.freed) | {allocation_id})
            return

        if event.kind == "clear":
            bound = set(state.bindings.get(target.text, frozenset()))
            alive = bound & set(state.active)
            for allocation_id in alive:
                site = self.sites.get(allocation_id)
                if site is not None:
                    self._report_overwrite(site, event, ownership, clear=True)
            bindings = dict(state.bindings)
            bindings.pop(target.text, None)
            state.bindings = bindings
            return

        if event.kind == "alias" and event.source_target is not None:
            src_ids = state.bindings.get(event.source_target.text)
            if not src_ids:
                return
            old_ids = set(state.bindings.get(target.text, frozenset())) & set(state.active)
            new_ids = set(src_ids)
            for old_id in old_ids - new_ids:
                site = self.sites.get(old_id)
                if site is not None:
                    self._report_overwrite(site, event, ownership)
            bindings = dict(state.bindings)
            bindings[target.text] = frozenset(new_ids)
            state.bindings = bindings

    def _report_live_locals(
        self,
        state: FlowState,
        ownership: FunctionOwnership,
        exit_line: int,
        exit_reason: str,
    ) -> None:
        for allocation_id in sorted(state.active):
            site = self.sites.get(allocation_id)
            if site is None or site.owner_scope != "local":
                continue
            self._report_once(
                key=("MEM001", site.key, exit_line, ownership.function.qualified_name),
                finding=Finding(
                    checker="memory",
                    rule="MEM001",
                    severity=Severity.WARNING,
                    confidence=Confidence.HIGH,
                    location=SourceLocation(site.file, site.line, site.column),
                    message=f"Potential memory leak: owned target '{site.target.text}' is still allocated when {exit_reason}.",
                    details=(
                        f"Allocation uses {site.kind} in function '{ownership.function.qualified_name}'. "
                        f"The ownership model requires local allocations to be released by the same function. "
                        f"An unreleased exit is reachable at line {exit_line}."
                    ),
                    suggestion=f"Release '{site.target.text}' with {site.expected_release} before every function exit.",
                    evidence=[
                        f"allocated: {site.file}:{site.line}",
                        f"unreleased exit: {site.file}:{exit_line}",
                    ],
                    tags=["memory", "leak", "ownership"],
                    metadata={"target": site.target.text, "allocator": site.kind, "expected_release": site.expected_release},
                ),
            )

    def _finalize_class_ownership(self) -> None:
        for key, sites in self.class_allocations.items():
            class_name, target_text = key
            # Sites can be observed on multiple branch paths. Deduplicate by key.
            unique_sites = {site.key: site for site in sites}.values()
            releases = self.class_releases.get(key, [])
            for site in unique_sites:
                compatible = [r for r in releases if r.release_kind == site.expected_release]
                if compatible:
                    continue
                mismatched = [r for r in releases if r.release_kind != site.expected_release]
                for release_event in mismatched:
                    self._report_mismatch(
                        site,
                        release_event.release_kind or "unknown",
                        site.file,
                        release_event.line,
                    )
                evidence = [f"allocated: {site.file}:{site.line}"]
                if mismatched:
                    evidence.extend(
                        f"incompatible release '{r.release_kind}' at line {r.line}" for r in mismatched
                    )
                self._report_once(
                    key=("MEM007", site.key, 0, class_name),
                    finding=Finding(
                        checker="memory",
                        rule="MEM007",
                        severity=Severity.WARNING,
                        confidence=Confidence.HIGH,
                        location=SourceLocation(site.file, site.line, site.column),
                        message=(
                            f"Potential class-owned memory leak: '{class_name}::{target_text}' is allocated "
                            "but no compatible release was found in the analyzed class methods."
                        ),
                        details=(
                            f"The field receives memory from {site.kind}. Under the configured ownership model, "
                            f"class-owned allocations must be destroyed by the same class. Expected release: {site.expected_release}."
                        ),
                        suggestion=(
                            f"Release '{target_text}' with {site.expected_release} in the class lifetime/cleanup path "
                            "(commonly the destructor or an explicit class cleanup method)."
                        ),
                        evidence=evidence,
                        tags=["memory", "class-lifetime", "ownership"],
                        metadata={"class": class_name, "target": target_text, "allocator": site.kind},
                    ),
                )

    def _report_overwrite(
        self,
        site: AllocationSite,
        event: MemoryEvent,
        ownership: FunctionOwnership,
        *,
        clear: bool = False,
    ) -> None:
        action = "cleared" if clear else "overwritten"
        self._report_once(
            key=("MEM002", site.key, event.line, ownership.function.qualified_name),
            finding=Finding(
                checker="memory",
                rule="MEM002",
                severity=Severity.ERROR,
                confidence=Confidence.CERTAIN,
                location=SourceLocation(site.file, site.line, site.column),
                message=f"Owned allocation for '{site.target.text}' is {action} before it is released.",
                details=(
                    f"The allocation created with {site.kind} remains active when the owning target is {action} "
                    f"at line {event.line}. This loses the only tracked owner under the project ownership rules."
                ),
                suggestion=f"Call {site.expected_release} for the current allocation before replacing '{site.target.text}'.",
                evidence=[f"allocation: line {site.line}", f"{action}: line {event.line}"],
                tags=["memory", "leak", "overwrite"],
            ),
        )

    def _report_mismatch(
        self,
        site: AllocationSite,
        release_kind: str,
        file: str,
        line: int,
    ) -> None:
        self._report_once(
            key=("MEM003", site.key, line, release_kind),
            finding=Finding(
                checker="memory",
                rule="MEM003",
                severity=Severity.ERROR,
                confidence=Confidence.CERTAIN,
                location=SourceLocation(file, line, 1),
                message=(
                    f"Allocation/release mismatch for '{site.target.text}': {site.kind} is released with {release_kind}."
                ),
                details=f"This allocation expects {site.expected_release}.",
                suggestion=f"Use {site.expected_release} for this allocation.",
                evidence=[f"allocation: {site.file}:{site.line}", f"release: {file}:{line}"],
                tags=["memory", "mismatched-release"],
            ),
        )

    def _report_double_release(self, event: MemoryEvent, ownership: FunctionOwnership) -> None:
        target = event.target.text if event.target else "<unknown>"
        self._report_once(
            key=("MEM004", ownership.source.relative_path, event.line, target),
            finding=Finding(
                checker="memory",
                rule="MEM004",
                severity=Severity.ERROR,
                confidence=Confidence.HIGH,
                location=SourceLocation(ownership.source.relative_path, event.line, event.column),
                message=f"Potential double release of '{target}'.",
                details="The checker has already observed the tracked allocation being released on this execution path.",
                suggestion="Ensure each owned allocation is released exactly once.",
                tags=["memory", "double-free"],
            ),
        )

    def _report_borrowed_release(self, event: MemoryEvent, ownership: FunctionOwnership) -> None:
        target = event.target.text if event.target else "<unknown>"
        self._report_once(
            key=("MEM006", ownership.source.relative_path, event.line, target),
            finding=Finding(
                checker="memory",
                rule="MEM006",
                severity=Severity.WARNING,
                confidence=Confidence.HIGH,
                location=SourceLocation(ownership.source.relative_path, event.line, event.column),
                message=f"Function releases borrowed parameter '{target}'.",
                details=(
                    "Function parameters are treated as borrowed under this project's ownership model; "
                    "allocation/free ownership is not transferred through parameters."
                ),
                suggestion="Remove the release here or explicitly change the project ownership convention if this parameter is owning.",
                tags=["memory", "ownership", "borrowed"],
            ),
        )

    def _report_once(self, key: tuple[str, str, int, str], finding: Finding) -> None:
        if key in self._reported:
            return
        self._reported.add(key)
        self.findings.append(finding)

    def _target_from_tokens(
        self,
        tokens: Sequence[Token],
        ownership: FunctionOwnership,
        *,
        strip_address: bool = False,
    ) -> Target | None:
        work = [t for t in tokens if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}]
        if not work:
            return None
        while work and work[0].value == "(":
            # Strip only a simple outer pair.
            pairs = matching_pairs(work, "(", ")")
            if pairs.get(0) == len(work) - 1:
                work = work[1:-1]
            else:
                break
        if strip_address:
            while work and work[0].value in {"&", "*"}:
                work = work[1:]
        if not work:
            return None

        known = ownership.local_names | ownership.parameter_names | ownership.field_names
        candidate_index = None
        explicit_this = False

        # Prefer explicit this->field.
        for i in range(len(work) - 2):
            if work[i].value == "this" and work[i + 1].value == "->" and work[i + 2].value in ownership.field_names:
                candidate_index = i + 2
                explicit_this = True
                break

        if candidate_index is None:
            for i, token in enumerate(work):
                if token.kind == TokenKind.IDENTIFIER and token.value in known:
                    candidate_index = i
                    break
        if candidate_index is None:
            return None

        base = work[candidate_index].value
        pieces = [base]
        family = False
        i = candidate_index + 1
        while i < len(work):
            if work[i].value == "[":
                depth = 1
                j = i + 1
                inside: list[Token] = []
                while j < len(work) and depth:
                    if work[j].value == "[":
                        depth += 1
                    elif work[j].value == "]":
                        depth -= 1
                        if depth == 0:
                            break
                    if depth:
                        inside.append(work[j])
                    j += 1
                if depth != 0:
                    break
                if len(inside) == 1 and inside[0].kind == TokenKind.NUMBER:
                    pieces.append(f"[{inside[0].value}]")
                else:
                    pieces.append("[*]")
                    family = True
                i = j + 1
                continue
            # Stop before assignment/type/call syntax. Member access other than
            # this->field is intentionally not treated as an owned target.
            break

        return Target("".join(pieces), base, family, explicit_this)

    @staticmethod
    def _top_level_assignment(tokens: Sequence[Token]) -> int | None:
        round_depth = square_depth = curly_depth = 0
        for i, token in enumerate(tokens):
            v = token.value
            if v == "(":
                round_depth += 1
            elif v == ")" and round_depth:
                round_depth -= 1
            elif v == "[":
                square_depth += 1
            elif v == "]" and square_depth:
                square_depth -= 1
            elif v == "{":
                curly_depth += 1
            elif v == "}" and curly_depth:
                curly_depth -= 1
            elif v == "=" and round_depth == square_depth == curly_depth == 0:
                return i
        return None

    @staticmethod
    def _find_calls(tokens: Sequence[Token]) -> list[tuple[str, list[list[Token]], Token]]:
        tokens = list(tokens)
        parens = matching_pairs(tokens, "(", ")")
        calls: list[tuple[str, list[list[Token]], Token]] = []
        for i, token in enumerate(tokens):
            if token.value != "(" or i not in parens:
                continue
            if i == 0:
                continue
            end = parens[i]
            if end <= i:
                continue

            # Walk backwards over identifier, ::, ., -> components.
            j = i - 1
            if tokens[j].kind != TokenKind.IDENTIFIER:
                continue
            parts = [tokens[j].value]
            call_token = tokens[j]
            j -= 1
            while j >= 1 and tokens[j].value in {"::", ".", "->"} and tokens[j - 1].kind == TokenKind.IDENTIFIER:
                parts.insert(0, tokens[j].value)
                parts.insert(0, tokens[j - 1].value)
                call_token = tokens[j - 1]
                j -= 2
            name = "".join(parts)
            args = split_top_level(tokens[i + 1:end], ",")
            if args == [[]]:
                args = []
            calls.append((name, args, call_token))
        return calls

    @staticmethod
    def _dedupe_events(events: Iterable[MemoryEvent]) -> list[MemoryEvent]:
        seen: set[tuple] = set()
        out: list[MemoryEvent] = []
        for event in events:
            key = (
                event.kind,
                event.line,
                event.column,
                event.target.text if event.target else None,
                event.allocation_kind,
                event.release_kind,
                event.source_target.text if event.source_target else None,
            )
            if key not in seen:
                seen.add(key)
                out.append(event)
        return out

    def _dedupe_states(self, states: Iterable[FlowState]) -> list[FlowState]:
        unique: dict[tuple, FlowState] = {}
        for state in states:
            unique.setdefault(state.signature(), state)
            if len(unique) >= self.max_states:
                break
        return list(unique.values())
