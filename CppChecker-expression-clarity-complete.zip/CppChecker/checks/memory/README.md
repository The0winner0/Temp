# Memory checker

The memory checker implements the project's explicit ownership convention rather than general C++ ownership inference.

## Ownership model

- Only function definitions in the selected target implementation file are analyzed.
- If the project contains exactly one `.c/.cc/.cpp/.cxx`, it is selected automatically.
- Otherwise `main.cpp`, then a unique file defining `main()`, is preferred.
- If selection is still ambiguous, set `checks.memory.target_cpp` to a relative path, filename, or unique stem.
- Local variables allocated in a function must be released by that function on every analyzed exit path.
- Function parameters are borrowed. The checker does not assume ownership is transferred through parameters.
- Unknown dependency objects/functions are opaque. Their internals are not analyzed and ordinary calls do not change ownership.
- A field of the current class is class-owned. Allocation and release may occur in different methods of that class.
- Allocation/release into unrelated objects is ignored.

## Built-in memory operations

Allocation:

- `new T`
- `new T[n]`
- `malloc(...)`
- `calloc(...)`

Release:

- `delete p`
- `delete[] p`
- `free(p)`

Pairing is strict: `new` -> `delete`, `new[]` -> `delete[]`, and `malloc/calloc` -> `free`.

Indexed ownership such as `a[i] = new T[n]` is normalized to an ownership family (`a[*]`). This allows an allocation loop and a later cleanup loop using `delete[] a[i]` to pair without pretending the checker knows the runtime index count. Outer allocations such as `a = new T*[count]` remain separate and also require release.

## Custom memory APIs

Size, offset, flags and other arguments are ignored. Only the variable being initialized/destroyed matters.

Return-style allocator:

```json
{
  "allocator": "PoolAlloc",
  "deallocator": "PoolFree",
  "allocation_mode": "return"
}
```

Recognizes:

```cpp
Buffer* p = PoolAlloc(size, offset);
PoolFree(p);
```

Out-argument initializer:

```json
{
  "allocator": "BufferInit",
  "deallocator": "BufferDestroy",
  "allocation_mode": "out_arg",
  "target_arg": 0,
  "deallocator_target_arg": 0
}
```

Recognizes both address-style and direct target arguments:

```cpp
BufferInit(&buffer, size, offset);
BufferDestroy(&buffer);
```

or APIs whose target itself is the configured argument.

Qualified API names such as `Memory::Alloc` can be used as names. Short-name matching is also supported.

## Current diagnostics

- `MEM000`: target implementation file is ambiguous; analysis skipped.
- `MEM001`: local allocation can reach function exit unreleased.
- `MEM002`: owned allocation is overwritten/cleared before release.
- `MEM003`: allocator/release mismatch.
- `MEM004`: potential double release on the same analyzed path.
- `MEM006`: function frees a borrowed pointer parameter.
- `MEM007`: class field is allocated but no compatible class release was found.

The analyzer is intentionally conservative. Unsupported/opaque ownership syntax is skipped instead of being guessed.
