from __future__ import annotations

from typing import Any, Mapping

from core.api import Checker, CheckerMetadata
from core.diagnostics import Finding
from core.source_context import ProjectContext

from .analyzer import MemoryAnalyzer


class MemoryChecker(Checker):
    metadata = CheckerMetadata(
        name="memory",
        description=(
            "Checks project-specific local/class memory ownership, allocation/release "
            "pairing, overwrite leaks, and release mismatches."
        ),
        version="1.0",
    )

    def run(self, context: ProjectContext, config: Mapping[str, Any]) -> list[Finding]:
        return MemoryAnalyzer(config).analyze(context)


def create_checker() -> Checker:
    return MemoryChecker()
