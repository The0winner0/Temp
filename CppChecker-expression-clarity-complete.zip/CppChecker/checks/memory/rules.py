from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


BUILTIN_ALLOCATORS: dict[str, tuple[str, str]] = {
    "malloc": ("malloc", "free"),
    "calloc": ("calloc", "free"),
}

BUILTIN_RELEASES: dict[str, str] = {
    "free": "free",
}

NEW_KIND = "new"
NEW_ARRAY_KIND = "new[]"
DELETE_KIND = "delete"
DELETE_ARRAY_KIND = "delete[]"

EXPECTED_RELEASE: dict[str, str] = {
    "malloc": "free",
    "calloc": "free",
    NEW_KIND: DELETE_KIND,
    NEW_ARRAY_KIND: DELETE_ARRAY_KIND,
}


@dataclass(frozen=True, slots=True)
class CustomMemoryAPI:
    allocator: str
    deallocator: str
    allocation_mode: str = "return"  # return | out_arg
    target_arg: int = 0
    deallocator_target_arg: int = 0

    @property
    def allocation_kind(self) -> str:
        return f"custom:{self.allocator}"

    @property
    def release_kind(self) -> str:
        return f"custom:{self.deallocator}"


def _first_text(item: Mapping[str, Any], keys: tuple[str, ...]) -> str | None:
    for key in keys:
        value = item.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def parse_custom_apis(config: Mapping[str, Any]) -> list[CustomMemoryAPI]:
    """Parse a deliberately small, explicit custom allocation API schema.

    Supported forms inside ``custom_apis``::

        {
          "allocator": "PoolAlloc",
          "deallocator": "PoolFree",
          "allocation_mode": "return"
        }

        {
          "allocator": "BufferInit",
          "deallocator": "BufferDestroy",
          "allocation_mode": "out_arg",
          "target_arg": 0,
          "deallocator_target_arg": 0
        }

    Aliases ``name``/``allocate`` and ``free``/``destroy`` are accepted so the
    config can describe existing APIs naturally. Size/offset arguments are not
    interpreted; only the configured ownership target argument matters.
    """
    raw = config.get("custom_apis", [])
    if not isinstance(raw, list):
        return []

    result: list[CustomMemoryAPI] = []
    for item in raw:
        if not isinstance(item, Mapping):
            continue
        allocator = _first_text(item, ("allocator", "allocate", "name"))
        deallocator = _first_text(item, ("deallocator", "free", "destroy"))
        if not allocator or not deallocator:
            continue
        mode = str(item.get("allocation_mode", item.get("mode", "return"))).strip().lower()
        if mode not in {"return", "out_arg"}:
            continue
        try:
            target_arg = int(item.get("target_arg", 0))
            free_arg = int(item.get("deallocator_target_arg", item.get("free_target_arg", 0)))
        except (TypeError, ValueError):
            continue
        if target_arg < 0 or free_arg < 0:
            continue
        result.append(
            CustomMemoryAPI(
                allocator=allocator,
                deallocator=deallocator,
                allocation_mode=mode,
                target_arg=target_arg,
                deallocator_target_arg=free_arg,
            )
        )
    return result


def expected_release(allocation_kind: str, custom_apis: list[CustomMemoryAPI]) -> str | None:
    if allocation_kind in EXPECTED_RELEASE:
        return EXPECTED_RELEASE[allocation_kind]
    for api in custom_apis:
        if allocation_kind == api.allocation_kind:
            return api.release_kind
    return None
