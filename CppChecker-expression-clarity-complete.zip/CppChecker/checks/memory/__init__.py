"""Memory ownership checker package."""
