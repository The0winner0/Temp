from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class GrammarRule:
    rule_id: str
    pattern: re.Pattern[str]
    message: str
    suggestion_template: str
    confidence: str = "high"


# These rules are intentionally narrow. They should catch likely mistakes without
# pretending to be a general English grammar model.
GRAMMAR_RULES: tuple[GrammarRule, ...] = (
    GrammarRule(
        "LANG201",
        re.compile(r"\b(more|less|greater|smaller|larger|better|worse|faster|slower|higher|lower|rather|other|different)\s+then\b", re.I),
        "'then' is probably being used where the comparative word 'than' is required.",
        "Use '{1} than'.",
    ),
    GrammarRule(
        "LANG202",
        re.compile(r"\btheir\s+(is|are|was|were|seems?|appears?|exists?|remains?)\b", re.I),
        "'their' is possessive; this construction normally requires 'there'.",
        "Use 'there {1}'.",
    ),
    GrammarRule(
        "LANG203",
        re.compile(r"\byour\s+(welcome|using|trying|doing|going|calling|passing|returning|checking|setting|getting|writing|reading|allocating|freeing|deleting|creating|destroying)\b", re.I),
        "'your' is possessive; this phrase probably requires 'you're' ('you are').",
        "Use \"you're {1}\".",
    ),
    GrammarRule(
        "LANG204",
        re.compile(r"\bits\s+(not|a|an|the|being|been|used|called|going|required|needed|important|correct|wrong|valid|invalid)\b", re.I),
        "'its' is possessive; this phrase probably requires \"it's\" ('it is'/'it has').",
        "Use \"it's {1}\".",
    ),
    GrammarRule(
        "LANG205",
        re.compile(r"\bit['’]s\s+([A-Za-z]+)\s+(is|are|was|were)\b", re.I),
        "\"it's\" means 'it is'/'it has'; this looks like a possessive construction.",
        "Use 'its {1} {2}'.",
    ),
    GrammarRule(
        "LANG206",
        re.compile(r"\b(should|could|would|might|must)\s+of\b", re.I),
        "A modal verb should be followed by 'have', not 'of', in this construction.",
        "Use '{1} have'.",
        confidence="certain",
    ),
    GrammarRule(
        "LANG207",
        re.compile(r"\bto\s+(many|much|few)\b", re.I),
        "'to' is probably being used where the degree word 'too' is required.",
        "Use 'too {1}'.",
    ),
    GrammarRule(
        "LANG208",
        re.compile(r"\b(a)\s+(array|integer|object|enum|allocation|error|index|offset|address)\b", re.I),
        "The article 'a' should normally be 'an' before this technical noun.",
        "Use 'an {1}'.",
    ),
    GrammarRule(
        "LANG209",
        re.compile(r"\b(an)\s+(function|variable|pointer|class|buffer|file|string|member|method|value|type)\b", re.I),
        "The article 'an' should normally be 'a' before this technical noun.",
        "Use 'a {1}'.",
    ),
    GrammarRule(
        "LANG210",
        re.compile(r"\b(variables|functions|pointers|classes|buffers|files|strings|members|methods|values|types|arrays|objects)\s+(is|was)\b", re.I),
        "Plural technical noun uses a singular verb.",
        "Use '{0} {verb}'.",
    ),
    GrammarRule(
        "LANG211",
        re.compile(r"\b(variable|function|pointer|class|buffer|file|string|member|method|value|type|array|object)\s+(are|were)\b", re.I),
        "Singular technical noun uses a plural verb.",
        "Use '{0} {verb}'.",
    ),
    GrammarRule(
        "LANG212",
        re.compile(r"\bthese\s+(type|function|variable|pointer|class|object|value|file|string|buffer|array|member|method)\b", re.I),
        "'these' normally modifies a plural noun; the following technical noun is singular.",
        "Use 'this {1}' or pluralize the noun, depending on the intended meaning.",
    ),
    GrammarRule(
        "LANG213",
        re.compile(r"\bthis\s+(types|functions|variables|pointers|classes|objects|values|files|strings|buffers|arrays|members|methods)\b", re.I),
        "'this' normally modifies a singular noun; the following technical noun is plural.",
        "Use 'these {1}' or make the noun singular, depending on the intended meaning.",
    ),
    GrammarRule(
        "LANG214",
        re.compile(r"\bthere\s+(value|size|name|type|length|count|result|address|pointer|variable|function|class|object|member|index|offset|state|buffer|allocation|owner|ownership)\b", re.I),
        "'there' indicates a place/existence; this looks like a possessive use of 'their'.",
        "Use 'their {1}' if possession is intended.",
        confidence="medium",
    ),
)

# Base forms after "did not/didn't" and "does not/doesn't". Restricted to
# common technical verbs so the checker remains conservative.
DID_NOT_FORMS = {
    "used": "use",
    "called": "call",
    "returned": "return",
    "allocated": "allocate",
    "freed": "free",
    "deleted": "delete",
    "initialized": "initialize",
    "created": "create",
    "destroyed": "destroy",
    "checked": "check",
    "assigned": "assign",
    "released": "release",
}

DOES_NOT_FORMS = {
    "uses": "use",
    "calls": "call",
    "returns": "return",
    "allocates": "allocate",
    "frees": "free",
    "deletes": "delete",
    "initializes": "initialize",
    "creates": "create",
    "destroys": "destroy",
    "checks": "check",
    "assigns": "assign",
    "releases": "release",
}

# High-value corrections get precedence over equally-close obscure dictionary words.
# This is deliberately small; normal suggestions still come from the local dictionaries.
COMMON_CORRECTIONS = {
    "teh": "the",
    "lenght": "length",
    "complted": "completed",
    "recieve": "receive",
    "recieved": "received",
    "seperate": "separate",
    "seperated": "separated",
    "occured": "occurred",
    "adress": "address",
    "enviroment": "environment",
    "sucess": "success",
    "succesful": "successful",
    "succesfully": "successfully",
    "paramter": "parameter",
    "varible": "variable",
    "funcion": "function",
    "alocate": "allocate",
    "alocated": "allocated",
    "deallocateed": "deallocated",
    "initialiseed": "initialized",
}


def language_directory() -> Path:
    return Path(__file__).resolve().parent


def dictionary_files() -> list[Path]:
    """Every .txt below this checker directory is a dictionary, by design."""
    return sorted(path for path in language_directory().rglob("*.txt") if path.is_file())


def load_dictionary() -> tuple[set[str], list[Path]]:
    words: set[str] = set()
    loaded: list[Path] = []
    for path in dictionary_files():
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        loaded.append(path)
        for line in text.splitlines():
            word = line.strip().casefold()
            if not word or word.startswith("#"):
                continue
            words.add(word.replace("’", "'"))
    return words, loaded


def ignored_words(config: Mapping[str, Any]) -> set[str]:
    raw = config.get("ignore_words", [])
    if not isinstance(raw, list):
        return set()
    return {str(word).casefold() for word in raw if str(word).strip()}
