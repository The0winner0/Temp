# Language checker

Pure-Python spelling + conservative grammar checks for C/C++ prose.

## What is checked

- `// line comments`
- `/* block comments */`
- normal C/C++ string literals
- raw string literals
- strings passed to `printf`, logging functions, constructors, `cout`, etc. are automatically covered because the checker works on string-literal tokens rather than specific APIs.

Character literals are intentionally not checked.

## Dictionaries

**Every `.txt` file anywhere below `checks/language/` is automatically loaded as a dictionary.**

The expected format is one accepted word per line. Blank lines and lines beginning with `#` are ignored.

Example:

```text
renderer
raycast
voxelizer
PhysicsKinetics
```

You can therefore add files such as:

```text
checks/language/dictionaries/project_terms.txt
checks/language/dictionaries/company_terms.txt
checks/language/my_extra_words.txt
```

No config or Python changes are required.

The bundled dictionaries are static local text files; the checker never downloads anything.

## Identifier suppression

Identifiers occurring in actual code are collected before prose is checked. Variables, parameters, fields, functions, classes, types, macros/token identifiers, and their common snake/camel components are therefore not reported as spelling errors when they are mentioned in a comment or string.

The checker also suppresses URLs, email addresses, paths/file names, printf format specifiers, `{name}`/`{0}`-style format fields, backtick code fragments, Doxygen tags, hexadecimal values, short all-caps acronyms, and code-like underscore/numeric fragments.

## Spelling precision

By default an unknown word is reported only when the local dictionaries contain a close edit-distance suggestion. This reduces false positives from legitimate domain terminology. Set `report_unknown_without_suggestion` to `true` if you want every unknown prose word reported.

## Grammar

This is intentionally **not** a general grammar engine. Without a language model or external library, broad grammar checking would produce too many false alarms.

The module instead checks a small set of high-confidence patterns, including:

- repeated words (`the the`)
- comparative `then` vs `than`
- common `their`/`there`, `your`/`you're`, `its`/`it's` mistakes
- `should/could/would of` -> `... have`
- `to many` -> `too many`
- selected `a`/`an` errors for technical nouns
- singular/plural agreement for common technical nouns
- `this/these` agreement for technical nouns
- base tense after `did not` / `does not`

Ambiguous grammar is intentionally skipped.
