from __future__ import annotations

import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.source_context import ProjectContext, SourceFileContext
from core.tokenizer import Token, TokenKind

from .rules import (
    COMMON_CORRECTIONS,
    DID_NOT_FORMS,
    DOES_NOT_FORMS,
    GRAMMAR_RULES,
    ignored_words,
)


_CPP_KEYWORDS = {
    "alignas", "alignof", "and", "and_eq", "asm", "auto", "bitand", "bitor",
    "bool", "break", "case", "catch", "char", "char8_t", "char16_t", "char32_t",
    "class", "compl", "concept", "const", "consteval", "constexpr", "constinit",
    "const_cast", "continue", "co_await", "co_return", "co_yield", "decltype",
    "default", "delete", "do", "double", "dynamic_cast", "else", "enum", "explicit",
    "export", "extern", "false", "float", "for", "friend", "goto", "if", "inline",
    "int", "long", "mutable", "namespace", "new", "noexcept", "not", "not_eq",
    "nullptr", "operator", "or", "or_eq", "private", "protected", "public", "register",
    "reinterpret_cast", "requires", "return", "short", "signed", "sizeof", "static",
    "static_assert", "static_cast", "struct", "switch", "template", "this", "thread_local",
    "throw", "true", "try", "typedef", "typeid", "typename", "union", "unsigned",
    "using", "virtual", "void", "volatile", "wchar_t", "while", "xor", "xor_eq",
}

# Common tokens that appear in C/C++ comments and diagnostic strings. Most are also
# shipped in cpp_terms.txt, but keeping a small built-in safety set avoids noisy
# reports if a user replaces the bundled dictionaries.
_ALWAYS_IGNORE = {
    "api", "apis", "ascii", "bool", "byte", "bytes", "cpu", "cpp", "crc", "dll",
    "endianness", "enum", "errno", "fifo", "gpu", "gui", "http", "https", "id",
    "ids", "io", "ipv4", "ipv6", "json", "lhs", "mutex", "nullptr", "opcode", "os",
    "ptr", "rhs", "sdk", "simd", "sql", "stderr", "stdin", "stdout", "tcp", "todo",
    "uint", "uint8", "uint16", "uint32", "uint64", "int8", "int16", "int32", "int64",
    "ui", "unicode", "uri", "url", "utf", "utf8", "utf16", "uuid", "xml", "yaml",
}

_WORD_RE = re.compile(r"[A-Za-z]+(?:['’][A-Za-z]+)?")
_URL_RE = re.compile(r"\b(?:https?://|ftp://|www\.)\S+", re.I)
_EMAIL_RE = re.compile(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b")
_PATH_RE = re.compile(
    r"(?<!\w)(?:[A-Za-z]:[\\/][^\s]+|(?:\.?\.?[\\/])?[^\s/\\]+(?:[\\/][^\s/\\]+)+|[\w.-]+\.(?:c|cc|cpp|cxx|h|hh|hpp|hxx|txt|json|xml|yaml|yml|ini|cfg|md|png|jpg|jpeg|bin|dat|log))(?!\w)",
    re.I,
)
_FORMAT_RE = re.compile(r"%(?:[-+ #0']*\d*(?:\.\d+)?(?:hh|h|ll|l|j|z|t|L)?[diuoxXfFeEgGaAcspn%])")
_BRACED_FORMAT_RE = re.compile(r"\{(?:\d+|[A-Za-z_][A-Za-z0-9_]*)(?::[^{}]*)?\}")
_BACKTICK_RE = re.compile(r"`[^`]*`")
_DOXY_TAG_RE = re.compile(r"[@\\](?:param|tparam|return|returns|brief|details|note|warning|see|sa|throws?|exception|deprecated|since|author|file|class|struct|fn|var)\b", re.I)
_HEX_RE = re.compile(r"\b(?:0x[0-9A-Fa-f]+|[0-9A-Fa-f]{8,})\b")


@dataclass(frozen=True, slots=True)
class Segment:
    file: SourceFileContext
    token: Token
    text: str
    token_content_offset: int
    kind: str  # comment or string

    def location(self, local_offset: int) -> tuple[int, int]:
        raw_offset = self.token_content_offset + local_offset
        prefix = self.token.value[:raw_offset]
        newlines = prefix.count("\n")
        if newlines == 0:
            return self.token.line, self.token.column + raw_offset
        last_newline = prefix.rfind("\n")
        return self.token.line + newlines, raw_offset - last_newline


class LanguageAnalyzer:
    def __init__(
        self,
        config: Mapping[str, Any],
        dictionary: set[str],
        dictionary_files: list[Path],
    ) -> None:
        self.config = config
        self.dictionary = {w.casefold().replace("’", "'") for w in dictionary}
        self.dictionary_files = dictionary_files
        self.check_spelling = bool(config.get("check_spelling", True))
        self.check_grammar = bool(config.get("check_grammar", True))
        self.check_comments = bool(config.get("check_comments", True))
        self.check_strings = bool(config.get("check_strings", True))
        self.min_word_length = max(1, int(config.get("min_word_length", 3)))
        self.max_edit_distance = max(0, min(3, int(config.get("max_edit_distance", 2))))
        self.report_unknown_without_suggestion = bool(
            config.get("report_unknown_without_suggestion", False)
        )
        self.max_suggestions = max(1, min(5, int(config.get("max_suggestions", 3))))
        self.user_ignore = ignored_words(config)
        self._length_index: dict[int, set[str]] = defaultdict(set)
        self._length_first_index: dict[tuple[int, str], set[str]] = defaultdict(set)
        for word in self.dictionary:
            if not word or not word[0].isalpha():
                continue
            length = len(word)
            self._length_index[length].add(word)
            self._length_first_index[(length, word[0])].add(word)

    def analyze(self, context: ProjectContext) -> list[Finding]:
        identifier_words = self._collect_identifier_words(context)
        findings: list[Finding] = []
        for source in context.files:
            for segment in self._segments(source):
                if self.check_spelling:
                    findings.extend(self._spell_segment(segment, identifier_words))
                if self.check_grammar:
                    findings.extend(self._grammar_segment(segment))
        return self._deduplicate(findings)

    def _segments(self, source: SourceFileContext) -> Iterable[Segment]:
        for token in source.tokens:
            if self.check_comments and token.kind in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}:
                if token.kind is TokenKind.COMMENT_LINE:
                    yield Segment(source, token, token.value[2:], 2, "comment")
                else:
                    content = token.value[2:-2] if token.value.endswith("*/") else token.value[2:]
                    yield Segment(source, token, content, 2, "comment")
            elif self.check_strings and token.kind in {TokenKind.STRING, TokenKind.RAW_STRING}:
                extracted = self._string_content(token)
                if extracted is not None:
                    text, offset = extracted
                    yield Segment(source, token, text, offset, "string")

    @staticmethod
    def _string_content(token: Token) -> tuple[str, int] | None:
        value = token.value
        if token.kind is TokenKind.RAW_STRING:
            quote = value.find('R"')
            if quote == -1:
                return None
            open_paren = value.find("(", quote + 2)
            if open_paren == -1:
                return None
            close_paren = value.rfind(")")
            if close_paren <= open_paren:
                return None
            return value[open_paren + 1:close_paren], open_paren + 1

        quote = value.find('"')
        if quote == -1:
            return None
        end_quote = len(value) - 1 if value.endswith('"') else len(value)
        content = value[quote + 1:end_quote]
        # Preserve character positions: replace escape sequences with spaces except escaped
        # apostrophes/quotes, which are harmless for word extraction anyway.
        content = re.sub(r"\\(?:x[0-9A-Fa-f]+|u[0-9A-Fa-f]{4}|U[0-9A-Fa-f]{8}|[0-7]{1,3}|.)", lambda m: " " * len(m.group(0)), content)
        return content, quote + 1

    def _collect_identifier_words(self, context: ProjectContext) -> set[str]:
        result = {kw.casefold() for kw in _CPP_KEYWORDS}
        result.update(_ALWAYS_IGNORE)
        result.update(self.user_ignore)

        # Every identifier token from actual code (not comments/strings) is considered valid
        # terminology. This directly prevents variable/function/type names from becoming
        # spelling errors when mentioned in prose.
        for source in context.files:
            for token in source.tokens:
                if token.kind is TokenKind.IDENTIFIER:
                    result.add(token.value.casefold())
                    result.update(self._identifier_components(token.value))

        # Include parsed symbols too in case future tokenizer/parser behavior changes.
        for fn in context.functions:
            result.add(fn.name.casefold())
            result.update(self._identifier_components(fn.name))
            result.add(fn.qualified_name.casefold())
            for param in fn.parameters:
                if param.name:
                    result.add(param.name.casefold())
                    result.update(self._identifier_components(param.name))
            for var in fn.local_variables:
                result.add(var.name.casefold())
                result.update(self._identifier_components(var.name))
        for cls in context.classes:
            result.add(cls.name.casefold())
            result.update(self._identifier_components(cls.name))
            for field in cls.fields:
                result.add(field.name.casefold())
                result.update(self._identifier_components(field.name))
        return result

    @staticmethod
    def _identifier_components(identifier: str) -> set[str]:
        # Split snake_case and CamelCase. Components shorter than 3 are ignored because
        # blindly exempting tiny fragments makes real typos too easy to miss.
        chunks = re.split(r"_+", identifier)
        result: set[str] = set()
        for chunk in chunks:
            for part in re.findall(r"[A-Z]+(?=[A-Z][a-z]|\d|$)|[A-Z]?[a-z]+|\d+", chunk):
                if len(part) >= 3 and part.isalpha():
                    result.add(part.casefold())
        return result

    def _masked_text(self, text: str) -> str:
        masked = text
        for pattern in (_URL_RE, _EMAIL_RE, _PATH_RE, _FORMAT_RE, _BRACED_FORMAT_RE, _BACKTICK_RE, _DOXY_TAG_RE, _HEX_RE):
            masked = pattern.sub(lambda m: " " * len(m.group(0)), masked)
        return masked

    def _spell_segment(self, segment: Segment, identifier_words: set[str]) -> list[Finding]:
        text = self._masked_text(segment.text)
        findings: list[Finding] = []
        seen_offsets: set[int] = set()
        for match in _WORD_RE.finditer(text):
            raw = match.group(0)
            normalized = raw.casefold().replace("’", "'")
            if match.start() in seen_offsets:
                continue
            seen_offsets.add(match.start())
            if not self._should_check_word(text, match.start(), match.end(), raw, normalized, identifier_words):
                continue
            if normalized in self.dictionary:
                continue
            suggestions = self._suggest(normalized)
            if not suggestions and not self.report_unknown_without_suggestion:
                continue
            line, column = segment.location(match.start())
            suggestion = ""
            if suggestions:
                suggestion = "Possible correction: " + ", ".join(suggestions) + "."
            else:
                suggestion = (
                    "If this is a valid project/domain term, add it as a new line to any "
                    ".txt dictionary under checks/language/."
                )
            findings.append(
                Finding(
                    checker="language",
                    rule="LANG101",
                    severity=Severity.STYLE,
                    confidence=Confidence.HIGH if suggestions else Confidence.MEDIUM,
                    location=SourceLocation(segment.file.relative_path, line, column),
                    message=f"Possible spelling error: '{raw}'.",
                    details=(
                        f"The word appears in a {segment.kind} but was not found in the local "
                        f"dictionary set ({len(self.dictionary_files)} .txt file(s))."
                    ),
                    suggestion=suggestion,
                    evidence=[self._line_evidence(segment.file, line)],
                    tags=["spelling", segment.kind],
                    metadata={"word": raw, "suggestions": suggestions},
                )
            )
        return findings

    def _should_check_word(
        self,
        text: str,
        start: int,
        end: int,
        raw: str,
        normalized: str,
        identifier_words: set[str],
    ) -> bool:
        if len(normalized.replace("'", "")) < self.min_word_length:
            return False
        if normalized in identifier_words or normalized in self.user_ignore:
            return False
        if raw.isupper() and len(raw) <= 8:  # likely acronym
            return False
        # Skip chunks embedded in snake_case, numeric identifiers, or other code-like tokens.
        left = text[start - 1] if start > 0 else ""
        right = text[end] if end < len(text) else ""
        if left == "_" or right == "_" or left.isdigit() or right.isdigit():
            return False
        if "'" in normalized and normalized not in self.dictionary:
            # Unknown contractions/names are too noisy without a full NLP model.
            return False
        return True

    def _suggest(self, word: str) -> list[str]:
        preferred = COMMON_CORRECTIONS.get(word)
        if preferred and preferred in self.dictionary:
            return [preferred]
        if self.max_edit_distance <= 0 or not word or not word[0].isalpha():
            return []
        base_len = len(word)
        # Same first letter dramatically limits work and is a useful precision filter.
        candidates: set[str] = set()
        for length in range(max(1, base_len - self.max_edit_distance), base_len + self.max_edit_distance + 1):
            candidates.update(self._length_first_index.get((length, word[0]), ()))

        scored: list[tuple[int, int, str]] = []
        for candidate in candidates:
            distance = self._bounded_distance(word, candidate, self.max_edit_distance)
            if distance is None or distance == 0:
                continue
            # For tiny words, only one-edit suggestions are trustworthy.
            allowed = 1 if base_len <= 5 else self.max_edit_distance
            if distance <= allowed:
                scored.append((distance, abs(len(candidate) - base_len), candidate))
        scored.sort()
        if not scored:
            return []
        best_distance = scored[0][0]
        # Returning only the best edit-distance tier avoids absurd suggestion lists.
        return [item[2] for item in scored if item[0] == best_distance][: self.max_suggestions]

    @staticmethod
    def _bounded_distance(a: str, b: str, max_distance: int) -> int | None:
        """Bounded optimal-string-alignment distance.

        Adjacent transpositions count as one edit, which is important for normal typos
        such as `teh` -> `the` or `lenght` -> `length`.
        """
        if abs(len(a) - len(b)) > max_distance:
            return None
        if a == b:
            return 0
        prev_prev: list[int] | None = None
        previous = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            current = [i]
            row_min = i
            for j, cb in enumerate(b, 1):
                cost = 0 if ca == cb else 1
                value = min(
                    previous[j] + 1,
                    current[j - 1] + 1,
                    previous[j - 1] + cost,
                )
                if (
                    prev_prev is not None
                    and i > 1
                    and j > 1
                    and a[i - 1] == b[j - 2]
                    and a[i - 2] == b[j - 1]
                ):
                    value = min(value, prev_prev[j - 2] + 1)
                current.append(value)
                row_min = min(row_min, value)
            if row_min > max_distance:
                return None
            prev_prev, previous = previous, current
        result = previous[-1]
        return result if result <= max_distance else None

    def _grammar_segment(self, segment: Segment) -> list[Finding]:
        text = self._masked_text(segment.text)
        # Replace comment-decoration stars at line starts, while preserving offsets.
        text = re.sub(r"(?m)^(\s*)\*\s?", lambda m: " " * len(m.group(0)), text)
        findings: list[Finding] = []

        # Repeated words are deterministic enough to treat separately.
        for match in re.finditer(r"\b([A-Za-z]+)\s+\1\b", text, re.I):
            line, column = segment.location(match.start())
            findings.append(
                Finding(
                    checker="language",
                    rule="LANG200",
                    severity=Severity.STYLE,
                    confidence=Confidence.CERTAIN,
                    location=SourceLocation(segment.file.relative_path, line, column),
                    message=f"Repeated word: '{match.group(1)}'.",
                    details="The same word occurs twice consecutively in prose.",
                    suggestion=f"Remove one occurrence of '{match.group(1)}'.",
                    evidence=[self._line_evidence(segment.file, line)],
                    tags=["grammar", segment.kind],
                )
            )

        for rule in GRAMMAR_RULES:
            for match in rule.pattern.finditer(text):
                line, column = segment.location(match.start())
                groups = (match.group(0),) + match.groups()
                suggestion = self._format_grammar_suggestion(rule.rule_id, rule.suggestion_template, match)
                findings.append(
                    Finding(
                        checker="language",
                        rule=rule.rule_id,
                        severity=Severity.STYLE,
                        confidence=self._confidence(rule.confidence),
                        location=SourceLocation(segment.file.relative_path, line, column),
                        message=rule.message,
                        details=f"Matched phrase: '{match.group(0)}'.",
                        suggestion=suggestion,
                        evidence=[self._line_evidence(segment.file, line)],
                        tags=["grammar", segment.kind],
                        metadata={"phrase": match.group(0), "groups": list(groups)},
                    )
                )

        findings.extend(self._did_does_rules(segment, text))
        return findings

    @staticmethod
    def _format_grammar_suggestion(rule_id: str, template: str, match: re.Match[str]) -> str:
        if rule_id == "LANG210":
            verb = "are" if match.group(2).casefold() == "is" else "were"
            return template.format(match.group(1), verb=verb)
        if rule_id == "LANG211":
            verb = "is" if match.group(2).casefold() == "are" else "was"
            return template.format(match.group(1), verb=verb)
        args = [match.group(0)] + list(match.groups())
        try:
            return template.format(*args)
        except (IndexError, KeyError):
            return template

    def _did_does_rules(self, segment: Segment, text: str) -> list[Finding]:
        findings: list[Finding] = []
        did_pattern = re.compile(
            r"\b(did\s+not|didn't)\s+(" + "|".join(map(re.escape, DID_NOT_FORMS)) + r")\b",
            re.I,
        )
        does_pattern = re.compile(
            r"\b(does\s+not|doesn't)\s+(" + "|".join(map(re.escape, DOES_NOT_FORMS)) + r")\b",
            re.I,
        )
        for pattern, forms, rule_id in (
            (did_pattern, DID_NOT_FORMS, "LANG215"),
            (does_pattern, DOES_NOT_FORMS, "LANG216"),
        ):
            for match in pattern.finditer(text):
                wrong = match.group(2)
                base = forms[wrong.casefold()]
                line, column = segment.location(match.start(2))
                findings.append(
                    Finding(
                        checker="language",
                        rule=rule_id,
                        severity=Severity.STYLE,
                        confidence=Confidence.CERTAIN,
                        location=SourceLocation(segment.file.relative_path, line, column),
                        message=f"Use the base verb after '{match.group(1)}'.",
                        details=f"'{wrong}' is inflected, but this construction requires the base form.",
                        suggestion=f"Use '{base}'.",
                        evidence=[self._line_evidence(segment.file, line)],
                        tags=["grammar", "tense", segment.kind],
                    )
                )
        return findings

    @staticmethod
    def _confidence(value: str) -> Confidence:
        return {
            "low": Confidence.LOW,
            "medium": Confidence.MEDIUM,
            "high": Confidence.HIGH,
            "certain": Confidence.CERTAIN,
        }.get(value.casefold(), Confidence.HIGH)

    @staticmethod
    def _line_evidence(source: SourceFileContext, line: int) -> str:
        return source.line_text(line).strip()

    @staticmethod
    def _deduplicate(findings: list[Finding]) -> list[Finding]:
        result: list[Finding] = []
        seen: set[tuple[str, str, int, int, str]] = set()
        for finding in findings:
            key = (
                finding.rule,
                finding.location.file,
                finding.location.line,
                finding.location.column,
                finding.message,
            )
            if key not in seen:
                seen.add(key)
                result.append(finding)
        return result
