"""Comment/string spelling and lightweight grammar checker."""
