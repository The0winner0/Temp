from __future__ import annotations

from typing import Any, Mapping

from core.api import Checker, CheckerMetadata
from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.source_context import ProjectContext

from .analyzer import LanguageAnalyzer
from .rules import load_dictionary


class LanguageChecker(Checker):
    metadata = CheckerMetadata(
        name="language",
        description=(
            "Checks spelling in comments/string literals and a conservative set of "
            "high-confidence English grammar mistakes using only local dictionaries."
        ),
        version="1.0",
    )

    def run(self, context: ProjectContext, config: Mapping[str, Any]) -> list[Finding]:
        dictionary, loaded_files = load_dictionary()
        if bool(config.get("check_spelling", True)) and not dictionary:
            file = context.files[0].relative_path if context.files else "<project>"
            return [
                Finding(
                    checker="language",
                    rule="LANG000",
                    severity=Severity.ERROR,
                    confidence=Confidence.CERTAIN,
                    location=SourceLocation(file=file, line=1, column=1),
                    message="No spelling dictionary was found.",
                    details=(
                        "The language checker treats every .txt file below checks/language/ "
                        "as a newline-delimited dictionary, but none contained words."
                    ),
                    suggestion="Add one or more .txt dictionary files under checks/language/.",
                    tags=["configuration", "spelling"],
                )
            ]
        return LanguageAnalyzer(config, dictionary, loaded_files).analyze(context)


def create_checker() -> Checker:
    return LanguageChecker()
