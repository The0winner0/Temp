# Expression Clarity Checker

`expression_clarity` checks whether mixed-precedence expressions use enough explicit parentheses for a reader to understand grouping without remembering C/C++ operator precedence.

It is intentionally a readability/correctness guard, not a formatter and not a replacement for `semantic_safety`.

## Core rule

A visible expression group should normally contain operators from only one precedence family. Parentheses create a new group.

Allowed by default:

```cpp
if (a + b + c + d) { }
if (a * b / c * d) { }
if (a && b && c) { }
if (((a ^ b) | 1) == 1) { }
if ((a * b) + (c / d)) { }
```

Flagged by default:

```cpp
if (var1 ^ var2 | 1 == 1) { }
if (a * b + c / d) { }
if (a < b && c < d) { }
if (a && b || c) { }
if (flags & MASK == 0) { }
if (x << n + 1) { }
```

The checker does **not** guess the intended grouping. For a flagged expression it asks the developer to add parentheses until the intended grouping is explicit.

Function-call arguments are analyzed independently, so this does not create a false mix across arguments:

```cpp
if (foo(a + b, c * d)) { }
```

but this is still checked inside one argument:

```cpp
if (foo(a + b * c)) { }  // flagged
```

## Configuration

```json
"expression_clarity": {
  "enabled": true,
  "target_cpp": null,
  "check_if": true,
  "check_while": true,
  "check_for_condition": true,
  "check_switch": false,
  "check_return_expressions": false,
  "check_assignment_rhs": false,
  "require_comparison_grouping_in_logical": true,
  "require_bitwise_grouping": true,
  "require_arithmetic_grouping": true,
  "require_ternary_grouping": true,
  "analyze_header_definitions": false,
  "max_expression_tokens": 512
}
```

With `target_cpp: null`, all supplied implementation files are checked. Set a path, filename, unique stem, or list to limit diagnostics.

`check_return_expressions` and `check_assignment_rhs` are implemented but disabled by default because condition expressions are the primary use case and enabling every calculation can be intentionally strict.

## Rule IDs

- `EXPR101` — general mixed-precedence grouping
- `EXPR102` — bitwise/comparison/logical precedence ambiguity
- `EXPR103` — ternary mixed with another precedence level
- `EXPR104` — comparison mixed with logical operators without grouping
- `EXPR105` — arithmetic/shift precedence mixed without grouping
