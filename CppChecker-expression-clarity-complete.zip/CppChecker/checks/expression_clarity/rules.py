from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


# Higher number means tighter binding. The checker does not try to re-evaluate
# C++; it only needs stable precedence families for readability grouping.
PRECEDENCE_GROUPS: dict[str, tuple[str, int]] = {
    "*": ("multiplicative", 12),
    "/": ("multiplicative", 12),
    "%": ("multiplicative", 12),
    "+": ("additive", 11),
    "-": ("additive", 11),
    "<<": ("shift", 10),
    ">>": ("shift", 10),
    "<": ("relational", 9),
    "<=": ("relational", 9),
    ">": ("relational", 9),
    ">=": ("relational", 9),
    "==": ("equality", 8),
    "!=": ("equality", 8),
    "&": ("bitwise_and", 7),
    "^": ("bitwise_xor", 6),
    "|": ("bitwise_or", 5),
    "&&": ("logical_and", 4),
    "||": ("logical_or", 3),
    "?": ("conditional", 2),
    ":": ("conditional", 2),
    "=": ("assignment", 1),
    "+=": ("assignment", 1),
    "-=": ("assignment", 1),
    "*=": ("assignment", 1),
    "/=": ("assignment", 1),
    "%=": ("assignment", 1),
    "<<=": ("assignment", 1),
    ">>=": ("assignment", 1),
    "&=": ("assignment", 1),
    "^=": ("assignment", 1),
    "|=": ("assignment", 1),
}

BITWISE_GROUPS = {"bitwise_and", "bitwise_xor", "bitwise_or"}
COMPARISON_GROUPS = {"relational", "equality"}
LOGICAL_GROUPS = {"logical_and", "logical_or"}
ARITHMETIC_GROUPS = {"multiplicative", "additive", "shift"}


@dataclass(frozen=True, slots=True)
class ExpressionClarityRules:
    check_if: bool
    check_while: bool
    check_for_condition: bool
    check_switch: bool
    check_return_expressions: bool
    check_assignment_rhs: bool
    require_comparison_grouping_in_logical: bool
    require_bitwise_grouping: bool
    require_arithmetic_grouping: bool
    require_ternary_grouping: bool
    analyze_header_definitions: bool
    max_expression_tokens: int


def compile_rules(config: Mapping[str, Any]) -> ExpressionClarityRules:
    return ExpressionClarityRules(
        check_if=bool(config.get("check_if", True)),
        check_while=bool(config.get("check_while", True)),
        check_for_condition=bool(config.get("check_for_condition", True)),
        check_switch=bool(config.get("check_switch", False)),
        check_return_expressions=bool(config.get("check_return_expressions", False)),
        check_assignment_rhs=bool(config.get("check_assignment_rhs", False)),
        require_comparison_grouping_in_logical=bool(
            config.get("require_comparison_grouping_in_logical", True)
        ),
        require_bitwise_grouping=bool(config.get("require_bitwise_grouping", True)),
        require_arithmetic_grouping=bool(config.get("require_arithmetic_grouping", True)),
        require_ternary_grouping=bool(config.get("require_ternary_grouping", True)),
        analyze_header_definitions=bool(config.get("analyze_header_definitions", False)),
        max_expression_tokens=max(16, int(config.get("max_expression_tokens", 512))),
    )
