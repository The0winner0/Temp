"""Expression-parenthesization readability checker."""
