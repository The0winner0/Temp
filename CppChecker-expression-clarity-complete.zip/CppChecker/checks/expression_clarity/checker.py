from __future__ import annotations

from typing import Any, Mapping

from core.api import Checker, CheckerMetadata
from core.diagnostics import Finding
from core.source_context import ProjectContext

from .analyzer import ExpressionClarityAnalyzer
from .rules import compile_rules


class ExpressionClarityChecker(Checker):
    metadata = CheckerMetadata(
        name="expression_clarity",
        description=(
            "Requires explicit grouping for mixed-precedence C/C++ expressions so "
            "the intended evaluation order is visible without relying on precedence memory."
        ),
        version="1.0",
    )

    def run(self, context: ProjectContext, config: Mapping[str, Any]) -> list[Finding]:
        rules = compile_rules(config)
        return ExpressionClarityAnalyzer(config, rules).analyze(context)


def create_checker() -> Checker:
    return ExpressionClarityChecker()
