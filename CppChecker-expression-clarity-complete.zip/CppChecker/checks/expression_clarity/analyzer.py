from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any, Mapping, Sequence

from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.source_context import ProjectContext, SourceFileContext
from core.tokenizer import Token, TokenKind

from .rules import (
    ARITHMETIC_GROUPS,
    BITWISE_GROUPS,
    COMPARISON_GROUPS,
    LOGICAL_GROUPS,
    PRECEDENCE_GROUPS,
    ExpressionClarityRules,
)


_CPP_EXTENSIONS = {".c", ".cc", ".cpp", ".cxx"}
_HEADER_EXTENSIONS = {".h", ".hh", ".hpp", ".hxx"}
_SKIP_KINDS = {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}
_CAST_KEYWORDS = {"static_cast", "reinterpret_cast", "const_cast", "dynamic_cast"}
_CONTROL_KEYWORDS = {"if", "while", "for", "switch"}
_ASSIGNMENT_OPS = {"=", "+=", "-=", "*=", "/=", "%=", "<<=", ">>=", "&=", "^=", "|="}


@dataclass(frozen=True, slots=True)
class OperatorUse:
    token: Token
    operator: str
    group: str
    precedence: int


@dataclass(frozen=True, slots=True)
class ExpressionSite:
    kind: str
    file: SourceFileContext
    tokens: tuple[Token, ...]


class ExpressionClarityAnalyzer:
    def __init__(self, config: Mapping[str, Any], rules: ExpressionClarityRules) -> None:
        self.config = config
        self.rules = rules
        self.findings: list[Finding] = []
        self._reported: set[tuple[str, int, int, str]] = set()

    def analyze(self, context: ProjectContext) -> list[Finding]:
        sources, issue = self._resolve_target_sources(context)
        if issue is not None:
            return [issue]

        if self.rules.analyze_header_definitions:
            sources = sources + [
                source
                for source in context.files
                if source.path.suffix.lower() in _HEADER_EXTENSIONS
            ]

        for source in sources:
            tokens = tuple(t for t in source.tokens if t.kind not in _SKIP_KINDS)
            for site in self._condition_sites(source, tokens):
                self._analyze_expression(site, site.tokens)

            if self.rules.check_return_expressions or self.rules.check_assignment_rhs:
                self._scan_statement_expressions(source, tokens)

        return self.findings

    # ------------------------------------------------------------------
    # Source selection
    # ------------------------------------------------------------------

    def _resolve_target_sources(
        self, context: ProjectContext
    ) -> tuple[list[SourceFileContext], Finding | None]:
        cpp_files = [f for f in context.files if f.path.suffix.lower() in _CPP_EXTENSIONS]
        requested = self.config.get("target_cpp")
        if not requested:
            return cpp_files, None

        raw_items = requested if isinstance(requested, list) else [requested]
        selected: list[SourceFileContext] = []
        unresolved: list[str] = []
        for raw in raw_items:
            text = str(raw).replace("\\", "/").strip()
            if not text:
                continue
            lower = text.lower()
            matches = [
                source
                for source in cpp_files
                if source.relative_path.lower() == lower
                or PurePosixPath(source.relative_path).name.lower() == lower
                or PurePosixPath(source.relative_path).stem.lower() == lower
            ]
            if len(matches) == 1:
                if matches[0] not in selected:
                    selected.append(matches[0])
            else:
                unresolved.append(text)

        if selected and not unresolved:
            return selected, None

        file = context.files[0].relative_path if context.files else "<project>"
        return [], Finding(
            checker="expression_clarity",
            rule="EXPR000",
            severity=Severity.INFO,
            confidence=Confidence.CERTAIN,
            location=SourceLocation(file=file, line=1, column=1),
            message="Expression-clarity analysis was skipped because target_cpp could not be resolved uniquely.",
            details="Unresolved target(s): " + ", ".join(unresolved or [str(x) for x in raw_items]),
            suggestion="Set checks.expression_clarity.target_cpp to a unique .cpp path, filename, or stem.",
            tags=["configuration", "scope"],
        )

    # ------------------------------------------------------------------
    # Expression-site discovery
    # ------------------------------------------------------------------

    def _condition_sites(
        self, source: SourceFileContext, tokens: Sequence[Token]
    ) -> list[ExpressionSite]:
        out: list[ExpressionSite] = []
        i = 0
        while i < len(tokens):
            token = tokens[i]
            if token.kind != TokenKind.IDENTIFIER or token.value not in _CONTROL_KEYWORDS:
                i += 1
                continue

            keyword = token.value
            enabled = (
                (keyword == "if" and self.rules.check_if)
                or (keyword == "while" and self.rules.check_while)
                or (keyword == "for" and self.rules.check_for_condition)
                or (keyword == "switch" and self.rules.check_switch)
            )
            if not enabled:
                i += 1
                continue

            open_index = self._find_open_paren(tokens, i + 1)
            if open_index is None:
                i += 1
                continue
            close_index = self._matching(tokens, open_index, "(", ")")
            if close_index is None:
                i += 1
                continue

            content = tuple(tokens[open_index + 1 : close_index])
            if keyword == "for":
                parts = self._split_top_level(content, ";")
                if len(parts) == 3 and parts[1]:
                    out.append(ExpressionSite("for-condition", source, tuple(parts[1])))
            elif content:
                out.append(ExpressionSite(keyword, source, content))
            i = open_index + 1
        return out

    @staticmethod
    def _find_open_paren(tokens: Sequence[Token], start: int) -> int | None:
        # Supports `if constexpr (...)` and leaves unusual constructs alone.
        for i in range(start, min(len(tokens), start + 5)):
            if tokens[i].value == "(":
                return i
            if tokens[i].value in {";", "{", "}"}:
                break
        return None

    def _scan_statement_expressions(
        self, source: SourceFileContext, tokens: Sequence[Token]
    ) -> None:
        if self.rules.check_return_expressions:
            i = 0
            while i < len(tokens):
                if tokens[i].kind == TokenKind.IDENTIFIER and tokens[i].value == "return":
                    end = self._find_statement_end(tokens, i + 1)
                    if end is not None and end > i + 1:
                        expr = tuple(tokens[i + 1 : end])
                        self._analyze_expression(ExpressionSite("return", source, expr), expr)
                        i = end
                i += 1

        if self.rules.check_assignment_rhs:
            for i, token in enumerate(tokens):
                if token.value not in _ASSIGNMENT_OPS:
                    continue
                if not self._is_binary_operator(tokens, i):
                    continue
                end = self._find_statement_end(tokens, i + 1)
                if end is None or end <= i + 1:
                    continue
                expr = tuple(tokens[i + 1 : end])
                self._analyze_expression(ExpressionSite("assignment-rhs", source, expr), expr)

    @staticmethod
    def _find_statement_end(tokens: Sequence[Token], start: int) -> int | None:
        paren = bracket = brace = 0
        for i in range(start, len(tokens)):
            value = tokens[i].value
            if value == "(":
                paren += 1
            elif value == ")":
                if paren > 0:
                    paren -= 1
            elif value == "[":
                bracket += 1
            elif value == "]":
                if bracket > 0:
                    bracket -= 1
            elif value == "{":
                brace += 1
            elif value == "}":
                if brace > 0:
                    brace -= 1
            elif value == ";" and paren == bracket == brace == 0:
                return i
        return None

    # ------------------------------------------------------------------
    # Readability analysis
    # ------------------------------------------------------------------

    def _analyze_expression(self, site: ExpressionSite, tokens: Sequence[Token]) -> None:
        if not tokens or len(tokens) > self.rules.max_expression_tokens:
            return
        self._analyze_region(site, tuple(tokens), depth=0)

    def _analyze_region(
        self, site: ExpressionSite, tokens: tuple[Token, ...], *, depth: int
    ) -> None:
        if not tokens or depth > 32:
            return

        # Top-level commas are usually function arguments or initializer elements.
        # Treat each as an independent expression instead of comparing precedence
        # across unrelated arguments.
        comma_parts = self._split_top_level(tokens, ",")
        if len(comma_parts) > 1:
            for part in comma_parts:
                if part:
                    self._analyze_region(site, tuple(part), depth=depth + 1)
            self._recurse_nested(site, tokens, depth)
            return

        masked = self._template_angle_mask(tokens)
        operators: list[OperatorUse] = []
        paren = bracket = brace = 0
        i = 0
        while i < len(tokens):
            value = tokens[i].value
            if value == "(":
                paren += 1
            elif value == ")":
                paren = max(0, paren - 1)
            elif value == "[":
                bracket += 1
            elif value == "]":
                bracket = max(0, bracket - 1)
            elif value == "{":
                brace += 1
            elif value == "}":
                brace = max(0, brace - 1)
            elif paren == bracket == brace == 0 and i not in masked:
                info = PRECEDENCE_GROUPS.get(value)
                if info is not None and self._is_binary_or_ternary(tokens, i):
                    operators.append(OperatorUse(tokens[i], value, info[0], info[1]))
            i += 1

        finding = self._classify_mix(site, tokens, operators)
        if finding is not None:
            self._emit(finding)

        self._recurse_nested(site, tokens, depth)

    def _recurse_nested(
        self, site: ExpressionSite, tokens: tuple[Token, ...], depth: int
    ) -> None:
        i = 0
        while i < len(tokens):
            value = tokens[i].value
            if value in {"(", "["}:
                close_char = ")" if value == "(" else "]"
                close = self._matching(tokens, i, value, close_char)
                if close is None:
                    i += 1
                    continue
                inner = tuple(tokens[i + 1 : close])
                if inner:
                    self._analyze_region(site, inner, depth=depth + 1)
                i = close + 1
                continue
            i += 1

    def _classify_mix(
        self,
        site: ExpressionSite,
        tokens: Sequence[Token],
        operators: Sequence[OperatorUse],
    ) -> Finding | None:
        groups = {op.group for op in operators}
        if len(groups) <= 1:
            return None

        # Assignment is handled as a correctness issue elsewhere. If it appears
        # together with other groups, readability is still poor, but suppress it
        # here to avoid duplicating the semantic-safety assignment-in-condition rule.
        non_assignment = groups - {"assignment"}
        if len(non_assignment) <= 1:
            return None
        groups = non_assignment
        operators = [op for op in operators if op.group != "assignment"]

        rule = "EXPR101"
        severity = Severity.STYLE
        confidence = Confidence.HIGH
        reason = "The expression mixes operator precedence levels without explicit grouping."

        if self.rules.require_bitwise_grouping and groups & BITWISE_GROUPS and (
            groups & COMPARISON_GROUPS
            or groups & LOGICAL_GROUPS
            or len(groups & BITWISE_GROUPS) > 1
        ):
            rule = "EXPR102"
            severity = Severity.WARNING
            confidence = Confidence.HIGH
            reason = (
                "Bitwise operators are mixed with comparison/logical operators or with "
                "another bitwise precedence level without explicit grouping."
            )
        elif self.rules.require_ternary_grouping and "conditional" in groups:
            rule = "EXPR103"
            reason = "A conditional (?:) expression is mixed with another precedence level without grouping."
        elif self.rules.require_comparison_grouping_in_logical and (
            groups & COMPARISON_GROUPS and groups & LOGICAL_GROUPS
        ):
            rule = "EXPR104"
            reason = (
                "Comparison and logical operators are mixed without parentheses around "
                "the comparison/logical groups."
            )
        elif self.rules.require_arithmetic_grouping and len(groups & ARITHMETIC_GROUPS) > 1:
            rule = "EXPR105"
            reason = "Arithmetic/shift operators from different precedence levels are mixed without grouping."
        else:
            # If a configurable category is disabled and no other risky mix remains,
            # do not emit a generic warning for that same category.
            if groups <= ARITHMETIC_GROUPS and not self.rules.require_arithmetic_grouping:
                return None
            if groups <= (COMPARISON_GROUPS | LOGICAL_GROUPS) and not self.rules.require_comparison_grouping_in_logical:
                return None
            if groups <= BITWISE_GROUPS and not self.rules.require_bitwise_grouping:
                return None

        first = operators[0].token
        expression = self._render(tokens)
        operator_text = ", ".join(op.operator for op in operators)
        group_text = ", ".join(sorted(groups, key=self._group_sort_key, reverse=True))
        return Finding(
            checker="expression_clarity",
            rule=rule,
            severity=severity,
            confidence=confidence,
            location=SourceLocation(
                file=site.file.relative_path,
                line=first.line,
                column=first.column,
            ),
            message="Mixed-precedence expression should use explicit parentheses.",
            details=(
                f"{reason} Context: {site.kind}. Operators: {operator_text}. "
                f"Precedence groups: {group_text}.\nExpression: {expression}"
            ),
            suggestion=(
                "Add parentheses around the intended subexpressions until each visible "
                "group contains only one precedence level. The checker does not guess "
                "which grouping you intended."
            ),
            evidence=[expression],
            tags=["readability", "precedence", "parentheses"],
            metadata={
                "context": site.kind,
                "operators": [op.operator for op in operators],
                "groups": sorted(groups),
            },
        )

    @staticmethod
    def _group_sort_key(group: str) -> int:
        values = [p for _, (g, p) in PRECEDENCE_GROUPS.items() if g == group]
        return max(values) if values else 0

    def _emit(self, finding: Finding) -> None:
        key = (
            finding.location.file,
            finding.location.line,
            finding.location.column,
            finding.rule,
        )
        if key in self._reported:
            return
        self._reported.add(key)
        self.findings.append(finding)

    # ------------------------------------------------------------------
    # Token helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _render(tokens: Sequence[Token]) -> str:
        if not tokens:
            return ""
        out: list[str] = []
        no_space_before = {")", "]", ",", ";", ":"}
        no_space_after = {"(", "[", "::", ".", "->"}
        tight = {"::", ".", "->"}
        for token in tokens:
            value = token.value
            if not out:
                out.append(value)
                continue
            prev = tokens[len(out) - 1].value if len(out) - 1 < len(tokens) else ""
            if value in no_space_before or prev in no_space_after or value in tight or prev in tight:
                out.append(value)
            else:
                out.append(" " + value)
        text = "".join(out)
        return " ".join(text.split())

    @staticmethod
    def _split_top_level(tokens: Sequence[Token], delimiter: str) -> list[list[Token]]:
        parts: list[list[Token]] = [[]]
        paren = bracket = brace = 0
        for token in tokens:
            value = token.value
            if value == "(":
                paren += 1
            elif value == ")":
                paren = max(0, paren - 1)
            elif value == "[":
                bracket += 1
            elif value == "]":
                bracket = max(0, bracket - 1)
            elif value == "{":
                brace += 1
            elif value == "}":
                brace = max(0, brace - 1)
            if value == delimiter and paren == bracket == brace == 0:
                parts.append([])
            else:
                parts[-1].append(token)
        return parts

    @staticmethod
    def _matching(
        tokens: Sequence[Token], start: int, open_char: str, close_char: str
    ) -> int | None:
        if start >= len(tokens) or tokens[start].value != open_char:
            return None
        depth = 0
        for i in range(start, len(tokens)):
            value = tokens[i].value
            if value == open_char:
                depth += 1
            elif value == close_char:
                depth -= 1
                if depth == 0:
                    return i
        return None

    @staticmethod
    def _looks_like_type_only_group(tokens: Sequence[Token]) -> bool:
        if not tokens:
            return False
        allowed_ops = {"*", "&", "&&", "::", "<", ">", ","}
        for token in tokens:
            if token.kind == TokenKind.IDENTIFIER:
                continue
            if token.value in allowed_ops:
                continue
            return False
        return True

    def _template_angle_mask(self, tokens: Sequence[Token]) -> set[int]:
        masked: set[int] = set()
        i = 0
        while i < len(tokens):
            if tokens[i].value != "<":
                i += 1
                continue
            prev = tokens[i - 1] if i > 0 else None
            if prev is None or not (
                prev.kind == TokenKind.IDENTIFIER
                or prev.value in {">", ">>", "::"}
            ):
                i += 1
                continue
            # Comparison `a < b` normally has no template-style closing `>` followed
            # by call/scope syntax. Require a strong suffix signal before masking.
            depth = 0
            match = None
            for j in range(i, min(len(tokens), i + 64)):
                value = tokens[j].value
                if value == "<":
                    depth += 1
                elif value == ">":
                    depth -= 1
                    if depth == 0:
                        match = j
                        break
                elif value == ">>":
                    if depth >= 2:
                        depth -= 2
                        if depth == 0:
                            match = j
                            break
                elif value in {";", "&&", "||"} and depth == 1:
                    break
            if match is None:
                i += 1
                continue
            next_value = tokens[match + 1].value if match + 1 < len(tokens) else ""
            if next_value not in {"(", "::", "{", "["} and prev.value not in _CAST_KEYWORDS:
                i += 1
                continue
            masked.update(range(i, match + 1))
            i = match + 1
        return masked

    def _is_binary_or_ternary(self, tokens: Sequence[Token], index: int) -> bool:
        value = tokens[index].value
        if value in {"?", ":"}:
            return True
        return self._is_binary_operator(tokens, index)

    @staticmethod
    def _is_binary_operator(tokens: Sequence[Token], index: int) -> bool:
        value = tokens[index].value
        if value not in PRECEDENCE_GROUPS:
            return False
        if value in {"?", ":"}:
            return True
        if value in {"++", "--"}:
            return False

        # Operators with no common unary role are binary here.
        if value not in {"+", "-", "*", "&"}:
            return True

        if index == 0:
            return False
        prev = tokens[index - 1]
        if prev.value in {
            "(", "[", "{", ",", ";", "?", ":", "=", "+=", "-=", "*=", "/=", "%=",
            "&&", "||", "!", "~", "+", "-", "*", "/", "%", "&", "|", "^", "<<", ">>",
            "<", ">", "<=", ">=", "==", "!=",
        }:
            return False
        return True
