# Checker packages

Concrete checks live under `checks/<checker_name>/`.

Use `_template/` as the starting point. A checker should normally stay self-contained:

```text
checks/<name>/
├── __init__.py
├── checker.py
├── analyzer.py
└── rules.py      # optional
```

`checker.py` is the stable adapter to the core API. Domain logic stays in `analyzer.py`; checker-specific constants/configuration helpers stay in `rules.py`.

Do not modify `main.py` to add a checker. Add an entry to `checker_config.json`:

```json
{
  "checks": {
    "my_checker": {
      "enabled": true
    }
  }
}
```

Every checker returns `core.diagnostics.Finding` objects. If a checker cannot analyze an ambiguous construct confidently, it should skip that case or emit a lower-confidence finding rather than guessing.
