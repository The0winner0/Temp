from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Mapping


# Defaults are intentionally conventional and easy to replace in checker_config.json.
# Set a rule to null/"" to disable naming validation for that category.
DEFAULT_NAME_PATTERNS: dict[str, str] = {
    "local_variable": r"^[a-z][a-z0-9_]*$",
    "parameter": r"^[a-z][a-z0-9_]*$",
    "class_field": r"^[a-z][a-z0-9_]*$",
    "static_class_field": r"^[a-z][a-z0-9_]*$",
    "global_variable": r"^[a-z][a-z0-9_]*$",
    "static_global_variable": r"^[a-z][a-z0-9_]*$",
    "local_constant": r"^[A-Z][A-Z0-9_]*$",
    "class_constant": r"^[A-Z][A-Z0-9_]*$",
    "global_constant": r"^[A-Z][A-Z0-9_]*$",
    "free_function": r"^[a-z][a-z0-9_]*$",
    "member_function": r"^[a-z][a-z0-9_]*$",
}


# Identifier keywords/literals which can appear in a function body but can never be
# undeclared variables. Keep this broad because the undeclared check is deliberately
# conservative: silence is preferable to a noisy false positive.
CPP_KEYWORDS = {
    "alignas", "alignof", "and", "and_eq", "asm", "auto", "bitand", "bitor",
    "bool", "break", "case", "catch", "char", "char8_t", "char16_t", "char32_t",
    "class", "compl", "concept", "const", "consteval", "constexpr", "constinit",
    "const_cast", "continue", "co_await", "co_return", "co_yield", "decltype",
    "default", "delete", "do", "double", "dynamic_cast", "else", "enum", "explicit",
    "export", "extern", "false", "float", "for", "friend", "goto", "if", "inline",
    "int", "long", "mutable", "namespace", "new", "noexcept", "not", "not_eq",
    "nullptr", "operator", "or", "or_eq", "private", "protected", "public", "register",
    "reinterpret_cast", "requires", "return", "short", "signed", "sizeof", "static",
    "static_assert", "static_cast", "struct", "switch", "template", "this", "thread_local",
    "throw", "true", "try", "typedef", "typeid", "typename", "union", "unsigned",
    "using", "virtual", "void", "volatile", "wchar_t", "while", "xor", "xor_eq",
}


# Common C/C++ standard integer/scalar aliases. In addition, the analyzer learns type
# names from declarations and accepts *_t identifiers in clear type positions.
COMMON_TYPE_NAMES = {
    "size_t", "ssize_t", "ptrdiff_t", "max_align_t",
    "int8_t", "uint8_t", "int16_t", "uint16_t", "int32_t", "uint32_t",
    "int64_t", "uint64_t", "int_least8_t", "uint_least8_t", "int_least16_t",
    "uint_least16_t", "int_least32_t", "uint_least32_t", "int_least64_t",
    "uint_least64_t", "int_fast8_t", "uint_fast8_t", "int_fast16_t", "uint_fast16_t",
    "int_fast32_t", "uint_fast32_t", "int_fast64_t", "uint_fast64_t",
    "intptr_t", "uintptr_t", "intmax_t", "uintmax_t", "int_t", "uint_t", "unit_t",
    "clock_t", "time_t", "wint_t", "sig_atomic_t", "va_list",
}


@dataclass(frozen=True, slots=True)
class CompiledNamingRules:
    patterns: dict[str, re.Pattern[str]]
    source_patterns: dict[str, str]
    ignore_identifiers: frozenset[str]
    ignore_name_patterns: tuple[re.Pattern[str], ...]
    check_naming: bool
    check_unused: bool
    check_unused_parameters: bool
    check_undeclared: bool
    analyze_header_definitions: bool


def compile_rules(config: Mapping[str, Any]) -> CompiledNamingRules:
    raw_rules = config.get("rules", {})
    if not isinstance(raw_rules, Mapping):
        raw_rules = {}

    merged: dict[str, str] = dict(DEFAULT_NAME_PATTERNS)
    for key, value in raw_rules.items():
        if value is None or value == "":
            merged.pop(str(key), None)
        else:
            merged[str(key)] = str(value)

    compiled = {name: re.compile(pattern) for name, pattern in merged.items()}

    ignore = {str(x) for x in config.get("ignore_identifiers", [])}
    # Common intentional throw-away names. These are ignored by naming/unused checks.
    ignore.update({"_"})

    raw_ignore_patterns = config.get("ignore_name_patterns", [])
    ignore_patterns = tuple(re.compile(str(p)) for p in raw_ignore_patterns)

    return CompiledNamingRules(
        patterns=compiled,
        source_patterns=merged,
        ignore_identifiers=frozenset(ignore),
        ignore_name_patterns=ignore_patterns,
        check_naming=bool(config.get("check_naming", True)),
        check_unused=bool(config.get("check_unused", True)),
        check_unused_parameters=bool(config.get("check_unused_parameters", True)),
        check_undeclared=bool(config.get("check_undeclared", True)),
        analyze_header_definitions=bool(config.get("analyze_header_definitions", False)),
    )


def ignored_name(name: str, rules: CompiledNamingRules) -> bool:
    if name in rules.ignore_identifiers:
        return True
    return any(pattern.search(name) for pattern in rules.ignore_name_patterns)
