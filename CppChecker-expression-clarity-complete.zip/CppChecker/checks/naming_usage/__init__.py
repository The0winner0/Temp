"""Configurable variable/function naming and variable-usage checker."""
