from __future__ import annotations

from typing import Any, Mapping

from core.api import Checker, CheckerMetadata
from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.source_context import ProjectContext

from .analyzer import NamingUsageAnalyzer
from .rules import compile_rules


class NamingUsageChecker(Checker):
    metadata = CheckerMetadata(
        name="naming_usage",
        description=(
            "Checks configurable variable/function naming, declarations that are never used, "
            "and high-confidence variable-like uses with no visible declaration."
        ),
        version="1.0",
    )

    def run(self, context: ProjectContext, config: Mapping[str, Any]) -> list[Finding]:
        try:
            rules = compile_rules(config)
        except Exception as exc:
            file = context.files[0].relative_path if context.files else "<project>"
            return [
                Finding(
                    checker="naming_usage",
                    rule="NAME000",
                    severity=Severity.ERROR,
                    confidence=Confidence.CERTAIN,
                    location=SourceLocation(file=file, line=1, column=1),
                    message="Naming/usage checker configuration is invalid.",
                    details=f"Could not compile one of the configured regular expressions: {exc}",
                    suggestion="Correct the regex in checks.naming_usage.rules.",
                    tags=["configuration", "naming"],
                )
            ]
        return NamingUsageAnalyzer(config, rules).analyze(context)


def create_checker() -> Checker:
    return NamingUsageChecker()
