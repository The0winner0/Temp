from __future__ import annotations

from dataclasses import dataclass
from pathlib import PurePosixPath
import re
from typing import Any, Iterable, Mapping, Sequence

from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.expression_utils import matching_pairs, significant_tokens, split_top_level, tokens_to_compact_text
from core.source_context import ClassInfo, FunctionInfo, ProjectContext, SourceFileContext, VariableInfo
from core.tokenizer import Token, TokenKind

from .rules import (
    COMMON_TYPE_NAMES,
    CPP_KEYWORDS,
    CompiledNamingRules,
    ignored_name,
)


_CPP_EXTENSIONS = {".c", ".cc", ".cpp", ".cxx"}
_IDENTIFIER_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
_ALL_CAPS_RE = re.compile(r"^[A-Z_][A-Z0-9_]*$")
_TYPE_SUFFIX_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*_t$")
_ASSIGNMENTS = {"=", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<=", ">>="}
_TYPE_KEYWORDS = {"void", "bool", "char", "char8_t", "char16_t", "char32_t", "wchar_t", "short", "int", "long", "float", "double", "signed", "unsigned", "auto"}
_MEMBER_ACCESS = {".", "->"}
_QUALIFIERS = {
    "const", "constexpr", "volatile", "static", "extern", "mutable", "register",
    "inline", "thread_local", "signed", "unsigned", "short", "long", "typename",
}


@dataclass(frozen=True, slots=True)
class _ExtraDeclaration:
    variable: VariableInfo
    token_index: int


@dataclass(slots=True)
class _KnownNames:
    types: set[str]
    macros: set[str]
    enum_values: set[str]
    function_names: set[str]
    aliases: set[str]

    @property
    def non_variables(self) -> set[str]:
        return self.types | self.macros | self.enum_values | self.function_names | self.aliases | CPP_KEYWORDS


class NamingUsageAnalyzer:
    def __init__(self, config: Mapping[str, Any], rules: CompiledNamingRules) -> None:
        self.config = config
        self.rules = rules
        self.findings: list[Finding] = []
        self._reported: set[tuple[str, str, int, int, str]] = set()

    def analyze(self, context: ProjectContext) -> list[Finding]:
        target_sources, error = self._resolve_target_sources(context)
        if error is not None:
            return [error]

        known = self._collect_known_names(context)
        target_paths = {source.relative_path for source in target_sources}
        functions = [
            fn for fn in context.function_definitions
            if fn.file in target_paths
            or (self.rules.analyze_header_definitions and PurePosixPath(fn.file).suffix.lower() not in _CPP_EXTENSIONS)
        ]

        extra_by_function: dict[int, list[_ExtraDeclaration]] = {}
        for fn in functions:
            source = context.source_file(fn.file)
            if source is None:
                continue
            extras = self._extra_local_declarations(source, fn, known.types)
            extra_by_function[id(fn)] = extras
            for extra in extras:
                known.types.update(self._type_words(extra.variable.type_text))

        classes = self._selected_classes(context, target_sources, functions)
        globals_to_check = [
            var for source in target_sources for var in source.global_variables
            if "extern" not in self._type_words(var.type_text)
        ]

        if self.rules.check_naming:
            self._check_function_names(context, functions)
            self._check_variable_names(functions, extra_by_function, classes, globals_to_check)

        if self.rules.check_unused:
            self._check_function_unused(context, functions, extra_by_function)
            self._check_field_unused(context, classes)
            self._check_global_unused(context, globals_to_check)

        if self.rules.check_undeclared:
            self._check_undeclared(context, functions, extra_by_function, known)

        return self.findings

    # ------------------------------------------------------------------
    # Target/module selection
    # ------------------------------------------------------------------

    def _resolve_target_sources(
        self, context: ProjectContext
    ) -> tuple[list[SourceFileContext], Finding | None]:
        cpp_files = [f for f in context.files if f.path.suffix.lower() in _CPP_EXTENSIONS]
        requested = self.config.get("target_cpp")
        if not requested:
            return cpp_files, None

        raw_items = requested if isinstance(requested, list) else [requested]
        selected: list[SourceFileContext] = []
        unresolved: list[str] = []
        for raw in raw_items:
            text = str(raw).replace("\\", "/").strip()
            if not text:
                continue
            lower = text.lower()
            matches = [
                source for source in cpp_files
                if source.relative_path.lower() == lower
                or PurePosixPath(source.relative_path).name.lower() == lower
                or PurePosixPath(source.relative_path).stem.lower() == lower
            ]
            if len(matches) == 1:
                if matches[0] not in selected:
                    selected.append(matches[0])
            else:
                unresolved.append(text)

        if selected and not unresolved:
            return selected, None

        file = context.files[0].relative_path if context.files else "<project>"
        return [], Finding(
            checker="naming_usage",
            rule="NAME001",
            severity=Severity.INFO,
            confidence=Confidence.CERTAIN,
            location=SourceLocation(file=file, line=1, column=1),
            message="Naming/usage analysis was skipped because target_cpp could not be resolved uniquely.",
            details="Unresolved target(s): " + ", ".join(unresolved or [str(x) for x in raw_items]),
            suggestion="Set checks.naming_usage.target_cpp to a unique .cpp path, filename, or stem.",
            tags=["configuration", "scope"],
        )

    def _selected_classes(
        self,
        context: ProjectContext,
        target_sources: Sequence[SourceFileContext],
        functions: Sequence[FunctionInfo],
    ) -> list[ClassInfo]:
        # With no explicit target, all supplied classes are part of the small program.
        if not self.config.get("target_cpp"):
            return list(context.classes)

        owner_names = {fn.owner_class for fn in functions if fn.owner_class}
        target_tokens = {
            token.value
            for source in target_sources
            for token in source.tokens
            if token.kind == TokenKind.IDENTIFIER
        }
        out: list[ClassInfo] = []
        seen: set[tuple[str, str, int]] = set()
        for cls in context.classes:
            if cls.name not in owner_names and cls.name not in target_tokens:
                continue
            key = (cls.file, cls.name, cls.start_line)
            if key not in seen:
                seen.add(key)
                out.append(cls)
        return out

    # ------------------------------------------------------------------
    # Naming
    # ------------------------------------------------------------------

    def _check_function_names(self, context: ProjectContext, functions: Sequence[FunctionInfo]) -> None:
        seen: set[tuple[str | None, str]] = set()
        for fn in functions:
            if fn.is_constructor or fn.is_destructor or fn.name.startswith("operator") or ignored_name(fn.name, self.rules):
                continue
            category = "member_function" if fn.owner_class else "free_function"
            pattern = self.rules.patterns.get(category)
            if pattern is None:
                continue
            key = (fn.owner_class, fn.name)
            if key in seen:
                continue
            seen.add(key)
            if pattern.fullmatch(fn.name):
                continue
            source = context.source_file(fn.file)
            line, column = self._function_name_location(source, fn)
            self._emit(
                rule="NAME101",
                severity=Severity.STYLE,
                confidence=Confidence.CERTAIN,
                file=fn.file,
                line=line,
                column=column,
                message=f"{category.replace('_', ' ').title()} '{fn.name}' does not match its naming rule.",
                details=f"Configured regex for {category}: {self.rules.source_patterns[category]}",
                suggestion="Rename the function or update the configured regex if this spelling is intentional.",
                tags=["naming", "function", category],
                metadata={"symbol": fn.name, "category": category, "regex": self.rules.source_patterns[category]},
            )

    def _check_variable_names(
        self,
        functions: Sequence[FunctionInfo],
        extra_by_function: Mapping[int, list[_ExtraDeclaration]],
        classes: Sequence[ClassInfo],
        globals_to_check: Sequence[VariableInfo],
    ) -> None:
        variables: list[VariableInfo] = []
        for fn in functions:
            variables.extend(self._unique_variables(fn.local_variables))
            variables.extend(extra.variable for extra in extra_by_function.get(id(fn), []))
        for cls in classes:
            variables.extend(self._unique_variables(cls.fields))
        variables.extend(self._unique_variables(globals_to_check))

        seen: set[tuple[str, int, int, str]] = set()
        for var in variables:
            key = (var.file, var.line, var.column, var.name)
            if key in seen:
                continue
            seen.add(key)
            if ignored_name(var.name, self.rules):
                continue
            category = self._naming_category(var)
            pattern = self.rules.patterns.get(category)
            if pattern is None or pattern.fullmatch(var.name):
                continue
            self._emit(
                rule="NAME102",
                severity=Severity.STYLE,
                confidence=Confidence.CERTAIN,
                file=var.file,
                line=var.line,
                column=var.column,
                message=f"{category.replace('_', ' ').title()} '{var.name}' does not match its naming rule.",
                details=f"Type: {var.type_text or '<unknown>'}\nConfigured regex: {self.rules.source_patterns[category]}",
                suggestion="Rename the symbol or update the regex for this symbol category.",
                tags=["naming", "variable", category],
                metadata={"symbol": var.name, "category": category, "regex": self.rules.source_patterns[category]},
            )

    def _naming_category(self, var: VariableInfo) -> str:
        if var.category == "parameter":
            return "parameter"
        top_level_constant = var.constexpr or (var.const and var.pointer_depth == 0 and not var.reference)
        if var.category == "field":
            if top_level_constant:
                return "class_constant"
            return "static_class_field" if var.static else "class_field"
        if var.category == "global":
            if top_level_constant:
                return "global_constant"
            return "static_global_variable" if var.static else "global_variable"
        if top_level_constant:
            return "local_constant"
        return "local_variable"

    # ------------------------------------------------------------------
    # Unused variables
    # ------------------------------------------------------------------

    def _check_function_unused(
        self,
        context: ProjectContext,
        functions: Sequence[FunctionInfo],
        extra_by_function: Mapping[int, list[_ExtraDeclaration]],
    ) -> None:
        for fn in functions:
            source = context.source_file(fn.file)
            if source is None or fn.body_start_token < 0:
                continue
            variables = self._unique_variables(fn.local_variables)
            variables.extend(extra.variable for extra in extra_by_function.get(id(fn), []))
            variables = self._unique_variables(variables)

            # Same-name shadowing requires block-resolution to attribute a bare use safely.
            # Skip unused judgments for the ambiguous name rather than fabricate a warning.
            counts: dict[str, int] = {}
            locations_by_name: dict[str, set[tuple[int, int]]] = {}
            for var in variables:
                locations_by_name.setdefault(var.name, set()).add((var.line, var.column))
            ambiguous = {name for name, locs in locations_by_name.items() if len(locs) > 1}

            decl_locations = {(v.name, v.line, v.column) for v in variables}
            body_indexes = self._significant_indexes(source.tokens, fn.body_start_token + 1, fn.body_end_token)
            for idx in body_indexes:
                tok = source.tokens[idx]
                if tok.kind != TokenKind.IDENTIFIER:
                    continue
                if tok.value not in locations_by_name:
                    continue
                if (tok.value, tok.line, tok.column) in decl_locations:
                    continue
                prev_value, next_value = self._neighbor_values(source.tokens, idx, fn.body_start_token + 1, fn.body_end_token)
                # obj.name / ptr->name / Scope::name is not a reference to a same-named local.
                if prev_value in _MEMBER_ACCESS or prev_value == "::" or next_value == "::":
                    continue
                counts[tok.value] = counts.get(tok.value, 0) + 1

            for var in variables:
                if var.name in ambiguous or ignored_name(var.name, self.rules):
                    continue
                if var.category == "parameter" and not self.rules.check_unused_parameters:
                    continue
                if counts.get(var.name, 0) != 0:
                    continue
                self._emit(
                    rule="USE201" if var.category != "parameter" else "USE202",
                    severity=Severity.WARNING if var.category != "parameter" else Severity.INFO,
                    confidence=Confidence.HIGH,
                    file=var.file,
                    line=var.line,
                    column=var.column,
                    message=(
                        f"Variable '{var.name}' is declared but never used in '{fn.qualified_name}'."
                        if var.category != "parameter"
                        else f"Parameter '{var.name}' is never used in '{fn.qualified_name}'."
                    ),
                    details=f"Declared type: {var.type_text or '<unknown>'}",
                    suggestion="Remove it if unnecessary, or use/rename it according to the intended design.",
                    tags=["usage", "unused", var.category],
                    metadata={"symbol": var.name, "function": fn.qualified_name},
                )

    def _check_field_unused(self, context: ProjectContext, classes: Sequence[ClassInfo]) -> None:
        for cls in classes:
            for field in self._unique_variables(cls.fields):
                if ignored_name(field.name, self.rules):
                    continue
                if self._field_reference_count(context, cls, field) > 0:
                    continue
                self._emit(
                    rule="USE203",
                    severity=Severity.INFO,
                    confidence=Confidence.MEDIUM,
                    file=field.file,
                    line=field.line,
                    column=field.column,
                    message=f"Class field '{cls.name}::{field.name}' is never referenced in the supplied source files.",
                    details="No internal or explicit member access to this field was found. Public/external users outside the supplied files cannot be observed.",
                    suggestion="Remove it if it is obsolete, or ignore this finding if external code intentionally accesses it.",
                    tags=["usage", "unused", "field"],
                    metadata={"symbol": field.name, "class": cls.name},
                )

    def _check_global_unused(self, context: ProjectContext, globals_to_check: Sequence[VariableInfo]) -> None:
        for var in self._unique_variables(globals_to_check):
            if ignored_name(var.name, self.rules):
                continue
            if self._global_reference_count(context, var) > 0:
                continue
            confidence = Confidence.HIGH if var.static else Confidence.MEDIUM
            self._emit(
                rule="USE204",
                severity=Severity.INFO,
                confidence=confidence,
                file=var.file,
                line=var.line,
                column=var.column,
                message=f"Global variable '{var.name}' is never referenced in the supplied source files.",
                details=(
                    "The variable has internal static storage, so this is a high-confidence unused declaration."
                    if var.static else
                    "External users outside the supplied files cannot be observed, so this diagnostic is intentionally medium-confidence."
                ),
                suggestion="Remove it if obsolete, or keep/ignore it if it is part of an external interface.",
                tags=["usage", "unused", "global"],
                metadata={"symbol": var.name},
            )

    # ------------------------------------------------------------------
    # Undeclared variable-like uses
    # ------------------------------------------------------------------

    def _check_undeclared(
        self,
        context: ProjectContext,
        functions: Sequence[FunctionInfo],
        extra_by_function: Mapping[int, list[_ExtraDeclaration]],
        known: _KnownNames,
    ) -> None:
        global_names = {var.name for source in context.files for var in source.global_variables}
        class_fields: dict[str, set[str]] = {}
        for cls in context.classes:
            class_fields.setdefault(cls.name, set()).update(field.name for field in cls.fields)

        known_nonvars = known.non_variables
        config_ignored = {str(x) for x in self.config.get("ignore_undeclared_identifiers", [])}

        for fn in functions:
            source = context.source_file(fn.file)
            if source is None or fn.body_start_token < 0:
                continue

            locals_ = self._unique_variables(fn.local_variables)
            locals_.extend(extra.variable for extra in extra_by_function.get(id(fn), []))
            locals_ = self._unique_variables(locals_)
            local_names = {var.name for var in locals_}
            field_names = class_fields.get(fn.owner_class or "", set())
            declared = local_names | field_names | global_names
            declaration_positions = {(v.name, v.line, v.column) for v in locals_}

            lambda_ranges = self._lambda_body_ranges(source.tokens, fn.body_start_token + 1, fn.body_end_token)
            first_occurrences: dict[str, tuple[Token, int]] = {}
            occurrence_counts: dict[str, int] = {}

            indexes = self._significant_indexes(source.tokens, fn.body_start_token + 1, fn.body_end_token)
            for idx in indexes:
                tok = source.tokens[idx]
                if tok.kind != TokenKind.IDENTIFIER:
                    continue
                name = tok.value
                if (name, tok.line, tok.column) in declaration_positions:
                    continue
                if name in declared or name in known_nonvars or name in config_ignored:
                    continue
                if any(start <= idx <= end for start, end in lambda_ranges):
                    continue
                if self._looks_like_nonvariable_identifier(source.tokens, idx, fn, known):
                    continue

                occurrence_counts[name] = occurrence_counts.get(name, 0) + 1
                first_occurrences.setdefault(name, (tok, idx))

            for name, (tok, _) in first_occurrences.items():
                count = occurrence_counts[name]
                self._emit(
                    rule="USE301",
                    severity=Severity.ERROR,
                    confidence=Confidence.HIGH,
                    file=fn.file,
                    line=tok.line,
                    column=tok.column,
                    message=f"Identifier '{name}' is used like a variable but no visible declaration was found.",
                    details=(
                        f"Found {count} variable-like occurrence{'s' if count != 1 else ''} in '{fn.qualified_name}'. "
                        "Known locals, parameters, class fields, globals, macros, enum values, functions, and type names were excluded first."
                    ),
                    suggestion="Declare the variable in the appropriate scope, include its declaration in the supplied headers, or add a deliberate exception if it is generated externally.",
                    tags=["usage", "undeclared", "variable"],
                    metadata={"symbol": name, "function": fn.qualified_name, "occurrences": count},
                )

    # ------------------------------------------------------------------
    # Known symbols/types
    # ------------------------------------------------------------------

    def _collect_known_names(self, context: ProjectContext) -> _KnownNames:
        types = set(COMMON_TYPE_NAMES)
        macros: set[str] = set()
        enum_values: set[str] = set()
        aliases: set[str] = set()
        function_names: set[str] = set()

        for cls in context.classes:
            types.add(cls.name)
        for fn in context.functions:
            function_names.add(fn.name.lstrip("~"))
            function_names.add(fn.qualified_name.split("::")[-1].lstrip("~"))
            types.update(self._type_words(fn.return_type))
            for param in fn.parameters:
                types.update(self._type_words(param.type_text))
            for var in fn.local_variables:
                types.update(self._type_words(var.type_text))
        for source in context.files:
            for var in source.global_variables:
                types.update(self._type_words(var.type_text))
            for cls in source.classes:
                for field in cls.fields:
                    types.update(self._type_words(field.type_text))

            for token in source.tokens:
                if token.kind == TokenKind.PREPROCESSOR:
                    match = re.match(r"\s*#\s*define\s+([A-Za-z_][A-Za-z0-9_]*)", token.value)
                    if match:
                        macros.add(match.group(1))

            source_aliases, source_enum_types, source_enum_values, template_types = self._extract_declared_types(source.tokens)
            aliases.update(source_aliases)
            types.update(source_aliases)
            types.update(source_enum_types)
            types.update(template_types)
            enum_values.update(source_enum_values)

        return _KnownNames(
            types=types,
            macros=macros,
            enum_values=enum_values,
            function_names=function_names,
            aliases=aliases,
        )

    def _extract_declared_types(
        self, tokens: Sequence[Token]
    ) -> tuple[set[str], set[str], set[str], set[str]]:
        sig = [t for t in tokens if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}]
        aliases: set[str] = set()
        enum_types: set[str] = set()
        enum_values: set[str] = set()
        template_types: set[str] = set()
        braces = matching_pairs(sig, "{", "}")

        i = 0
        while i < len(sig):
            value = sig[i].value
            if value == "typedef":
                semi = self._next_token_value(sig, i + 1, ";")
                if semi is not None:
                    ids = [t.value for t in sig[i + 1:semi] if t.kind == TokenKind.IDENTIFIER and t.value not in CPP_KEYWORDS]
                    if ids:
                        aliases.add(ids[-1])
                    i = semi + 1
                    continue
            elif value == "using" and i + 2 < len(sig):
                if sig[i + 1].kind == TokenKind.IDENTIFIER and sig[i + 2].value == "=":
                    aliases.add(sig[i + 1].value)
            elif value == "enum":
                cursor = i + 1
                if cursor < len(sig) and sig[cursor].value in {"class", "struct"}:
                    cursor += 1
                if cursor < len(sig) and sig[cursor].kind == TokenKind.IDENTIFIER:
                    enum_types.add(sig[cursor].value)
                    cursor += 1
                open_brace = self._next_token_value(sig, cursor, "{", stop={";"})
                if open_brace is not None and open_brace in braces:
                    close = braces[open_brace]
                    for group in split_top_level(sig[open_brace + 1:close], ","):
                        first = next((t for t in group if t.kind == TokenKind.IDENTIFIER), None)
                        if first is not None:
                            enum_values.add(first.value)
                    i = close + 1
                    continue
            elif value == "template":
                lt = self._next_token_value(sig, i + 1, "<", stop={";", "{"})
                if lt is not None:
                    depth = 0
                    j = lt
                    while j < len(sig):
                        if sig[j].value == "<":
                            depth += 1
                        elif sig[j].value in {">", ">>"}:
                            depth -= 2 if sig[j].value == ">>" else 1
                            if depth <= 0:
                                break
                        elif sig[j].value in {"typename", "class"} and j + 1 < len(sig):
                            if sig[j + 1].kind == TokenKind.IDENTIFIER:
                                template_types.add(sig[j + 1].value)
                        j += 1
            i += 1

        return aliases, enum_types, enum_values, template_types

    # ------------------------------------------------------------------
    # Extra declarations not represented by the conservative core parser
    # ------------------------------------------------------------------

    def _extra_local_declarations(
        self, source: SourceFileContext, fn: FunctionInfo, known_types: set[str]
    ) -> list[_ExtraDeclaration]:
        if fn.body_start_token < 0:
            return []
        extras: list[_ExtraDeclaration] = []
        extras.extend(self._structured_bindings(source, fn))
        extras.extend(self._catch_parameters(source, fn))
        extras.extend(self._control_init_variables(source, fn, known_types))
        extras.extend(self._direct_init_variables(source, fn, known_types))
        extras.extend(self._function_pointer_variables(source, fn))

        existing = {(v.name, v.line, v.column) for v in fn.local_variables}
        unique: dict[tuple[str, int, int], _ExtraDeclaration] = {}
        for item in extras:
            key = (item.variable.name, item.variable.line, item.variable.column)
            if key in existing:
                continue
            unique[key] = item
        return list(unique.values())

    def _structured_bindings(self, source: SourceFileContext, fn: FunctionInfo) -> list[_ExtraDeclaration]:
        tokens = source.tokens
        out: list[_ExtraDeclaration] = []
        i = fn.body_start_token + 1
        while i < fn.body_end_token:
            if tokens[i].value != "auto":
                i += 1
                continue
            j = i + 1
            while j < fn.body_end_token and tokens[j].value in {"const", "volatile", "&", "&&"}:
                j += 1
            if j >= fn.body_end_token or tokens[j].value != "[":
                i += 1
                continue
            close = self._matching_forward(tokens, j, "[", "]", fn.body_end_token)
            if close is None:
                i += 1
                continue
            after = self._next_significant_index(tokens, close + 1, fn.body_end_token)
            if after is None or tokens[after].value not in {"=", ":"}:
                i += 1
                continue
            for k in range(j + 1, close):
                tok = tokens[k]
                if tok.kind != TokenKind.IDENTIFIER:
                    continue
                var = VariableInfo(
                    name=tok.value,
                    type_text="auto",
                    category="local",
                    line=tok.line,
                    column=tok.column,
                    owner_function=fn.qualified_name,
                    owner_class=fn.owner_class,
                    confidence="medium",
                    file=fn.file,
                )
                out.append(_ExtraDeclaration(var, k))
            i = close + 1
        return out

    def _catch_parameters(self, source: SourceFileContext, fn: FunctionInfo) -> list[_ExtraDeclaration]:
        tokens = source.tokens
        out: list[_ExtraDeclaration] = []
        parens = matching_pairs(tokens, "(", ")")
        for i in range(fn.body_start_token + 1, fn.body_end_token):
            if tokens[i].value != "catch":
                continue
            open_idx = self._next_significant_index(tokens, i + 1, fn.body_end_token)
            if open_idx is None or tokens[open_idx].value != "(" or open_idx not in parens:
                continue
            close = parens[open_idx]
            core = [t for t in tokens[open_idx + 1:close] if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}]
            ids = [(open_idx + 1 + k, t) for k, t in enumerate(core) if t.kind == TokenKind.IDENTIFIER and t.value not in CPP_KEYWORDS]
            if not ids:
                continue
            idx, tok = ids[-1]
            # Re-resolve index because filtering comments can shift the rough index.
            real_idx = next((j for j in range(open_idx + 1, close) if tokens[j] is tok), idx)
            type_tokens = [t for t in tokens[open_idx + 1:real_idx] if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}]
            var = VariableInfo(
                name=tok.value,
                type_text=tokens_to_compact_text(type_tokens),
                category="local",
                line=tok.line,
                column=tok.column,
                pointer_depth=sum(1 for t in type_tokens if t.value == "*"),
                reference=any(t.value in {"&", "&&"} for t in type_tokens),
                owner_function=fn.qualified_name,
                owner_class=fn.owner_class,
                confidence="medium",
                file=fn.file,
            )
            out.append(_ExtraDeclaration(var, real_idx))
        return out

    def _direct_init_variables(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        known_types: set[str],
    ) -> list[_ExtraDeclaration]:
        """Recognize common direct initialization missed by the conservative core parser.

        Examples: `int count(0);`, `Foo value(arg);`, `std::string text("x");`.
        Empty `Foo value();` is intentionally skipped because it is the classic function-
        declaration ambiguity (most-vexing parse).
        """
        tokens = source.tokens
        parens = matching_pairs(tokens, "(", ")")
        out: list[_ExtraDeclaration] = []
        for open_idx in range(fn.body_start_token + 1, fn.body_end_token):
            if tokens[open_idx].value != "(" or open_idx not in parens:
                continue
            close = parens[open_idx]
            if close <= open_idx + 1:  # Foo x(); is intentionally not treated as a variable.
                continue
            after = self._next_significant_index(tokens, close + 1, fn.body_end_token)
            if after is None or tokens[after].value != ";":
                continue
            name_idx = self._prev_significant_index(tokens, open_idx - 1, fn.body_start_token + 1)
            if name_idx is None or tokens[name_idx].kind != TokenKind.IDENTIFIER:
                continue
            before_name = self._prev_significant_index(tokens, name_idx - 1, fn.body_start_token + 1)
            if before_name is None or tokens[before_name].value in {".", "->", "::", ")", "]"}:
                continue

            statement_start = name_idx
            j = name_idx - 1
            while j > fn.body_start_token:
                if tokens[j].value in {";", "{", "}"}:
                    statement_start = j + 1
                    break
                statement_start = j
                j -= 1
            type_tokens = [
                t for t in tokens[statement_start:name_idx]
                if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}
            ]
            if not type_tokens:
                continue
            if any(t.value in {"=", "+", "-", "/", "%", "?", ".", "->"} for t in type_tokens):
                continue
            words = {t.value for t in type_tokens if t.kind == TokenKind.IDENTIFIER}
            plausible = bool(words & known_types) or bool(words & _TYPE_KEYWORDS)
            plausible = plausible or any(self._looks_type_name(word) or word[:1].isupper() for word in words)
            plausible = plausible or any(t.value == "::" for t in type_tokens)
            if not plausible:
                continue

            name_tok = tokens[name_idx]
            var = VariableInfo(
                name=name_tok.value,
                type_text=tokens_to_compact_text(type_tokens),
                category="local",
                line=name_tok.line,
                column=name_tok.column,
                const=any(t.value == "const" for t in type_tokens),
                constexpr=any(t.value == "constexpr" for t in type_tokens),
                static=any(t.value == "static" for t in type_tokens),
                pointer_depth=sum(1 for t in type_tokens if t.value == "*"),
                reference=any(t.value in {"&", "&&"} for t in type_tokens),
                owner_function=fn.qualified_name,
                owner_class=fn.owner_class,
                confidence="medium",
                file=fn.file,
            )
            out.append(_ExtraDeclaration(var, name_idx))
        return out

    def _function_pointer_variables(self, source: SourceFileContext, fn: FunctionInfo) -> list[_ExtraDeclaration]:
        """Recognize common C/C++ local function-pointer declarations.

        Example: `void (*callback)(int) = handler;`.
        """
        tokens = source.tokens
        out: list[_ExtraDeclaration] = []
        i = fn.body_start_token + 1
        while i < fn.body_end_token - 4:
            if tokens[i].value != "(":
                i += 1
                continue
            star_idx = self._next_significant_index(tokens, i + 1, fn.body_end_token)
            if star_idx is None or tokens[star_idx].value not in {"*", "&"}:
                i += 1
                continue
            name_idx = self._next_significant_index(tokens, star_idx + 1, fn.body_end_token)
            if name_idx is None or tokens[name_idx].kind != TokenKind.IDENTIFIER:
                i += 1
                continue
            close_inner = self._next_significant_index(tokens, name_idx + 1, fn.body_end_token)
            if close_inner is None or tokens[close_inner].value != ")":
                i += 1
                continue
            args_open = self._next_significant_index(tokens, close_inner + 1, fn.body_end_token)
            if args_open is None or tokens[args_open].value != "(":
                i += 1
                continue

            # Find a return/base type immediately before `(*name)`.
            before = self._prev_significant_index(tokens, i - 1, fn.body_start_token + 1)
            if before is None or tokens[before].value in {"=", ";", "{", "}", ".", "->"}:
                i += 1
                continue
            start = before
            while start > fn.body_start_token + 1 and tokens[start - 1].value not in {";", "{", "}"}:
                start -= 1
            type_tokens = [t for t in tokens[start:i] if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}]
            if not type_tokens:
                i += 1
                continue
            name_tok = tokens[name_idx]
            var = VariableInfo(
                name=name_tok.value,
                type_text=tokens_to_compact_text(type_tokens) + " (*)",
                category="local",
                line=name_tok.line,
                column=name_tok.column,
                pointer_depth=1,
                owner_function=fn.qualified_name,
                owner_class=fn.owner_class,
                confidence="medium",
                file=fn.file,
            )
            out.append(_ExtraDeclaration(var, name_idx))
            i = close_inner + 1
        return out

    def _control_init_variables(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        known_types: set[str],
    ) -> list[_ExtraDeclaration]:
        tokens = source.tokens
        parens = matching_pairs(tokens, "(", ")")
        out: list[_ExtraDeclaration] = []
        for i in range(fn.body_start_token + 1, fn.body_end_token):
            if tokens[i].value not in {"if", "while", "switch"}:
                continue
            open_idx = self._next_significant_index(tokens, i + 1, fn.body_end_token)
            if open_idx is None or tokens[open_idx].value != "(" or open_idx not in parens:
                continue
            close = parens[open_idx]
            segment = [t for t in tokens[open_idx + 1:close] if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}]
            # C++17 init statement: inspect the first top-level segment. Otherwise inspect
            # text before an assignment. This intentionally handles common `if (Type x = ...)`.
            split = split_top_level(segment, ";")
            candidate = split[0] if split else segment
            eq = next((n for n, t in enumerate(candidate) if t.value == "="), None)
            if eq is None:
                continue
            left = candidate[:eq]
            ids = [(n, t) for n, t in enumerate(left) if t.kind == TokenKind.IDENTIFIER and t.value not in CPP_KEYWORDS]
            if len(ids) < 2 and not (ids and any(t.value == "auto" for t in left)):
                continue
            name_local_index, name_tok = ids[-1]
            type_tokens = left[:name_local_index]
            type_words = {t.value for t in type_tokens if t.kind == TokenKind.IDENTIFIER}
            if not ("auto" in {t.value for t in type_tokens} or type_words & known_types or any(self._looks_type_name(x) for x in type_words)):
                continue
            real_idx = next(
                (j for j in range(open_idx + 1, close) if tokens[j].line == name_tok.line and tokens[j].column == name_tok.column),
                None,
            )
            if real_idx is None:
                continue
            var = VariableInfo(
                name=name_tok.value,
                type_text=tokens_to_compact_text(type_tokens),
                category="local",
                line=name_tok.line,
                column=name_tok.column,
                const=any(t.value == "const" for t in type_tokens),
                constexpr=any(t.value == "constexpr" for t in type_tokens),
                pointer_depth=sum(1 for t in type_tokens if t.value == "*"),
                reference=any(t.value in {"&", "&&"} for t in type_tokens),
                owner_function=fn.qualified_name,
                owner_class=fn.owner_class,
                confidence="medium",
                file=fn.file,
            )
            out.append(_ExtraDeclaration(var, real_idx))
        return out

    # ------------------------------------------------------------------
    # Reference counting helpers
    # ------------------------------------------------------------------

    def _field_reference_count(self, context: ProjectContext, cls: ClassInfo, field: VariableInfo) -> int:
        count = 0
        declaration = (field.file, field.line, field.column)
        methods = [fn for fn in context.function_definitions if fn.owner_class == cls.name]
        for fn in methods:
            source = context.source_file(fn.file)
            if source is None:
                continue
            shadowed = any(v.name == field.name for v in fn.local_variables)
            # Constructor/member initializer list.
            for idx in self._significant_indexes(source.tokens, fn.signature_end_token + 1, max(fn.body_start_token, fn.signature_end_token + 1)):
                tok = source.tokens[idx]
                if tok.value == field.name:
                    count += 1
            for idx in self._significant_indexes(source.tokens, fn.body_start_token + 1, fn.body_end_token):
                tok = source.tokens[idx]
                if tok.kind != TokenKind.IDENTIFIER or tok.value != field.name:
                    continue
                if (fn.file, tok.line, tok.column) == declaration:
                    continue
                prev_value, next_value = self._neighbor_values(source.tokens, idx, fn.body_start_token + 1, fn.body_end_token)
                if prev_value == "::":
                    count += 1
                elif prev_value in _MEMBER_ACCESS:
                    count += 1
                elif not shadowed and next_value != "::":
                    count += 1

        # Explicit external obj.field / ptr->field or Class::field access.
        for source in context.files:
            for idx, tok in enumerate(source.tokens):
                if tok.kind != TokenKind.IDENTIFIER or tok.value != field.name:
                    continue
                if (source.relative_path, tok.line, tok.column) == declaration:
                    continue
                prev_idx = self._prev_significant_index(source.tokens, idx - 1, 0)
                if prev_idx is None:
                    continue
                prev = source.tokens[prev_idx].value
                if prev in _MEMBER_ACCESS:
                    count += 1
                elif prev == "::":
                    owner_idx = self._prev_significant_index(source.tokens, prev_idx - 1, 0)
                    if owner_idx is not None and source.tokens[owner_idx].value == cls.name:
                        count += 1
        return count

    def _global_reference_count(self, context: ProjectContext, var: VariableInfo) -> int:
        declaration_locations = {
            (v.file, v.line, v.column)
            for source in context.files
            for v in (
                list(source.global_variables)
                + [field for cls in source.classes for field in cls.fields]
                + [local for fn in source.functions for local in fn.local_variables]
            )
            if v.name == var.name
        }
        count = 0
        for source in context.files:
            function_ranges = [
                (fn.body_start_token, fn.body_end_token, fn)
                for fn in source.functions
                if fn.is_definition and fn.body_start_token >= 0
            ]
            for idx, tok in enumerate(source.tokens):
                if tok.kind != TokenKind.IDENTIFIER or tok.value != var.name:
                    continue
                if (source.relative_path, tok.line, tok.column) in declaration_locations:
                    continue
                enclosing = next((fn for start, end, fn in function_ranges if start < idx < end), None)
                if enclosing is not None:
                    shadowed = any(v.name == var.name for v in enclosing.local_variables)
                    if enclosing.owner_class:
                        shadowed = shadowed or any(
                            field.name == var.name
                            for cls in context.classes if cls.name == enclosing.owner_class
                            for field in cls.fields
                        )
                    prev_value, next_value = self._neighbor_values(source.tokens, idx, enclosing.body_start_token + 1, enclosing.body_end_token)
                    if not shadowed and prev_value not in _MEMBER_ACCESS and next_value != "::":
                        count += 1
                    elif prev_value == "::":
                        count += 1
                else:
                    prev_value, next_value = self._neighbor_values(source.tokens, idx, 0, len(source.tokens))
                    if prev_value not in _MEMBER_ACCESS and next_value != "::":
                        count += 1
        return count

    # ------------------------------------------------------------------
    # Undeclared-use filtering
    # ------------------------------------------------------------------

    def _looks_like_nonvariable_identifier(
        self,
        tokens: Sequence[Token],
        index: int,
        fn: FunctionInfo,
        known: _KnownNames,
    ) -> bool:
        tok = tokens[index]
        name = tok.value
        prev_idx = self._prev_significant_index(tokens, index - 1, fn.body_start_token + 1)
        next_idx = self._next_significant_index(tokens, index + 1, fn.body_end_token)
        prev = tokens[prev_idx].value if prev_idx is not None else None
        nxt = tokens[next_idx].value if next_idx is not None else None

        # Qualified/member identifiers are not bare variable declarations in this scope.
        if prev in _MEMBER_ACCESS or prev == "::" or nxt == "::":
            return True
        # Any unknown identifier followed by '(' is treated as an opaque function/API call.
        if nxt == "(":
            return True
        if prev in {"class", "struct", "enum", "typename", "namespace", "using", "typedef", "template", "goto"}:
            return True
        if prev in {"case"} or nxt == ":":
            return True
        if _ALL_CAPS_RE.fullmatch(name):
            return True
        if self._looks_type_name(name):
            return True
        # Conventional type spelling is intentionally accepted when an external header/type
        # is not supplied. A lower-case variable under the default naming rules is unaffected.
        if name[:1].isupper():
            return True
        if prev in {"new", "sizeof", "alignof", "typeid"} and (name in known.types or self._looks_type_name(name) or name[:1].isupper()):
            return True
        # Template/type argument contexts are ambiguous without a compiler.
        if prev in {"<", ","} and nxt in {">", ">>", "*", "&", "&&", ","}:
            return True
        # Designated initializer field `.name =` has a dot and was already excluded.
        return False

    # ------------------------------------------------------------------
    # Generic helpers
    # ------------------------------------------------------------------

    def _type_words(self, type_text: str) -> set[str]:
        return {
            word for word in _IDENTIFIER_RE.findall(type_text or "")
            if word not in _QUALIFIERS and word not in CPP_KEYWORDS
        }

    @staticmethod
    def _looks_type_name(name: str) -> bool:
        return bool(_TYPE_SUFFIX_RE.fullmatch(name)) or name in COMMON_TYPE_NAMES

    @staticmethod
    def _unique_variables(variables: Iterable[VariableInfo]) -> list[VariableInfo]:
        out: list[VariableInfo] = []
        seen: set[tuple[str, int, int, str, str]] = set()
        for var in variables:
            key = (var.file, var.line, var.column, var.name, var.category)
            if key not in seen:
                seen.add(key)
                out.append(var)
        return out

    @staticmethod
    def _significant_indexes(tokens: Sequence[Token], start: int, end: int) -> list[int]:
        return [
            i for i in range(max(0, start), min(len(tokens), end))
            if tokens[i].kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}
        ]

    def _neighbor_values(self, tokens: Sequence[Token], index: int, start: int, end: int) -> tuple[str | None, str | None]:
        prev_idx = self._prev_significant_index(tokens, index - 1, start)
        next_idx = self._next_significant_index(tokens, index + 1, end)
        return (
            tokens[prev_idx].value if prev_idx is not None else None,
            tokens[next_idx].value if next_idx is not None else None,
        )

    @staticmethod
    def _prev_significant_index(tokens: Sequence[Token], index: int, start: int) -> int | None:
        i = index
        while i >= start:
            if tokens[i].kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}:
                return i
            i -= 1
        return None

    @staticmethod
    def _next_significant_index(tokens: Sequence[Token], index: int, end: int) -> int | None:
        i = index
        while i < min(len(tokens), end):
            if tokens[i].kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}:
                return i
            i += 1
        return None

    @staticmethod
    def _next_token_value(tokens: Sequence[Token], start: int, value: str, stop: set[str] | None = None) -> int | None:
        stop = stop or set()
        for i in range(start, len(tokens)):
            if tokens[i].value == value:
                return i
            if tokens[i].value in stop:
                return None
        return None

    @staticmethod
    def _matching_forward(tokens: Sequence[Token], start: int, opener: str, closer: str, end: int) -> int | None:
        depth = 0
        for i in range(start, min(len(tokens), end)):
            if tokens[i].value == opener:
                depth += 1
            elif tokens[i].value == closer:
                depth -= 1
                if depth == 0:
                    return i
        return None

    def _lambda_body_ranges(self, tokens: Sequence[Token], start: int, end: int) -> list[tuple[int, int]]:
        braces = matching_pairs(tokens, "{", "}")
        ranges: list[tuple[int, int]] = []
        i = start
        while i < end:
            if tokens[i].value != "[":
                i += 1
                continue
            close_square = self._matching_forward(tokens, i, "[", "]", end)
            if close_square is None:
                i += 1
                continue
            cursor = self._next_significant_index(tokens, close_square + 1, end)
            if cursor is None:
                i = close_square + 1
                continue
            if tokens[cursor].value not in {"(", "{", "mutable", "constexpr", "consteval", "noexcept", "->", "requires", "<"}:
                i = close_square + 1
                continue
            # Optional lambda parameter/specifier region; find a nearby body opener.
            limit = min(end, cursor + 80)
            body_open = None
            round_depth = angle_depth = 0
            while cursor < limit:
                v = tokens[cursor].value
                if v == "(": round_depth += 1
                elif v == ")" and round_depth: round_depth -= 1
                elif v == "<": angle_depth += 1
                elif v in {">", ">>"} and angle_depth: angle_depth = max(0, angle_depth - (2 if v == ">>" else 1))
                elif v == "{" and round_depth == angle_depth == 0:
                    body_open = cursor
                    break
                elif v == ";" and round_depth == angle_depth == 0:
                    break
                cursor += 1
            if body_open is not None and body_open in braces:
                ranges.append((i, braces[body_open]))
                i = braces[body_open] + 1
            else:
                i = close_square + 1
        return ranges

    def _function_name_location(self, source: SourceFileContext | None, fn: FunctionInfo) -> tuple[int, int]:
        if source is None:
            return fn.start_line, 1
        wanted = fn.name.lstrip("~")
        end = min(len(source.tokens), fn.signature_end_token + 1)
        for i in range(end - 1, max(-1, fn.signature_start_token - 1), -1):
            tok = source.tokens[i]
            if tok.kind == TokenKind.IDENTIFIER and tok.value == wanted:
                return tok.line, tok.column
        return fn.start_line, 1

    def _emit(
        self,
        *,
        rule: str,
        severity: Severity,
        confidence: Confidence,
        file: str,
        line: int,
        column: int,
        message: str,
        details: str = "",
        suggestion: str = "",
        tags: list[str] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        key = (rule, file, line, column, message)
        if key in self._reported:
            return
        self._reported.add(key)
        self.findings.append(Finding(
            checker="naming_usage",
            rule=rule,
            severity=severity,
            confidence=confidence,
            location=SourceLocation(file=file, line=line, column=column),
            message=message,
            details=details,
            suggestion=suggestion,
            tags=tags or [],
            metadata=metadata or {},
        ))
