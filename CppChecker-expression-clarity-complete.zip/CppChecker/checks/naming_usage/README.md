# Naming + variable-usage checker

`checks/naming_usage/` is independent of the memory checker and uses only the shared core API.

## What it checks

### Configurable naming

Each category has its own regular expression:

- `local_variable`
- `parameter`
- `class_field`
- `static_class_field`
- `global_variable`
- `static_global_variable`
- `local_constant`
- `class_constant`
- `global_constant`
- `free_function`
- `member_function`

Constructors/destructors are not independently named because their spelling is fixed by the class name.

A rule can be disabled by setting it to `null` or an empty string.

### Declared but unused

The checker reports locals and parameters with no reference after declaration. It also reports fields/globals that are never referenced in the supplied source set; field/global diagnostics use lower confidence where code outside the supplied files could legitimately reference them.

If the same local name is declared more than once in a function (shadowing), unused attribution for that name is skipped instead of guessed because the lightweight parser does not build a complete C++ scope graph.

### Used but not declared

Function bodies are scanned for high-confidence variable-like identifiers. Before reporting, the analyzer removes known:

- locals and parameters
- class fields
- globals
- function names / opaque function calls
- C/C++ keywords
- class/struct names
- typedef and `using` aliases
- enum types and enum values
- template type parameters
- preprocessor macros declared in supplied files
- member accesses (`obj.field`, `ptr->field`)
- qualified accesses (`Type::name`, `namespace::name`)
- common C/C++ scalar/fixed-width aliases
- conventional `*_t` external type names in type-like positions

Unknown function/API calls are assumed valid. This matches the project rule that missing dependency implementations are opaque rather than analyzed.

The checker deliberately skips uncertain constructs rather than producing speculative undeclared-variable warnings.

## Recognized declaration forms

The shared parser plus checker-specific conservative additions handle common forms including:

```cpp
int value;
uint32_t flags;
int16_t sample_count;
unit_t unit_count;
CustomType custom_value;
Foo* pointer_value;
int values[32];
auto result = api();
Foo direct_value(argument);
std::string text("value");
auto [left_value, right_value] = pair_value;
if (Node* node = get_node()) { ... }
int (*callback)(int) = handler;
```

`int8_t/uint8_t/int16_t/uint16_t/int32_t/uint32_t/int64_t/uint64_t`, fast/least variants, `size_t`, `intptr_t`, `uintptr_t`, `intmax_t`, `uintmax_t`, `uint_t`, `unit_t`, and discovered custom typedef/using/class types are treated as types rather than undeclared variables.

## Configuration

```json
"naming_usage": {
  "enabled": true,
  "target_cpp": null,
  "check_naming": true,
  "check_unused": true,
  "check_unused_parameters": true,
  "check_undeclared": true,
  "analyze_header_definitions": false,
  "ignore_identifiers": ["_"],
  "ignore_name_patterns": [],
  "ignore_undeclared_identifiers": [],
  "rules": {
    "local_variable": "^[a-z][a-z0-9_]*$",
    "parameter": "^[a-z][a-z0-9_]*$",
    "class_field": "^[a-z][a-z0-9_]*$",
    "static_class_field": "^[a-z][a-z0-9_]*$",
    "global_variable": "^[a-z][a-z0-9_]*$",
    "static_global_variable": "^[a-z][a-z0-9_]*$",
    "local_constant": "^[A-Z][A-Z0-9_]*$",
    "class_constant": "^[A-Z][A-Z0-9_]*$",
    "global_constant": "^[A-Z][A-Z0-9_]*$",
    "free_function": "^[a-z][a-z0-9_]*$",
    "member_function": "^[a-z][a-z0-9_]*$"
  }
}
```

If `target_cpp` is `null`, all supplied implementation files are checked. Set it to a path, filename, unique stem, or list to limit naming/usage diagnostics to selected implementation files while still using all supplied headers/files as context.

## Rule IDs

- `NAME000` invalid checker regex/configuration
- `NAME001` target file selection problem
- `NAME101` function naming violation
- `NAME102` variable naming violation
- `USE201` local variable declared but unused
- `USE202` parameter unused
- `USE203` field not referenced in supplied files
- `USE204` global not referenced in supplied files
- `USE301` high-confidence variable-like identifier used without a visible declaration
