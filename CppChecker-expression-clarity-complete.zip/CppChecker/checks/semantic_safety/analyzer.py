from __future__ import annotations

from dataclasses import dataclass
import re
from pathlib import PurePosixPath
from typing import Any, Mapping, Sequence

from core.diagnostics import Confidence, Finding, Severity, SourceLocation
from core.expression_utils import IGNORABLE_KINDS, matching_pairs, tokens_to_compact_text
from core.source_context import FunctionInfo, ProjectContext, SourceFileContext, VariableInfo
from core.tokenizer import Token, TokenKind

from .rules import TypeInfo, TypeSystem, merged_rule_config


_CPP_EXTENSIONS = {".c", ".cc", ".cpp", ".cxx"}
_COMPARISONS = {"<", "<=", ">", ">=", "==", "!="}
_NUMERIC_BINARY = {"+", "-", "*", "/", "%", "<<", ">>"}
_CAST_NAMES = {"static_cast", "reinterpret_cast", "const_cast", "dynamic_cast"}


@dataclass(slots=True)
class ExprInfo:
    type: TypeInfo
    constant: int | float | None = None
    explicit_cast: bool = False
    root_operator: str | None = None
    left: "ExprInfo | None" = None
    right: "ExprInfo | None" = None
    text: str = ""


class SemanticSafetyAnalyzer:
    """Conservative semantic checks using only the local structural/token model.

    Patch 1 implements numeric type/range/conversion analysis, Patch 2 adds
    high-confidence condition/loop/state mistakes, and Patch 3 extends arithmetic
    storage, precedence and loop-progression checks. Expressions whose type cannot
    be resolved confidently are intentionally skipped.
    """

    def __init__(self, config: Mapping[str, Any]) -> None:
        self.config = config
        self.rules = merged_rule_config(config)
        self.types = TypeSystem(config)
        self.findings: list[Finding] = []
        self.context: ProjectContext | None = None
        self._function_returns: dict[str, list[FunctionInfo]] = {}
        self._all_globals: list[VariableInfo] = []

    def analyze(self, context: ProjectContext) -> list[Finding]:
        self.context = context
        self.findings = []
        self._discover_type_aliases(context)
        self._function_returns = self._index_functions(context)
        self._all_globals = [v for f in context.files for v in f.global_variables]

        targets, config_finding = self._resolve_target_sources(context)
        if config_finding is not None:
            return [config_finding]

        target_paths = {source.relative_path for source in targets}
        functions = [
            fn for fn in context.function_definitions
            if fn.file in target_paths and fn.body_start_token >= 0
        ]
        for fn in functions:
            source = context.source_file(fn.file)
            if source is not None:
                self._analyze_function(source, fn)
                self._analyze_common_mistakes(source, fn)

        self._suppress_cascading_findings()
        self.findings.sort(key=lambda f: (f.location.file.lower(), f.location.line, f.location.column, f.rule))
        return self.findings

    def _suppress_cascading_findings(self) -> None:
        """Prefer the most specific root-cause diagnostic over derivative range noise."""
        loop_root_lines = {
            (f.location.file, f.location.line)
            for f in self.findings
            if f.rule in {"SEM204", "SEM205", "SEM207", "SEM208"}
        }
        definite_update_lines = {
            (f.location.file, f.location.line)
            for f in self.findings
            if f.rule == "SEM321"
        }
        self.findings = [
            f for f in self.findings
            if not (
                (f.location.file, f.location.line) in loop_root_lines
                and f.rule in {"SEM201", "SEM202", "SEM203"}
            )
            and not (
                (f.location.file, f.location.line) in definite_update_lines
                and f.rule == "SEM320"
            )
        ]

    # ------------------------------------------------------------------
    # Project/type setup
    # ------------------------------------------------------------------

    def _resolve_target_sources(
        self, context: ProjectContext
    ) -> tuple[list[SourceFileContext], Finding | None]:
        cpp_files = [f for f in context.files if f.path.suffix.lower() in _CPP_EXTENSIONS]
        requested = self.config.get("target_cpp")
        if not requested:
            if len(cpp_files) == 1:
                return cpp_files, None
            main_named = [f for f in cpp_files if PurePosixPath(f.relative_path).name.lower() == "main.cpp"]
            if len(main_named) == 1:
                return main_named, None
            # For semantic checks, analyzing all supplied .cpp files is safe when no target is given.
            return cpp_files, None

        raw_items = requested if isinstance(requested, list) else [requested]
        selected: list[SourceFileContext] = []
        unresolved: list[str] = []
        for raw in raw_items:
            text = str(raw).replace("\\", "/").strip()
            if not text:
                continue
            lower = text.lower()
            matches = [
                source for source in cpp_files
                if source.relative_path.lower() == lower
                or PurePosixPath(source.relative_path).name.lower() == lower
                or PurePosixPath(source.relative_path).stem.lower() == lower
            ]
            if len(matches) == 1:
                if matches[0] not in selected:
                    selected.append(matches[0])
            else:
                unresolved.append(text)
        if selected and not unresolved:
            return selected, None

        file = context.files[0].relative_path if context.files else "<project>"
        return [], Finding(
            checker="semantic_safety",
            rule="SEM000",
            severity=Severity.INFO,
            confidence=Confidence.CERTAIN,
            location=SourceLocation(file=file, line=1, column=1),
            message="Semantic-safety analysis was skipped because target_cpp could not be resolved uniquely.",
            details="Unresolved target(s): " + ", ".join(unresolved or [str(x) for x in raw_items]),
            suggestion="Set checks.semantic_safety.target_cpp to a unique .cpp path, filename, or stem.",
            tags=["configuration", "semantic-safety"],
        )

    def _discover_type_aliases(self, context: ProjectContext) -> None:
        for source in context.files:
            tokens = source.tokens
            sig = [i for i, t in enumerate(tokens) if t.kind not in IGNORABLE_KINDS]
            pos = 0
            while pos < len(sig):
                i = sig[pos]
                tok = tokens[i]
                if tok.value == "using" and pos + 3 < len(sig):
                    name_tok = tokens[sig[pos + 1]]
                    eq_tok = tokens[sig[pos + 2]]
                    if name_tok.kind == TokenKind.IDENTIFIER and eq_tok.value == "=":
                        end_pos = pos + 3
                        parts: list[Token] = []
                        while end_pos < len(sig) and tokens[sig[end_pos]].value != ";":
                            parts.append(tokens[sig[end_pos]])
                            end_pos += 1
                        target = tokens_to_compact_text(parts)
                        if target:
                            self.types.register_alias(name_tok.value, target)
                        pos = end_pos
                elif tok.value == "typedef":
                    end_pos = pos + 1
                    parts: list[Token] = []
                    while end_pos < len(sig) and tokens[sig[end_pos]].value != ";":
                        parts.append(tokens[sig[end_pos]])
                        end_pos += 1
                    identifiers = [t for t in parts if t.kind == TokenKind.IDENTIFIER]
                    if len(identifiers) >= 2:
                        alias = identifiers[-1].value
                        alias_index = max(j for j, t in enumerate(parts) if t is identifiers[-1])
                        target = tokens_to_compact_text(parts[:alias_index])
                        if target:
                            self.types.register_alias(alias, target)
                    pos = end_pos
                pos += 1

    @staticmethod
    def _index_functions(context: ProjectContext) -> dict[str, list[FunctionInfo]]:
        out: dict[str, list[FunctionInfo]] = {}
        for fn in context.functions:
            out.setdefault(fn.name, []).append(fn)
            out.setdefault(fn.qualified_name, []).append(fn)
        return out

    # ------------------------------------------------------------------
    # Function scan
    # ------------------------------------------------------------------

    def _analyze_function(self, source: SourceFileContext, fn: FunctionInfo) -> None:
        variable_map = self._variable_map(fn)
        body_indices = self._significant_indices(source.tokens, fn.body_start_token + 1, fn.body_end_token)
        if not body_indices:
            return
        local_decl_positions = {
            (v.line, v.column, v.name): v for v in fn.local_variables
        }

        # Initializers for parsed locals.
        for var in fn.local_variables:
            idx = self._find_token_index(source.tokens, fn.body_start_token + 1, fn.body_end_token, var.line, var.column, var.name)
            if idx is None:
                continue
            statement_end = self._find_statement_end(source.tokens, idx, fn.body_end_token)
            eq = self._find_top_level_value(source.tokens, idx + 1, statement_end, "=")
            if eq is None:
                continue
            expr_tokens = self._clean(source.tokens[eq + 1:statement_end])
            self._check_conversion(expr_tokens, self.types.resolve(var.type_text), source, fn, source.tokens[eq], "initialization", variable_map)

        # Assignments, returns, calls, comparisons and shifts.
        seen_calls: set[int] = set()
        for pos, idx in enumerate(body_indices):
            tok = source.tokens[idx]

            if tok.value == "=" and self._is_plain_assignment(source.tokens, idx, fn.body_start_token + 1, fn.body_end_token):
                lhs = self._assignment_lhs_variable(source.tokens, body_indices, pos, variable_map)
                if lhs is not None and not self._is_declaration_assignment(tok, lhs, local_decl_positions):
                    end = self._find_statement_end(source.tokens, idx + 1, fn.body_end_token)
                    expr_tokens = self._clean(source.tokens[idx + 1:end])
                    self._check_conversion(expr_tokens, self.types.resolve(lhs.type_text), source, fn, tok, "assignment", variable_map)

            elif tok.value in {"+=", "-=", "*=", "/=", "%=", "<<=", ">>="}:
                lhs = self._assignment_lhs_variable(source.tokens, body_indices, pos, variable_map)
                if lhs is not None:
                    end = self._find_statement_end(source.tokens, idx + 1, fn.body_end_token)
                    expr_tokens = self._clean(source.tokens[idx + 1:end])
                    self._check_compound_assignment(
                        source, fn, tok, lhs, expr_tokens, variable_map
                    )

            elif tok.value == "return" and self.rules.get("return_conversion", True):
                end = self._find_statement_end(source.tokens, idx + 1, fn.body_end_token)
                expr_tokens = self._clean(source.tokens[idx + 1:end])
                if expr_tokens and fn.return_type and fn.return_type.strip() != "void":
                    self._check_conversion(expr_tokens, self.types.resolve(fn.return_type), source, fn, tok, "return", variable_map, rule_override="SEM106")

            if tok.kind == TokenKind.IDENTIFIER and pos + 1 < len(body_indices):
                next_idx = body_indices[pos + 1]
                if source.tokens[next_idx].value == "(" and idx not in seen_calls:
                    close = self._matching_close(source.tokens, next_idx, "(", ")", fn.body_end_token)
                    if close is not None:
                        seen_calls.add(idx)
                        self._check_call_arguments(source, fn, idx, next_idx, close, variable_map)

            if tok.value in _COMPARISONS:
                self._check_comparison(source, fn, idx, variable_map)

            if tok.value in {"<<", ">>"} and self.rules.get("invalid_shift_width", True):
                self._check_shift(source, fn, idx, variable_map)

    def _variable_map(self, fn: FunctionInfo) -> dict[str, list[VariableInfo]]:
        out: dict[str, list[VariableInfo]] = {}
        for param in fn.parameters:
            if not param.name:
                continue
            out.setdefault(param.name, []).append(VariableInfo(
                name=param.name,
                type_text=param.type_text,
                category="parameter",
                line=param.line,
                column=param.column,
                file=param.file or fn.file,
                owner_function=fn.qualified_name,
                owner_class=fn.owner_class,
            ))
        for var in fn.local_variables:
            out.setdefault(var.name, []).append(var)
        if self.context is not None and fn.owner_class:
            for cls in self.context.classes:
                if cls.name == fn.owner_class:
                    for field in cls.fields:
                        out.setdefault(field.name, []).append(field)
        for var in self._all_globals:
            out.setdefault(var.name, []).append(var)
        return out

    # ------------------------------------------------------------------
    # Patch 2: common operator / condition / loop / state mistakes
    # ------------------------------------------------------------------

    def _analyze_common_mistakes(self, source: SourceFileContext, fn: FunctionInfo) -> None:
        variable_map = self._variable_map(fn)
        sig = self._significant_indices(source.tokens, fn.body_start_token + 1, fn.body_end_token)
        sig_pos = {idx: pos for pos, idx in enumerate(sig)}

        # Control-condition analysis.
        for idx in sig:
            tok = source.tokens[idx]
            if tok.value not in {"if", "while", "for"}:
                continue
            pos = sig_pos[idx]
            if pos + 1 >= len(sig) or source.tokens[sig[pos + 1]].value != "(":
                continue
            open_idx = sig[pos + 1]
            close_idx = self._matching_close(source.tokens, open_idx, "(", ")", fn.body_end_token)
            if close_idx is None:
                continue
            inside = self._clean(source.tokens[open_idx + 1:close_idx])
            if tok.value == "for":
                clauses = self._split_top_level_semicolons(inside)
                if len(clauses) == 3:
                    self._check_condition_patterns(source, fn, clauses[1], variable_map)
                    self._check_for_loop(source, fn, tok, clauses, variable_map)
            else:
                self._check_condition_patterns(source, fn, inside, variable_map)

        # General statement/expression mistakes.
        if self.rules.get("division_by_zero", True):
            for pos, idx in enumerate(sig):
                tok = source.tokens[idx]
                if tok.value not in {"/", "%"}:
                    continue
                right = self._simple_operand_right(source.tokens, idx, fn.body_end_token)
                expr = self._infer_expr(right, fn, variable_map) if right else None
                if expr is not None and expr.constant == 0:
                    self._emit(
                        "SEM310", Severity.ERROR, Confidence.CERTAIN, source, tok,
                        "Division or modulo by zero.",
                        f"The right operand of '{tok.value}' is the constant zero.",
                        "Correct the divisor or validate it before the operation.",
                        ["arithmetic", "division-by-zero"],
                    )

        if self.rules.get("self_assignment", True):
            for pos, idx in enumerate(sig):
                if source.tokens[idx].value != "=" or pos == 0 or pos + 1 >= len(sig):
                    continue
                lhs = source.tokens[sig[pos - 1]]
                rhs = source.tokens[sig[pos + 1]]
                if lhs.kind == TokenKind.IDENTIFIER and rhs.kind == TokenKind.IDENTIFIER and lhs.value == rhs.value:
                    # Require the RHS to end the simple expression to avoid x = x + 1.
                    after = source.tokens[sig[pos + 2]].value if pos + 2 < len(sig) else ";"
                    if after in {";", ")", ","}:
                        self._emit(
                            "SEM402", Severity.WARNING, Confidence.CERTAIN, source, source.tokens[idx],
                            f"Self-assignment '{lhs.value} = {rhs.value}' has no effect.",
                            "The same variable appears as both the complete source and destination.",
                            "Remove the assignment or correct the source variable if this is a typo.",
                            ["assignment", "self-assignment"],
                        )

        if self.rules.get("constant_update_overflow", True) or self.rules.get("known_zero_divisor", True):
            self._check_linear_constant_state(source, fn, variable_map)

        if self.rules.get("use_before_initialization", True):
            self._check_definite_use_before_init(source, fn, variable_map)

    def _check_condition_patterns(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        condition: Sequence[Token],
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        if not condition:
            return

        # Assignment in a boolean condition.  Intentional idioms such as
        # ((p = next()) != nullptr) are suppressed because the assignment result
        # is explicitly compared.
        if self.rules.get("assignment_in_condition", True):
            assignments = [t for t in condition if t.value == "="]
            if assignments and not self._condition_has_outer_comparison_of_assignment(condition):
                for eq in assignments[:1]:
                    self._emit(
                        "SEM001", Severity.ERROR, Confidence.HIGH, source, eq,
                        "Assignment is used as a condition; '==' may have been intended.",
                        "A bare '=' changes the left operand and then uses the assigned value as truth/falsehood.",
                        "Use '==' for comparison. If assignment is intentional, compare its result explicitly, e.g. ((x = f()) != 0).",
                        ["condition", "assignment", "operator"],
                    )

        # 0 < x < 10, a == b == c, etc. are legal C++ but do not mean mathematical chaining.
        if self.rules.get("chained_comparison", True):
            top = self._top_level_operator_positions(condition, _COMPARISONS)
            if len(top) >= 2 and not self._top_level_operator_positions(condition, {"&&", "||"}):
                self._emit(
                    "SEM002", Severity.ERROR, Confidence.CERTAIN, source, condition[top[1]],
                    "Chained comparison does not have mathematical meaning in C/C++.",
                    f"Expression '{tokens_to_compact_text(condition)}' evaluates the first comparison to bool, then compares that bool again.",
                    "Split the tests with &&/||, for example: 0 < x && x < 10.",
                    ["condition", "comparison", "operator"],
                )

        if self.rules.get("contradictory_boolean", True):
            self._check_contradictory_boolean(source, condition)

        if self.rules.get("bitwise_boolean_mixup", True):
            for op in ("&", "|"):
                positions = self._top_level_operator_positions(condition, {op})
                for p in positions:
                    left = self._strip_outer_parentheses(condition[:p])
                    right = self._strip_outer_parentheses(condition[p + 1:])
                    if self._contains_comparison(left) and self._contains_comparison(right):
                        logical = "&&" if op == "&" else "||"
                        self._emit(
                            "SEM004", Severity.WARNING, Confidence.HIGH, source, condition[p],
                            f"Bitwise '{op}' combines boolean comparison results; '{logical}' may have been intended.",
                            f"Both sides of '{op}' are comparison expressions.",
                            f"Use '{logical}' if logical short-circuit boolean combination is intended.",
                            ["condition", "bitwise", "logical-operator"],
                        )
                        break

        if self.rules.get("suspicious_not_precedence", True):
            stripped = self._strip_outer_parentheses(condition)
            if len(stripped) >= 3 and stripped[0].value == "!":
                bitwise = self._top_level_operator_positions(stripped, {"&", "|"})
                if bitwise:
                    op_token = stripped[bitwise[0]]
                    self._emit(
                        "SEM005", Severity.WARNING, Confidence.HIGH, source, stripped[0],
                        f"'!' is evaluated before bitwise '{op_token.value}'.",
                        f"Expression '{tokens_to_compact_text(stripped)}' negates only the first operand before the bitwise operation.",
                        "Add parentheses if the intended test is !(flags & MASK) or !(flags | MASK).",
                        ["condition", "precedence", "bitwise"],
                    )

        # flags & MASK == 0 parses as flags & (MASK == 0), because equality
        # binds more tightly than bitwise &, | and ^. Parenthesized bitmasks are
        # not reported because their bitwise operator is no longer top-level.
        if self.rules.get("bitwise_comparison_precedence", True):
            stripped = self._strip_outer_parentheses(condition)
            bitwise = self._top_level_operator_positions(stripped, {"&", "|", "^"})
            comparisons = self._top_level_operator_positions(stripped, _COMPARISONS)
            pair = next(((b, c) for b in bitwise for c in comparisons if b < c), None)
            if pair is not None:
                b, c = pair
                op_token = stripped[b]
                self._emit(
                    "SEM006", Severity.WARNING, Confidence.HIGH, source, op_token,
                    f"Bitwise '{op_token.value}' is mixed with comparison '{stripped[c].value}' without grouping.",
                    f"Expression '{tokens_to_compact_text(stripped)}' evaluates the comparison before the bitwise operation under C/C++ precedence rules.",
                    f"Add parentheses around the bitmask expression if intended, e.g. (flags {op_token.value} MASK) {stripped[c].value} value.",
                    ["condition", "precedence", "bitwise", "comparison"],
                )

    def _check_contradictory_boolean(self, source: SourceFileContext, condition: Sequence[Token]) -> None:
        for logical, impossible_ops in (("||", {"!="}), ("&&", {"=="})):
            positions = self._top_level_operator_positions(condition, {logical})
            if len(positions) != 1:
                continue
            p = positions[0]
            left = self._simple_comparison_signature(self._strip_outer_parentheses(condition[:p]))
            right = self._simple_comparison_signature(self._strip_outer_parentheses(condition[p + 1:]))
            if left is None or right is None:
                continue
            l_name, l_op, l_rhs = left
            r_name, r_op, r_rhs = right
            if l_name != r_name or l_op not in impossible_ops or r_op not in impossible_ops or l_rhs == r_rhs:
                continue
            if logical == "||":
                msg = f"Condition is always true: '{l_name} != {l_rhs} || {l_name} != {r_rhs}'."
                suggestion = "Use && when excluding multiple distinct values."
            else:
                msg = f"Condition is impossible: '{l_name} == {l_rhs} && {l_name} == {r_rhs}'."
                suggestion = "Use || when accepting either distinct value, or correct one comparison operand."
            self._emit(
                "SEM003", Severity.ERROR, Confidence.CERTAIN, source, condition[p],
                msg,
                "The same scalar cannot simultaneously satisfy these distinct equality requirements.",
                suggestion,
                ["condition", "boolean-logic", "comparison"],
            )

    def _check_for_loop(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        for_token: Token,
        clauses: Sequence[Sequence[Token]],
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        init, condition, update = clauses
        loop_name = self._for_loop_variable_name(init)
        if not loop_name:
            return
        loop_token = next((t for t in init if t.kind == TokenKind.IDENTIFIER and t.value == loop_name), None)
        if loop_token is None:
            return
        var = self._resolve_variable(loop_token, variable_map)
        if var is None:
            # The structure parser may not expose a for-init local in unusual syntax;
            # infer its type from tokens immediately preceding the loop variable.
            var = self._synthetic_for_variable(init, loop_token, fn)
        t = self.types.resolve(var.type_text) if var is not None else TypeInfo("<unknown>", "unknown")

        comp = self._simple_comparison_signature(condition)
        update_name, update_direction = self._for_update_signature(update)
        update_step = self._for_update_constant_step(update, fn, variable_map)
        if update_step is not None:
            if update_step > 0:
                update_direction = "up"
            elif update_step < 0:
                update_direction = "down"
            else:
                update_direction = "none"

        if self.rules.get("wrong_for_update_variable", True) and update_name and update_name != loop_name:
            self._emit(
                "SEM403", Severity.ERROR, Confidence.HIGH, source, next((x for x in update if x.value in {"++", "--", "+=", "-="}), for_token),
                f"For-loop initializes/checks '{loop_name}' but updates '{update_name}'.",
                "With a single obvious loop-control variable, updating a different variable is usually a typo and can make the loop non-terminating.",
                f"Update '{loop_name}' or revise the loop condition/initializer if multiple control variables are intentional.",
                ["loop", "control-variable", "operator"],
            )

        if self.rules.get("zero_loop_step", True) and update_step == 0:
            anchor = next((x for x in update if x.value in {"+=", "-=", "++", "--"}), for_token)
            self._emit(
                "SEM207", Severity.ERROR, Confidence.CERTAIN, source, anchor,
                f"For-loop control variable '{loop_name}' has a zero update step.",
                "The loop-control value does not change, so a true condition cannot progress toward termination.",
                "Use a non-zero step or change the loop condition/control variable.",
                ["loop", "progress", "non-terminating"],
            )

        if comp is None or comp[0] != loop_name or not t.is_integer:
            return
        _name, op, rhs_text = comp
        rhs_expr = self._infer_expr(self._strip_outer_parentheses(self._comparison_rhs_tokens(condition)), fn, variable_map)
        rhs_const = rhs_expr.constant if isinstance(rhs_expr.constant, int) else None

        if self.rules.get("loop_direction_mismatch", True) and rhs_const is not None and update_step not in {None, 0}:
            init_const = self._for_initializer_constant(init, fn, variable_map)
            if init_const is not None and self._constant_comparison(init_const, op, rhs_const) is True:
                moving_away = (op in {"<", "<="} and update_step < 0) or (op in {">", ">="} and update_step > 0)
                if moving_away:
                    self._emit(
                        "SEM208", Severity.ERROR, Confidence.HIGH, source, for_token,
                        f"For-loop update moves '{loop_name}' away from its terminating bound.",
                        f"The loop starts with {loop_name}={init_const}, condition '{loop_name} {op} {rhs_const}' is true, but the constant step is {update_step:+d}.",
                        "Reverse the update direction or correct the comparison/bound.",
                        ["loop", "progress", "direction"],
                    )

        if (
            self.rules.get("unsigned_reverse_loop", True)
            and t.signed is False
            and update_direction == "down"
            and rhs_const == 0
            and op in {">=", ">"}
        ):
            if op == ">=":
                self._emit(
                    "SEM204", Severity.ERROR, Confidence.CERTAIN, source, for_token,
                    f"Unsigned reverse loop using '{loop_name} >= 0' cannot terminate at -1.",
                    f"{t.name} cannot become negative; decrementing zero wraps to the type's maximum value.",
                    "Use a signed loop index or a reverse-loop form that tests before decrementing.",
                    ["loop", "unsigned", "underflow"],
                )

        if (
            self.rules.get("loop_bound_out_of_range", True)
            and rhs_const is not None and t.min_value is not None and t.max_value is not None
            and update_direction in {"up", "down"}
        ):
            impossible = False
            if update_direction == "up" and op in {"<", "<="} and rhs_const > t.max_value:
                impossible = True
            if update_direction == "down" and op in {">", ">="} and rhs_const < t.min_value:
                impossible = True
            if impossible:
                self._emit(
                    "SEM205", Severity.ERROR, Confidence.CERTAIN, source, for_token,
                    f"Loop bound {rhs_const} is outside the representable range of {t.name}.",
                    f"Loop variable '{loop_name}' range is [{t.min_value}, {t.max_value}], so it cannot reach the terminating bound without overflow/wrap.",
                    "Use a wider loop-variable type or a bound representable by the loop variable.",
                    ["loop", "range", "overflow"],
                )

    def _check_linear_constant_state(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        """Track only obvious constants inside straight-line code.

        State is discarded at control-flow boundaries, nested scopes and opaque calls.
        This intentionally sacrifices coverage to avoid path-sensitive false alarms.
        """
        sig = self._significant_indices(source.tokens, fn.body_start_token + 1, fn.body_end_token)
        if not sig:
            return
        declarations = {(v.line, v.column, v.name): v for v in fn.local_variables}
        state: dict[str, int | float] = {}

        for pos, idx in enumerate(sig):
            tok = source.tokens[idx]

            if tok.value in {"if", "else", "for", "while", "switch", "do", "goto", "case", "default", "?", "{", "}"}:
                state.clear()
                continue

            # Opaque calls can mutate values through pointers/references. Clear the
            # tiny constant cache instead of assuming call semantics.
            if tok.kind == TokenKind.IDENTIFIER and pos + 1 < len(sig) and source.tokens[sig[pos + 1]].value == "(":
                if tok.value not in {"sizeof"}:
                    state.clear()
                continue

            # Numeric local declaration with a simple constant initializer.
            decl = declarations.get((tok.line, tok.column, tok.value)) if tok.kind == TokenKind.IDENTIFIER else None
            if decl is not None:
                t = self.types.resolve(decl.type_text)
                if t.category not in {"integer", "floating", "bool"}:
                    continue
                end = self._find_statement_end(source.tokens, idx, fn.body_end_token)
                eq = self._find_top_level_value(source.tokens, idx + 1, end, "=")
                if eq is None:
                    state.pop(decl.name, None)
                    continue
                expr = self._infer_expr(self._clean(source.tokens[eq + 1:end]), fn, variable_map)
                if isinstance(expr.constant, (int, float)):
                    state[decl.name] = expr.constant
                else:
                    state.pop(decl.name, None)
                continue

            # Direct assignment updates or invalidates the known constant.
            if tok.value == "=" and pos > 0:
                lhs_tok = source.tokens[sig[pos - 1]]
                if lhs_tok.kind == TokenKind.IDENTIFIER and lhs_tok.value in variable_map:
                    end = self._find_statement_end(source.tokens, idx + 1, fn.body_end_token)
                    expr = self._infer_expr(self._clean(source.tokens[idx + 1:end]), fn, variable_map)
                    if isinstance(expr.constant, (int, float)):
                        state[lhs_tok.value] = expr.constant
                    else:
                        state.pop(lhs_tok.value, None)
                continue

            # Definite overflow/wrap from ++/-- or constant compound arithmetic.
            if tok.value in {"++", "--", "+=", "-=", "*=", "/=", "%="}:
                name_tok: Token | None = None
                if pos > 0 and source.tokens[sig[pos - 1]].kind == TokenKind.IDENTIFIER:
                    name_tok = source.tokens[sig[pos - 1]]
                elif tok.value in {"++", "--"} and pos + 1 < len(sig) and source.tokens[sig[pos + 1]].kind == TokenKind.IDENTIFIER:
                    name_tok = source.tokens[sig[pos + 1]]
                if name_tok is None or name_tok.value not in state:
                    continue
                var = self._resolve_variable(name_tok, variable_map)
                t = self.types.resolve(var.type_text) if var is not None else TypeInfo("<unknown>", "unknown")
                if not t.is_integer or t.min_value is None or t.max_value is None:
                    state.pop(name_tok.value, None)
                    continue

                current = state[name_tok.value]
                if not isinstance(current, int):
                    state.pop(name_tok.value, None)
                    continue
                result: int | None = None
                if tok.value == "++":
                    result = current + 1
                elif tok.value == "--":
                    result = current - 1
                else:
                    end = self._find_statement_end(source.tokens, idx + 1, fn.body_end_token)
                    rhs = self._infer_expr(self._clean(source.tokens[idx + 1:end]), fn, variable_map)
                    if isinstance(rhs.constant, int):
                        op = tok.value[0]
                        result_value = self._evaluate_constant(current, op, rhs.constant)
                        result = result_value if isinstance(result_value, int) else None
                if result is None:
                    state.pop(name_tok.value, None)
                    continue
                if not (t.min_value <= result <= t.max_value):
                    if self.rules.get("constant_update_overflow", True):
                        behavior = "wraps the unsigned value" if t.signed is False else "overflows the signed range"
                        self._emit(
                            "SEM321", Severity.ERROR, Confidence.CERTAIN, source, tok,
                            f"Known update of '{name_tok.value}' {behavior} for {t.name}.",
                            f"Current known value is {current}; '{tok.value}' produces mathematical value {result}, outside [{t.min_value}, {t.max_value}].",
                            "Use a wider type, validate the boundary before updating, or explicitly implement the intended wrap behavior.",
                            ["arithmetic", "overflow", "constant-state"],
                        )
                    state.pop(name_tok.value, None)
                else:
                    state[name_tok.value] = result
                continue

            # Division/modulo by an identifier known to be zero in this same
            # straight-line segment. Literal zero is already handled separately.
            if tok.value in {"/", "%"} and self.rules.get("known_zero_divisor", True) and pos + 1 < len(sig):
                rhs_tok = source.tokens[sig[pos + 1]]
                if rhs_tok.kind == TokenKind.IDENTIFIER and state.get(rhs_tok.value) == 0:
                    self._emit(
                        "SEM311", Severity.ERROR, Confidence.CERTAIN, source, tok,
                        f"Division or modulo uses '{rhs_tok.value}', which is known to be zero here.",
                        "The variable was assigned constant zero earlier in the same straight-line region with no control-flow boundary in between.",
                        "Change the divisor or validate/update it before this operation.",
                        ["arithmetic", "division-by-zero", "constant-state"],
                    )

    def _check_definite_use_before_init(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        for var in fn.local_variables:
            t = self.types.resolve(var.type_text)
            if t.category not in {"integer", "floating", "bool", "pointer"} or var.array:
                continue
            decl_idx = self._find_token_index(source.tokens, fn.body_start_token + 1, fn.body_end_token, var.line, var.column, var.name)
            if decl_idx is None:
                continue
            stmt_end = self._find_statement_end(source.tokens, decl_idx, fn.body_end_token)
            initialized = self._declaration_has_initializer(source.tokens, decl_idx, stmt_end)
            if initialized:
                continue

            sig = self._significant_indices(source.tokens, decl_idx + 1, fn.body_end_token)
            reported = False
            for pos, idx in enumerate(sig):
                tok = source.tokens[idx]
                if tok.kind != TokenKind.IDENTIFIER or tok.value != var.name:
                    continue
                prev = source.tokens[sig[pos - 1]].value if pos > 0 else None
                nxt = source.tokens[sig[pos + 1]].value if pos + 1 < len(sig) else None

                # Address passed out: an opaque/local API may initialize it.  Do not
                # report and stop tracking to avoid false positives.
                if prev == "&":
                    break

                # Direct assignment initializes after the RHS has been evaluated.
                if nxt == "=":
                    initialized = True
                    break

                # Assignment operators and ++/-- read the old value first.
                if nxt in {"+=", "-=", "*=", "/=", "%=", "++", "--"} or prev in {"++", "--"}:
                    pass
                # Member access on an uninitialized object/pointer is still a read;
                # bare member names themselves are handled elsewhere.
                elif prev in {".", "->", "::"}:
                    continue

                if not initialized:
                    self._emit(
                        "SEM400", Severity.ERROR, Confidence.CERTAIN, source, tok,
                        f"Local variable '{var.name}' is read before it is initialized.",
                        f"'{var.name}' is declared at line {var.line} without an initializer and this is the first definite read before any direct assignment.",
                        "Initialize the variable at declaration or assign it before this use.",
                        ["variable", "initialization", "dataflow"],
                    )
                    reported = True
                    break
            if reported:
                continue

    # ---- Patch-2 parsing helpers -------------------------------------

    @staticmethod
    def _split_top_level_semicolons(tokens: Sequence[Token]) -> list[list[Token]]:
        out: list[list[Token]] = []
        current: list[Token] = []
        rd = sd = cd = 0
        for t in tokens:
            if t.value == "(": rd += 1
            elif t.value == ")" and rd: rd -= 1
            elif t.value == "[": sd += 1
            elif t.value == "]" and sd: sd -= 1
            elif t.value == "{": cd += 1
            elif t.value == "}" and cd: cd -= 1
            if t.value == ";" and rd == sd == cd == 0:
                out.append(current); current = []
            else:
                current.append(t)
        out.append(current)
        return out

    @staticmethod
    def _top_level_operator_positions(tokens: Sequence[Token], operators: set[str]) -> list[int]:
        out: list[int] = []
        rd = sd = cd = 0
        for i, t in enumerate(tokens):
            if t.value == "(": rd += 1
            elif t.value == ")" and rd: rd -= 1
            elif t.value == "[": sd += 1
            elif t.value == "]" and sd: sd -= 1
            elif t.value == "{": cd += 1
            elif t.value == "}" and cd: cd -= 1
            elif rd == sd == cd == 0 and t.value in operators:
                out.append(i)
        return out

    def _condition_has_outer_comparison_of_assignment(self, tokens: Sequence[Token]) -> bool:
        # Explicit comparison at the condition's outer level is the common idiom:
        # ((x = f()) != 0).  The outer wrapper is removed first.
        stripped = self._strip_outer_parentheses(tokens)
        return bool(self._top_level_operator_positions(stripped, _COMPARISONS))

    def _strip_outer_parentheses(self, tokens: Sequence[Token]) -> list[Token]:
        out = list(tokens)
        while len(out) >= 2 and out[0].value == "(" and self._matching_close_local(out, 0, "(", ")") == len(out) - 1:
            out = out[1:-1]
        return out

    def _contains_comparison(self, tokens: Sequence[Token]) -> bool:
        stripped = self._strip_outer_parentheses(tokens)
        return bool(self._top_level_operator_positions(stripped, _COMPARISONS))

    def _simple_comparison_signature(self, tokens: Sequence[Token]) -> tuple[str, str, str] | None:
        stripped = self._strip_outer_parentheses(tokens)
        positions = self._top_level_operator_positions(stripped, _COMPARISONS)
        if len(positions) != 1:
            return None
        p = positions[0]
        left = self._strip_outer_parentheses(stripped[:p])
        right = self._strip_outer_parentheses(stripped[p + 1:])
        if len(left) != 1 or left[0].kind != TokenKind.IDENTIFIER or not right:
            return None
        rhs = tokens_to_compact_text(right)
        return left[0].value, stripped[p].value, rhs

    @staticmethod
    def _for_loop_variable_name(init: Sequence[Token]) -> str | None:
        # Prefer the identifier immediately before '='. This covers declarations
        # and assignments without requiring full declaration parsing.
        for i, t in enumerate(init):
            if t.value == "=" and i > 0 and init[i - 1].kind == TokenKind.IDENTIFIER:
                return init[i - 1].value
        # Fallback for direct initialization: Type i(...)
        for i in range(1, len(init)):
            if init[i].kind == TokenKind.IDENTIFIER and i + 1 < len(init) and init[i + 1].value in {"(", "{"}:
                return init[i].value
        return None

    def _synthetic_for_variable(self, init: Sequence[Token], name_token: Token, fn: FunctionInfo) -> VariableInfo | None:
        name_pos = next((i for i, t in enumerate(init) if t is name_token), None)
        if name_pos is None or name_pos == 0:
            return None
        type_text = tokens_to_compact_text(init[:name_pos])
        if self.types.resolve(type_text).category == "unknown":
            return None
        return VariableInfo(
            name=name_token.value, type_text=type_text, category="local",
            line=name_token.line, column=name_token.column, file=fn.file,
            owner_function=fn.qualified_name, owner_class=fn.owner_class,
        )

    @staticmethod
    def _for_update_signature(update: Sequence[Token]) -> tuple[str | None, str | None]:
        for i, t in enumerate(update):
            if t.value in {"++", "--"}:
                name = None
                if i > 0 and update[i - 1].kind == TokenKind.IDENTIFIER:
                    name = update[i - 1].value
                elif i + 1 < len(update) and update[i + 1].kind == TokenKind.IDENTIFIER:
                    name = update[i + 1].value
                return name, "up" if t.value == "++" else "down"
            if t.value in {"+=", "-="} and i > 0 and update[i - 1].kind == TokenKind.IDENTIFIER:
                return update[i - 1].value, "up" if t.value == "+=" else "down"
        return None, None

    def _for_update_constant_step(
        self,
        update: Sequence[Token],
        fn: FunctionInfo,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> int | None:
        for i, t in enumerate(update):
            if t.value == "++":
                return 1
            if t.value == "--":
                return -1
            if t.value in {"+=", "-="}:
                rhs = self._infer_expr(update[i + 1:], fn, variable_map)
                if isinstance(rhs.constant, int):
                    return rhs.constant if t.value == "+=" else -rhs.constant
        return None

    def _for_initializer_constant(
        self,
        init: Sequence[Token],
        fn: FunctionInfo,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> int | None:
        eq = self._find_top_level_value(init, 0, len(init), "=")
        if eq is None:
            return None
        expr = self._infer_expr(init[eq + 1:], fn, variable_map)
        return expr.constant if isinstance(expr.constant, int) else None

    @staticmethod
    def _constant_comparison(left: int, op: str, right: int) -> bool | None:
        if op == "<": return left < right
        if op == "<=": return left <= right
        if op == ">": return left > right
        if op == ">=": return left >= right
        if op == "==": return left == right
        if op == "!=": return left != right
        return None

    def _comparison_rhs_tokens(self, condition: Sequence[Token]) -> list[Token]:
        stripped = self._strip_outer_parentheses(condition)
        positions = self._top_level_operator_positions(stripped, _COMPARISONS)
        if len(positions) != 1:
            return []
        return list(stripped[positions[0] + 1:])

    @staticmethod
    def _declaration_has_initializer(tokens: Sequence[Token], decl_idx: int, stmt_end: int) -> bool:
        for i in range(decl_idx + 1, min(stmt_end, len(tokens))):
            if tokens[i].kind in IGNORABLE_KINDS:
                continue
            if tokens[i].value in {"=", "{", "("}:
                return True
            if tokens[i].value in {",", ";"}:
                return False
        return False

    # ------------------------------------------------------------------
    # Conversions
    # ------------------------------------------------------------------

    def _check_conversion(
        self,
        expr_tokens: Sequence[Token],
        destination: TypeInfo,
        source: SourceFileContext,
        fn: FunctionInfo,
        anchor: Token,
        conversion_context: str,
        variable_map: Mapping[str, list[VariableInfo]],
        rule_override: str | None = None,
    ) -> None:
        if destination.category == "unknown" or not expr_tokens:
            return
        expr = self._infer_expr(expr_tokens, fn, variable_map)
        if expr.type.category == "unknown" or expr.explicit_cast:
            return

        # A mathematically known constant expression can already overflow/wrap
        # in its own evaluation type before any destination conversion occurs.
        # Example: uint64_t x = 100000 * 100000; when int is 32-bit.
        if (
            self.rules.get("constant_expression_overflow", True)
            and expr.type.is_integer
            and isinstance(expr.constant, int)
            and expr.root_operator in {"+", "-", "*", "<<"}
            and expr.type.min_value is not None and expr.type.max_value is not None
            and not (expr.type.min_value <= expr.constant <= expr.type.max_value)
        ):
            behavior = "wraps modulo the unsigned range" if expr.type.signed is False else "overflows the signed evaluation range"
            self._emit(
                "SEM300", Severity.ERROR, Confidence.CERTAIN, source, anchor,
                f"Constant expression {behavior} before conversion to {destination.name}.",
                f"Expression '{expr.text}' evaluates mathematically to {expr.constant}, outside {expr.type.name} range [{expr.type.min_value}, {expr.type.max_value}].",
                "Widen an operand before the arithmetic (or change the literal suffix/type) so the expression itself is evaluated in the intended range.",
                ["arithmetic", "overflow", "constant-expression", conversion_context],
            )
            return

        # Integer division performed before storage/return as floating point.
        if (
            self.rules.get("integer_division_to_float", True)
            and destination.is_floating
            and expr.type.is_integer
            and expr.root_operator == "/"
            and expr.left is not None and expr.right is not None
            and expr.left.type.is_integer and expr.right.type.is_integer
        ):
            self._emit(
                "SEM104", Severity.WARNING, Confidence.HIGH, source, anchor,
                "Integer division is implicitly converted to floating point after truncation.",
                f"Expression '{expr.text}' is evaluated as integer arithmetic before conversion to {destination.name}.",
                "Cast at least one operand to the intended floating type before division.",
                ["conversion", "integer-division", conversion_context],
            )
            return

        # Constant result outside destination range.
        if destination.is_integer and isinstance(expr.constant, (int, float)):
            if isinstance(expr.constant, float) and not expr.constant.is_integer():
                if expr.type.is_floating and self.rules.get("float_to_integer", True):
                    self._emit(
                        rule_override or "SEM103", Severity.WARNING, Confidence.CERTAIN, source, anchor,
                        f"Floating-point value is implicitly converted to integer type {destination.name}.",
                        f"Known value {expr.constant!r} loses its fractional part during {conversion_context}.",
                        "Use an explicit cast only if truncation is deliberate, or keep the destination floating-point.",
                        ["conversion", "float-to-int", conversion_context],
                    )
                    return
            lo, hi = destination.min_value, destination.max_value
            if lo is not None and hi is not None and not (lo <= expr.constant <= hi):
                self._emit(
                    rule_override or "SEM200", Severity.ERROR, Confidence.CERTAIN, source, anchor,
                    f"Value {expr.constant} cannot be represented by {destination.name}.",
                    f"Destination range is [{lo}, {hi}] during {conversion_context}.",
                    "Use a wider destination type or explicitly constrain/validate the value before conversion.",
                    ["conversion", "range", conversion_context],
                )
                return

        if destination.is_integer and expr.type.is_floating and self.rules.get("float_to_integer", True):
            self._emit(
                rule_override or "SEM103", Severity.WARNING, Confidence.HIGH, source, anchor,
                f"Implicit floating-point to integer conversion to {destination.name}.",
                f"Source expression has type {expr.type.name}; fractional data and out-of-range values can be lost.",
                "Use an explicit cast only if truncation is deliberate, or validate/range-limit the value first.",
                ["conversion", "float-to-int", conversion_context],
            )
            return

        if destination.is_integer and expr.type.is_integer:
            s, d = expr.type, destination
            # A known constant that fits is safe even if its nominal source literal type is wider/signed differently.
            if isinstance(expr.constant, int) and d.min_value is not None and d.max_value is not None:
                if d.min_value <= expr.constant <= d.max_value:
                    pass
                else:
                    return
            else:
                if s.signed is True and d.signed is False and self.rules.get("signed_to_unsigned", True):
                    self._emit(
                        rule_override or "SEM101", Severity.WARNING, Confidence.HIGH, source, anchor,
                        f"Implicit signed-to-unsigned conversion from {s.name} to {d.name}.",
                        "A negative source value becomes a large unsigned value; narrowing may also discard high bits.",
                        "Validate that the value is non-negative and in range, or make the conversion explicit if deliberate.",
                        ["conversion", "signedness", conversion_context],
                    )
                    return
                if s.signed is False and d.signed is True and s.max_value is not None and d.max_value is not None and s.max_value > d.max_value and self.rules.get("unsigned_to_signed", True):
                    self._emit(
                        rule_override or "SEM102", Severity.WARNING, Confidence.HIGH, source, anchor,
                        f"Implicit unsigned-to-signed conversion from {s.name} to {d.name} may be out of range.",
                        f"{s.name} can represent values above the maximum {d.name} value {d.max_value}.",
                        "Range-check the source or use an explicit cast if the conversion is intentional.",
                        ["conversion", "signedness", conversion_context],
                    )
                    return
                if s.bits is not None and d.bits is not None and s.bits > d.bits and self.rules.get("narrowing_integer", True):
                    self._emit(
                        rule_override or "SEM100", Severity.WARNING, Confidence.HIGH, source, anchor,
                        f"Implicit narrowing conversion from {s.name} to {d.name}.",
                        f"Source width is {s.bits} bits while destination width is {d.bits} bits.",
                        "Range-check the source or make the narrowing explicit if it is deliberate.",
                        ["conversion", "narrowing", conversion_context],
                    )
                    return

        # Arithmetic can overflow at its operand/common type before assignment widens it.
        if (
            self.rules.get("overflow_before_widening", True)
            and destination.is_integer and expr.type.is_integer
            and destination.bits is not None and expr.type.bits is not None
            and destination.bits > expr.type.bits
            and expr.root_operator in {"*", "+", "-"}
            and expr.left is not None and expr.right is not None
            and expr.left.type.is_integer and expr.right.type.is_integer
            and expr.constant is None
        ):
            self._emit(
                "SEM301", Severity.WARNING, Confidence.HIGH, source, anchor,
                f"'{expr.root_operator}' may overflow before widening to {destination.name}.",
                f"The arithmetic expression is evaluated as {expr.type.name} ({expr.type.bits} bits) before assignment to {destination.name} ({destination.bits} bits).",
                "Cast one operand to the wider type before the arithmetic if the wider range is required.",
                ["arithmetic", "overflow", conversion_context],
            )
            return

        if (
            self.rules.get("shift_before_widening", True)
            and destination.is_integer and expr.type.is_integer
            and destination.bits is not None and expr.type.bits is not None
            and destination.bits > expr.type.bits
            and expr.root_operator == "<<"
            and expr.left is not None and expr.left.type.is_integer
            and not expr.explicit_cast
        ):
            self._emit(
                "SEM304", Severity.WARNING, Confidence.HIGH, source, anchor,
                f"Left shift is evaluated in {expr.type.bits}-bit {expr.type.name} before widening to {destination.name}.",
                f"A wider destination does not widen the left operand of '{expr.text}' before the shift.",
                "Use a wider left operand/literal (for example 1ULL) or explicitly cast the left operand before shifting.",
                ["arithmetic", "shift", "widening", conversion_context],
            )

    def _check_compound_assignment(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        operator: Token,
        lhs: VariableInfo,
        rhs_tokens: Sequence[Token],
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        if not self.rules.get("compound_assignment_conversion", True) or not rhs_tokens:
            return
        destination = self.types.resolve(lhs.type_text)
        rhs = self._infer_expr(rhs_tokens, fn, variable_map)
        if destination.category == "unknown" or rhs.type.category == "unknown" or rhs.explicit_cast:
            return

        if operator.value in {"<<=", ">>="} and destination.is_integer and destination.bits is not None:
            if isinstance(rhs.constant, int) and (rhs.constant < 0 or rhs.constant >= destination.bits):
                self._emit(
                    "SEM303", Severity.ERROR, Confidence.CERTAIN, source, operator,
                    f"Shift count {rhs.constant} is outside the valid range for {destination.name}.",
                    f"Compound shift operates on a {destination.bits}-bit destination; valid counts are 0..{destination.bits - 1}.",
                    "Constrain the shift amount or use a wider destination type.",
                    ["arithmetic", "shift", "compound-assignment"],
                )
            return

        if destination.is_integer and rhs.type.is_floating:
            self._emit(
                "SEM320", Severity.WARNING, Confidence.HIGH, source, operator,
                f"Compound assignment '{operator.value}' converts floating-point arithmetic back to integer {destination.name}.",
                "Fractional data and out-of-range values may be discarded when the result is stored back in the left operand.",
                "Use an explicit conversion if truncation is intentional or keep the calculation in a floating-point destination.",
                ["conversion", "compound-assignment", "float-to-int"],
            )
            return

        if not destination.is_integer or not rhs.type.is_integer:
            return

        if isinstance(rhs.constant, int) and destination.min_value is not None and destination.max_value is not None:
            if destination.min_value <= rhs.constant <= destination.max_value:
                return

        risky = False
        reason = ""
        if rhs.type.bits is not None and destination.bits is not None and rhs.type.bits > destination.bits:
            risky = True
            reason = f"right operand type {rhs.type.name} is wider than {destination.name}"
        elif rhs.type.signed is True and destination.signed is False:
            risky = True
            reason = "a negative signed right operand is converted through unsigned arithmetic"
        elif (
            rhs.type.signed is False and destination.signed is True
            and rhs.type.max_value is not None and destination.max_value is not None
            and rhs.type.max_value > destination.max_value
        ):
            risky = True
            reason = f"unsigned {rhs.type.name} can exceed the positive range of {destination.name}"

        if risky:
            self._emit(
                "SEM320", Severity.WARNING, Confidence.HIGH, source, operator,
                f"Compound assignment '{operator.value}' can lose or reinterpret value when stored back into {destination.name}.",
                f"The operation uses the right operand before converting the result back to the left operand; {reason}.",
                "Range-check the right operand or make the intended conversion explicit before the compound assignment.",
                ["conversion", "compound-assignment", "narrowing"],
            )

    def _check_call_arguments(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        name_idx: int,
        open_idx: int,
        close_idx: int,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        if not self.rules.get("argument_conversion", True):
            return
        name = source.tokens[name_idx].value
        candidates = self._function_returns.get(name, [])
        if not candidates:
            return
        args = self._split_args(source.tokens[open_idx + 1:close_idx])
        by_arity = [c for c in candidates if len(c.parameters) == len(args)]
        if not by_arity:
            return
        # If overloads disagree on parameter types, type resolution is ambiguous: skip those arguments.
        for arg_index, arg_tokens in enumerate(args):
            param_types = {c.parameters[arg_index].type_text for c in by_arity if c.parameters[arg_index].type_text}
            if len(param_types) != 1:
                continue
            destination = self.types.resolve(next(iter(param_types)))
            anchor = arg_tokens[0] if arg_tokens else source.tokens[name_idx]
            self._check_conversion(arg_tokens, destination, source, fn, anchor, "function argument", variable_map, rule_override="SEM105")

    # ------------------------------------------------------------------
    # Comparisons / shifts
    # ------------------------------------------------------------------

    def _check_comparison(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        op_idx: int,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        left_tokens = self._simple_operand_left(source.tokens, op_idx, fn.body_start_token + 1)
        right_tokens = self._simple_operand_right(source.tokens, op_idx, fn.body_end_token)
        if not left_tokens or not right_tokens:
            return
        left = self._infer_expr(left_tokens, fn, variable_map)
        right = self._infer_expr(right_tokens, fn, variable_map)
        op = source.tokens[op_idx].value
        if left.type.category == "unknown" or right.type.category == "unknown":
            return

        # Range-vs-constant checks, including the classic unsigned < 0 / >= 0 errors.
        variable_side: ExprInfo | None = None
        constant: int | float | None = None
        effective_op = op
        if left.type.is_integer and left.constant is None and isinstance(right.constant, int):
            variable_side, constant = left, right.constant
        elif right.type.is_integer and right.constant is None and isinstance(left.constant, int):
            variable_side, constant = right, left.constant
            effective_op = self._reverse_comparison(op)

        if variable_side is not None and constant is not None:
            t = variable_side.type
            if t.signed is False and constant == 0:
                if effective_op == "<" and self.rules.get("unsigned_zero_comparison", True):
                    self._emit("SEM202", Severity.ERROR, Confidence.CERTAIN, source, source.tokens[op_idx],
                               f"Comparison is always false: unsigned {t.name} cannot be less than zero.",
                               "Unsigned integer ranges start at 0.", "Remove the impossible condition or use a signed type if negative values are meaningful.",
                               ["comparison", "unsigned", "range"])
                    return
                if effective_op == ">=" and self.rules.get("unsigned_zero_comparison", True):
                    self._emit("SEM203", Severity.WARNING, Confidence.CERTAIN, source, source.tokens[op_idx],
                               f"Comparison is always true: unsigned {t.name} is always greater than or equal to zero.",
                               "Unsigned integer ranges start at 0.", "Remove the redundant condition or use a signed type if negative values are meaningful.",
                               ["comparison", "unsigned", "range"])
                    return

            if self.rules.get("impossible_range_comparison", True) and t.min_value is not None and t.max_value is not None:
                truth = self._range_comparison_truth(t.min_value, t.max_value, effective_op, constant)
                if truth is not None:
                    label = "always true" if truth else "always false"
                    self._emit(
                        "SEM201", Severity.ERROR if not truth else Severity.WARNING, Confidence.CERTAIN,
                        source, source.tokens[op_idx],
                        f"Comparison is {label} for type {t.name}.",
                        f"{t.name} range is [{t.min_value}, {t.max_value}], but the comparison uses {constant}.",
                        "Correct the constant, comparison operator, or variable type.",
                        ["comparison", "range"],
                    )
                    return

        # Signed/unsigned variable comparison. Non-negative constants that fit are intentionally ignored.
        if self.rules.get("signed_unsigned_compare", True):
            if left.type.is_integer and right.type.is_integer and left.type.signed != right.type.signed:
                signed_expr = left if left.type.signed else right
                unsigned_expr = right if left.type.signed else left
                if isinstance(signed_expr.constant, int) and signed_expr.constant >= 0 and unsigned_expr.type.max_value is not None and signed_expr.constant <= unsigned_expr.type.max_value:
                    return
                self._emit(
                    "SEM110", Severity.WARNING, Confidence.HIGH, source, source.tokens[op_idx],
                    f"Comparison mixes signed {signed_expr.type.name} and unsigned {unsigned_expr.type.name}.",
                    "Usual arithmetic conversions can turn a negative signed value into a large unsigned value before comparison.",
                    "Use matching signedness, validate the signed value before comparison, or cast explicitly if the conversion is deliberate.",
                    ["comparison", "signedness"],
                )

    def _check_shift(
        self,
        source: SourceFileContext,
        fn: FunctionInfo,
        op_idx: int,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> None:
        left_tokens = self._simple_operand_left(source.tokens, op_idx, fn.body_start_token + 1)
        right_tokens = self._simple_operand_right(source.tokens, op_idx, fn.body_end_token)
        if not left_tokens or not right_tokens:
            return
        left = self._infer_expr(left_tokens, fn, variable_map)
        right = self._infer_expr(right_tokens, fn, variable_map)
        if not left.type.is_integer or left.type.bits is None or not isinstance(right.constant, int):
            return
        if right.constant < 0 or right.constant >= left.type.bits:
            self._emit(
                "SEM303", Severity.ERROR, Confidence.CERTAIN, source, source.tokens[op_idx],
                f"Shift count {right.constant} is outside the valid range for {left.type.name}.",
                f"The left operand width is {left.type.bits} bits; valid shift counts are 0..{left.type.bits - 1}.",
                "Use a wider left operand or constrain the shift amount.",
                ["arithmetic", "shift", "range"],
            )

    # ------------------------------------------------------------------
    # Expression inference
    # ------------------------------------------------------------------

    def _infer_expr(
        self,
        tokens: Sequence[Token],
        fn: FunctionInfo,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> ExprInfo:
        tokens = self._clean(tokens)
        text = tokens_to_compact_text(tokens)
        if not tokens:
            return ExprInfo(TypeInfo("<unknown>", "unknown"), text=text)

        # Strip balanced outer parentheses, but preserve C-style casts.
        while len(tokens) >= 2 and tokens[0].value == "(" and self._matching_close_local(tokens, 0, "(", ")") == len(tokens) - 1:
            tokens = list(tokens[1:-1])
            text = tokens_to_compact_text(tokens)

        # C++ named cast.
        if len(tokens) >= 6 and tokens[0].value in _CAST_NAMES and tokens[1].value == "<":
            close_angle = self._find_matching_angle(tokens, 1)
            if close_angle is not None and close_angle + 1 < len(tokens) and tokens[close_angle + 1].value == "(":
                target = self.types.resolve(tokens_to_compact_text(tokens[2:close_angle]))
                return ExprInfo(target, explicit_cast=True, text=text)

        # C-style cast: (type)expr. Unknown named types still count as deliberate casts,
        # but only known numeric target types participate in subsequent inference.
        if tokens[0].value == "(":
            close = self._matching_close_local(tokens, 0, "(", ")")
            if close is not None and close < len(tokens) - 1 and self._looks_like_type(tokens[1:close]):
                target = self.types.resolve(tokens_to_compact_text(tokens[1:close]))
                return ExprInfo(target, explicit_cast=True, text=text)

        # sizeof(...) has size_t type.
        if tokens[0].value == "sizeof":
            return ExprInfo(self.types.resolve("size_t"), text=text)

        # Unary +/- on a numeric constant/simple integer expression.
        if len(tokens) >= 2 and tokens[0].value in {"+", "-"}:
            inner = self._infer_expr(tokens[1:], fn, variable_map)
            if inner.type.is_integer and isinstance(inner.constant, int):
                value = inner.constant if tokens[0].value == "+" else -inner.constant
                return ExprInfo(inner.type, constant=value, text=text)
            if inner.type.is_floating and isinstance(inner.constant, (int, float)):
                value = float(inner.constant) if tokens[0].value == "+" else -float(inner.constant)
                return ExprInfo(inner.type, constant=value, text=text)

        if len(tokens) == 1:
            token = tokens[0]
            if token.kind == TokenKind.NUMBER:
                return self._number_expr(token)
            if token.kind == TokenKind.IDENTIFIER:
                var = self._resolve_variable(token, variable_map)
                if var is not None:
                    return ExprInfo(self.types.resolve(var.type_text), text=text)
                if token.value in {"true", "false"}:
                    return ExprInfo(self.types.resolve("bool"), constant=1 if token.value == "true" else 0, text=text)

        # Simple function call with known return type.
        if len(tokens) >= 3 and tokens[0].kind == TokenKind.IDENTIFIER and tokens[1].value == "(" and tokens[-1].value == ")":
            close = self._matching_close_local(tokens, 1, "(", ")")
            if close == len(tokens) - 1:
                return_type = self._resolve_function_return(tokens[0].value, tokens[2:-1])
                return ExprInfo(return_type, text=text)

        # Binary operators, from low to high precedence so the final split is the root.
        for ops in (("||",), ("&&",), ("|",), ("^",), ("&",), ("==", "!="), ("<", "<=", ">", ">="), ("<<", ">>"), ("+", "-"), ("*", "/", "%")):
            split = self._find_root_operator(tokens, set(ops))
            if split is None:
                continue
            left_tokens, op, right_tokens = tokens[:split], tokens[split].value, tokens[split + 1:]
            if not left_tokens or not right_tokens:
                continue
            left = self._infer_expr(left_tokens, fn, variable_map)
            right = self._infer_expr(right_tokens, fn, variable_map)
            if op in _COMPARISONS or op in {"&&", "||"}:
                return ExprInfo(self.types.resolve("bool"), root_operator=op, left=left, right=right, text=text)
            if op in _NUMERIC_BINARY or op in {"&", "|", "^"}:
                result_type = self._usual_numeric_type(left.type, right.type)
                constant = self._evaluate_constant(left.constant, op, right.constant)
                return ExprInfo(result_type, constant=constant, root_operator=op, left=left, right=right, text=text)

        return ExprInfo(TypeInfo(text or "<unknown>", "unknown"), text=text)

    def _number_expr(self, token: Token) -> ExprInfo:
        raw = token.value.replace("'", "")
        # Floating literal.
        if any(c in raw.lower() for c in (".", "e", "p")) and not raw.lower().startswith(("0x", "0b")):
            suffix_match = re.search(r"([fFlL]+)$", raw)
            suffix = suffix_match.group(1).lower() if suffix_match else ""
            number = raw[:-len(suffix)] if suffix else raw
            try:
                value = float(number)
            except ValueError:
                return ExprInfo(TypeInfo(raw, "unknown"), text=raw)
            t = self.types.resolve("float" if "f" in suffix else ("long double" if "l" in suffix else "double"))
            return ExprInfo(t, constant=value, text=raw)

        match = re.fullmatch(r"(0[xX][0-9a-fA-F]+|0[bB][01]+|0[0-7]*|[0-9]+)([uUlL]*)", raw)
        if not match:
            return ExprInfo(TypeInfo(raw, "unknown"), text=raw)
        number_text, suffix = match.groups()
        if number_text.lower().startswith("0x"):
            base = 16
        elif number_text.lower().startswith("0b"):
            base = 2
        elif len(number_text) > 1 and number_text.startswith("0"):
            base = 8
        else:
            base = 10
        try:
            value = int(number_text, base)
        except ValueError:
            return ExprInfo(TypeInfo(raw, "unknown"), text=raw)
        return ExprInfo(self.types.integer_literal_type(value, suffix, base), constant=value, text=raw)

    def _usual_numeric_type(self, a: TypeInfo, b: TypeInfo) -> TypeInfo:
        if a.is_floating or b.is_floating:
            floats = [t for t in (a, b) if t.is_floating]
            return max(floats, key=lambda t: t.bits or 0) if floats else TypeInfo("<unknown>", "unknown")
        if not a.is_integer or not b.is_integer or a.bits is None or b.bits is None:
            return TypeInfo("<unknown>", "unknown")
        # Integer promotions for types narrower than int.
        a = self._promote_integer(a)
        b = self._promote_integer(b)
        if a.bits == b.bits:
            if a.signed == b.signed:
                return a
            return TypeInfo(f"unsigned{a.bits}", "integer", a.bits, False)
        wider, narrower = (a, b) if (a.bits or 0) > (b.bits or 0) else (b, a)
        if wider.signed is False:
            return wider
        if narrower.signed is False and narrower.bits == wider.bits:
            return TypeInfo(f"unsigned{wider.bits}", "integer", wider.bits, False)
        return wider

    def _promote_integer(self, t: TypeInfo) -> TypeInfo:
        if not t.is_integer or t.bits is None:
            return t
        int_t = self.types.resolve("int")
        uint_t = self.types.resolve("unsigned int")
        if t.bits < (int_t.bits or 0):
            if t.max_value is not None and int_t.max_value is not None and t.max_value <= int_t.max_value:
                return int_t
            return uint_t
        return t

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _resolve_variable(self, token: Token, variable_map: Mapping[str, list[VariableInfo]]) -> VariableInfo | None:
        candidates = variable_map.get(token.value, [])
        if not candidates:
            return None
        visible = [v for v in candidates if (v.line < token.line or (v.line == token.line and v.column <= token.column))]
        if visible:
            # The lightweight declaration parser can conservatively misread the
            # RHS of compound assignments as a declaration in rare same-line
            # forms (e.g. small += large). Prefer a scalar type the semantic
            # type model can actually resolve instead of letting that artifact
            # hide the real declaration.
            typed = [v for v in visible if self.types.resolve(v.type_text).category != "unknown"]
            pool = typed or visible
            return max(pool, key=lambda v: (v.line, v.column, 1 if v.category == "local" else 0))
        # Class fields/globals can be declared in headers after/before this translation unit position.
        nonlocals = [v for v in candidates if v.category in {"field", "global", "parameter"}]
        return nonlocals[0] if len(nonlocals) == 1 else None

    def _resolve_function_return(self, name: str, arg_tokens: Sequence[Token]) -> TypeInfo:
        candidates = self._function_returns.get(name, [])
        if not candidates:
            return TypeInfo("<unknown>", "unknown")
        args = self._split_args(arg_tokens)
        arity = len(args)
        matches = [fn for fn in candidates if len(fn.parameters) == arity and fn.return_type]
        return_types = {fn.return_type for fn in matches}
        if len(return_types) == 1:
            return self.types.resolve(next(iter(return_types)))
        return TypeInfo("<unknown>", "unknown")

    @staticmethod
    def _clean(tokens: Sequence[Token]) -> list[Token]:
        return [t for t in tokens if t.kind not in IGNORABLE_KINDS]

    @staticmethod
    def _significant_indices(tokens: Sequence[Token], start: int, end: int) -> list[int]:
        return [i for i in range(max(start, 0), min(end, len(tokens))) if tokens[i].kind not in IGNORABLE_KINDS]

    @staticmethod
    def _find_token_index(tokens: Sequence[Token], start: int, end: int, line: int, column: int, name: str) -> int | None:
        for i in range(max(0, start), min(end, len(tokens))):
            t = tokens[i]
            if t.line == line and t.column == column and t.value == name:
                return i
        # Parser columns can differ in exotic declarators; line/name fallback remains conservative.
        matches = [i for i in range(max(0, start), min(end, len(tokens))) if tokens[i].line == line and tokens[i].value == name]
        return matches[0] if len(matches) == 1 else None

    @staticmethod
    def _find_statement_end(tokens: Sequence[Token], start: int, hard_end: int) -> int:
        round_d = square_d = curly_d = 0
        for i in range(start, min(hard_end, len(tokens))):
            v = tokens[i].value
            if v == "(": round_d += 1
            elif v == ")" and round_d: round_d -= 1
            elif v == "[": square_d += 1
            elif v == "]" and square_d: square_d -= 1
            elif v == "{": curly_d += 1
            elif v == "}" and curly_d: curly_d -= 1
            elif v == ";" and round_d == square_d == curly_d == 0:
                return i
        return min(hard_end, len(tokens))

    @staticmethod
    def _find_top_level_value(tokens: Sequence[Token], start: int, end: int, value: str) -> int | None:
        round_d = square_d = curly_d = 0
        for i in range(start, min(end, len(tokens))):
            v = tokens[i].value
            if v == "(": round_d += 1
            elif v == ")" and round_d: round_d -= 1
            elif v == "[": square_d += 1
            elif v == "]" and square_d: square_d -= 1
            elif v == "{": curly_d += 1
            elif v == "}" and curly_d: curly_d -= 1
            elif v == value and round_d == square_d == curly_d == 0:
                return i
        return None

    @staticmethod
    def _is_plain_assignment(tokens: Sequence[Token], idx: int, start: int, end: int) -> bool:
        # Tokenizer already distinguishes ==, +=, etc.; bare '=' is assignment.
        return tokens[idx].value == "=" and start <= idx < end

    @staticmethod
    def _is_declaration_assignment(anchor: Token, lhs: VariableInfo, declarations: Mapping[tuple[int, int, str], VariableInfo]) -> bool:
        # The declaration-initializer pass already handles these.  If the lhs was declared
        # on the same line before '=', treat it as declaration initialization.
        return any(v is lhs and line == lhs.line for (line, _col, _name), v in declarations.items() if line == anchor.line)

    def _assignment_lhs_variable(
        self,
        tokens: Sequence[Token],
        significant: Sequence[int],
        pos: int,
        variable_map: Mapping[str, list[VariableInfo]],
    ) -> VariableInfo | None:
        if pos <= 0:
            return None
        # Simple x = ...
        prev_idx = significant[pos - 1]
        prev = tokens[prev_idx]
        if prev.kind == TokenKind.IDENTIFIER:
            return self._resolve_variable(prev, variable_map)
        # this->x = ...
        if pos >= 3 and prev.kind == TokenKind.IDENTIFIER:
            return self._resolve_variable(prev, variable_map)
        return None

    @staticmethod
    def _matching_close(tokens: Sequence[Token], open_idx: int, opener: str, closer: str, hard_end: int) -> int | None:
        depth = 0
        for i in range(open_idx, min(hard_end + 1, len(tokens))):
            if tokens[i].kind in IGNORABLE_KINDS:
                continue
            if tokens[i].value == opener:
                depth += 1
            elif tokens[i].value == closer:
                depth -= 1
                if depth == 0:
                    return i
        return None

    @staticmethod
    def _matching_close_local(tokens: Sequence[Token], open_idx: int, opener: str, closer: str) -> int | None:
        depth = 0
        for i in range(open_idx, len(tokens)):
            if tokens[i].value == opener:
                depth += 1
            elif tokens[i].value == closer:
                depth -= 1
                if depth == 0:
                    return i
        return None

    @staticmethod
    def _find_matching_angle(tokens: Sequence[Token], open_idx: int) -> int | None:
        depth = 0
        for i in range(open_idx, len(tokens)):
            v = tokens[i].value
            if v == "<": depth += 1
            elif v == ">":
                depth -= 1
                if depth == 0: return i
            elif v == ">>":
                depth -= 2
                if depth <= 0: return i
        return None

    def _looks_like_type(self, tokens: Sequence[Token]) -> bool:
        if not tokens:
            return False
        text = tokens_to_compact_text(tokens)
        if self.types.resolve(text).category != "unknown":
            return True
        allowed = {"const", "volatile", "signed", "unsigned", "short", "long", "*", "&", "::"}
        return all(t.kind == TokenKind.IDENTIFIER or t.value in allowed for t in tokens)

    @staticmethod
    def _find_root_operator(tokens: Sequence[Token], operators: set[str]) -> int | None:
        round_d = square_d = curly_d = angle_d = 0
        # Right-to-left makes left-associative expressions split at the final operator of that precedence.
        for i in range(len(tokens) - 1, -1, -1):
            v = tokens[i].value
            if v == ")": round_d += 1
            elif v == "(" and round_d: round_d -= 1
            elif v == "]": square_d += 1
            elif v == "[" and square_d: square_d -= 1
            elif v == "}": curly_d += 1
            elif v == "{" and curly_d: curly_d -= 1
            elif v == ">": angle_d += 1
            elif v == "<" and angle_d: angle_d -= 1
            if round_d == square_d == curly_d == angle_d == 0 and v in operators:
                # Unary + / - are not binary roots.
                if v in {"+", "-"} and (i == 0 or tokens[i - 1].value in _NUMERIC_BINARY | _COMPARISONS | {"=", "(", ",", "?", ":", "&&", "||"}):
                    continue
                return i
        return None

    def _split_args(self, tokens: Sequence[Token]) -> list[list[Token]]:
        tokens = self._clean(tokens)
        if not tokens:
            return []
        out: list[list[Token]] = []
        current: list[Token] = []
        rd = sd = cd = ad = 0
        for t in tokens:
            v = t.value
            if v == "(": rd += 1
            elif v == ")" and rd: rd -= 1
            elif v == "[": sd += 1
            elif v == "]" and sd: sd -= 1
            elif v == "{": cd += 1
            elif v == "}" and cd: cd -= 1
            elif v == "<": ad += 1
            elif v == ">" and ad: ad -= 1
            elif v == ">>" and ad: ad = max(0, ad - 2)
            if v == "," and rd == sd == cd == ad == 0:
                out.append(current); current = []
            else:
                current.append(t)
        out.append(current)
        return out

    def _simple_operand_left(self, tokens: Sequence[Token], op_idx: int, hard_start: int) -> list[Token]:
        i = op_idx - 1
        while i >= hard_start and tokens[i].kind in IGNORABLE_KINDS:
            i -= 1
        if i < hard_start:
            return []
        if tokens[i].value == ")":
            open_idx = self._matching_open(tokens, i, "(", ")", hard_start)
            if open_idx is not None and open_idx > hard_start and tokens[open_idx - 1].kind == TokenKind.IDENTIFIER:
                return self._clean(tokens[open_idx - 1:i + 1])
            if open_idx is not None:
                return self._clean(tokens[open_idx:i + 1])
        if tokens[i].kind in {TokenKind.IDENTIFIER, TokenKind.NUMBER}:
            start = i
            if i - 1 >= hard_start and tokens[i - 1].value in {"+", "-"} and tokens[i].kind == TokenKind.NUMBER:
                start = i - 1
            return self._clean(tokens[start:i + 1])
        return []

    def _simple_operand_right(self, tokens: Sequence[Token], op_idx: int, hard_end: int) -> list[Token]:
        i = op_idx + 1
        while i < hard_end and tokens[i].kind in IGNORABLE_KINDS:
            i += 1
        if i >= hard_end:
            return []
        start = i
        if tokens[i].value in {"+", "-"} and i + 1 < hard_end and tokens[i + 1].kind == TokenKind.NUMBER:
            i += 1
        if tokens[i].kind in {TokenKind.IDENTIFIER, TokenKind.NUMBER}:
            if i + 1 < hard_end and tokens[i].kind == TokenKind.IDENTIFIER and tokens[i + 1].value == "(":
                close = self._matching_close(tokens, i + 1, "(", ")", hard_end)
                if close is not None:
                    return self._clean(tokens[start:close + 1])
            return self._clean(tokens[start:i + 1])
        if tokens[i].value == "(":
            close = self._matching_close(tokens, i, "(", ")", hard_end)
            if close is not None:
                return self._clean(tokens[i:close + 1])
        return []

    @staticmethod
    def _matching_open(tokens: Sequence[Token], close_idx: int, opener: str, closer: str, hard_start: int) -> int | None:
        depth = 0
        for i in range(close_idx, hard_start - 1, -1):
            if tokens[i].value == closer: depth += 1
            elif tokens[i].value == opener:
                depth -= 1
                if depth == 0: return i
        return None

    @staticmethod
    def _evaluate_constant(left: int | float | None, op: str, right: int | float | None) -> int | float | None:
        if left is None or right is None:
            return None
        try:
            if op == "+": return left + right
            if op == "-": return left - right
            if op == "*": return left * right
            if op == "/":
                if right == 0: return None
                if isinstance(left, int) and isinstance(right, int): return int(left / right)
                return left / right
            if op == "%":
                if right == 0: return None
                return left % right
            if op == "<<" and isinstance(left, int) and isinstance(right, int): return left << right
            if op == ">>" and isinstance(left, int) and isinstance(right, int): return left >> right
            if op == "&" and isinstance(left, int) and isinstance(right, int): return left & right
            if op == "|" and isinstance(left, int) and isinstance(right, int): return left | right
            if op == "^" and isinstance(left, int) and isinstance(right, int): return left ^ right
        except (ArithmeticError, ValueError, OverflowError):
            return None
        return None

    @staticmethod
    def _reverse_comparison(op: str) -> str:
        return {"<": ">", "<=": ">=", ">": "<", ">=": "<=", "==": "==", "!=": "!="}[op]

    @staticmethod
    def _range_comparison_truth(lo: int, hi: int, op: str, c: int) -> bool | None:
        if op == "<":
            if hi < c: return True
            if lo >= c: return False
        elif op == "<=":
            if hi <= c: return True
            if lo > c: return False
        elif op == ">":
            if lo > c: return True
            if hi <= c: return False
        elif op == ">=":
            if lo >= c: return True
            if hi < c: return False
        elif op == "==":
            if c < lo or c > hi: return False
        elif op == "!=":
            if c < lo or c > hi: return True
        return None

    def _emit(
        self,
        rule: str,
        severity: Severity,
        confidence: Confidence,
        source: SourceFileContext,
        token: Token,
        message: str,
        details: str,
        suggestion: str,
        tags: list[str],
    ) -> None:
        self.findings.append(Finding(
            checker="semantic_safety",
            rule=rule,
            severity=severity,
            confidence=confidence,
            location=SourceLocation(file=source.relative_path, line=token.line, column=token.column),
            message=message,
            details=details,
            suggestion=suggestion,
            evidence=[source.line_text(token.line).rstrip()],
            tags=tags,
        ))
