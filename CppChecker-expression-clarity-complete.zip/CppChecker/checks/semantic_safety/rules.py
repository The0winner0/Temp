from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class TypeInfo:
    name: str
    category: str  # integer, floating, bool, pointer, unknown
    bits: int | None = None
    signed: bool | None = None

    @property
    def is_integer(self) -> bool:
        return self.category == "integer"

    @property
    def is_floating(self) -> bool:
        return self.category == "floating"

    @property
    def min_value(self) -> int | None:
        if not self.is_integer or self.bits is None or self.signed is None:
            return None
        if self.signed:
            return -(1 << (self.bits - 1))
        return 0

    @property
    def max_value(self) -> int | None:
        if not self.is_integer or self.bits is None or self.signed is None:
            return None
        if self.signed:
            return (1 << (self.bits - 1)) - 1
        return (1 << self.bits) - 1


DEFAULT_RULES = {
    # Patch 1: type/conversion/range engine.
    "narrowing_integer": True,
    "signed_to_unsigned": True,
    "unsigned_to_signed": True,
    "float_to_integer": True,
    "integer_division_to_float": True,
    "argument_conversion": True,
    "return_conversion": True,
    "literal_out_of_range": True,
    "impossible_range_comparison": True,
    "unsigned_zero_comparison": True,
    "signed_unsigned_compare": True,
    "overflow_before_widening": True,
    "invalid_shift_width": True,
    # Patch 2 rules are accepted now but disabled until Patch 2 analyzer implements them.
    "assignment_in_condition": True,
    "chained_comparison": True,
    "contradictory_boolean": True,
    "bitwise_boolean_mixup": True,
    "suspicious_not_precedence": True,
    "unsigned_reverse_loop": True,
    "loop_bound_out_of_range": True,
    "division_by_zero": True,
    "self_assignment": True,
    "wrong_for_update_variable": True,
    "use_before_initialization": True,
    # Patch 3: arithmetic storage/precedence/loop progression.
    "constant_expression_overflow": True,
    "shift_before_widening": True,
    "compound_assignment_conversion": True,
    "bitwise_comparison_precedence": True,
    "zero_loop_step": True,
    "loop_direction_mismatch": True,
    "constant_update_overflow": True,
    "known_zero_divisor": True,
}


class TypeSystem:
    """Small deterministic C/C++ scalar type model.

    It is intentionally not a compiler ABI model.  The user-configured platform
    widths make implementation-defined built-in widths deterministic for this
    checker, while fixed-width stdint types remain exact.
    """

    def __init__(self, config: Mapping[str, Any]) -> None:
        platform = config.get("platform", {}) if isinstance(config.get("platform", {}), Mapping) else {}
        self.char_bits = int(platform.get("char_bits", 8))
        self.short_bits = int(platform.get("short_bits", 16))
        self.int_bits = int(platform.get("int_bits", 32))
        self.long_bits = int(platform.get("long_bits", 32))
        self.long_long_bits = int(platform.get("long_long_bits", 64))
        self.pointer_bits = int(platform.get("pointer_bits", 64))
        self.size_t_bits = int(platform.get("size_t_bits", self.pointer_bits))
        self.plain_char_signed = bool(platform.get("plain_char_signed", True))

        self.types: dict[str, TypeInfo] = {}
        self.aliases: dict[str, str] = {}
        self._install_builtins()
        self._install_custom(config.get("custom_types", {}))

    def _put_integer(self, names: tuple[str, ...], bits: int, signed: bool) -> None:
        canonical = names[0]
        info = TypeInfo(canonical, "integer", bits, signed)
        for name in names:
            self.types[self._normalize(name)] = info

    def _install_builtins(self) -> None:
        self._put_integer(("int8_t", "std::int8_t"), 8, True)
        self._put_integer(("uint8_t", "std::uint8_t"), 8, False)
        self._put_integer(("int16_t", "std::int16_t"), 16, True)
        self._put_integer(("uint16_t", "std::uint16_t"), 16, False)
        self._put_integer(("int32_t", "std::int32_t"), 32, True)
        self._put_integer(("uint32_t", "std::uint32_t"), 32, False)
        self._put_integer(("int64_t", "std::int64_t"), 64, True)
        self._put_integer(("uint64_t", "std::uint64_t"), 64, False)

        self._put_integer(("signed char",), self.char_bits, True)
        self._put_integer(("unsigned char",), self.char_bits, False)
        self._put_integer(("char",), self.char_bits, self.plain_char_signed)
        self._put_integer(("short", "short int", "signed short", "signed short int"), self.short_bits, True)
        self._put_integer(("unsigned short", "unsigned short int"), self.short_bits, False)
        self._put_integer(("int", "signed", "signed int"), self.int_bits, True)
        self._put_integer(("unsigned", "unsigned int"), self.int_bits, False)
        self._put_integer(("long", "long int", "signed long", "signed long int"), self.long_bits, True)
        self._put_integer(("unsigned long", "unsigned long int"), self.long_bits, False)
        self._put_integer(("long long", "long long int", "signed long long", "signed long long int"), self.long_long_bits, True)
        self._put_integer(("unsigned long long", "unsigned long long int"), self.long_long_bits, False)

        self._put_integer(("size_t", "std::size_t"), self.size_t_bits, False)
        self._put_integer(("ptrdiff_t", "std::ptrdiff_t"), self.pointer_bits, True)
        self._put_integer(("intptr_t", "std::intptr_t"), self.pointer_bits, True)
        self._put_integer(("uintptr_t", "std::uintptr_t"), self.pointer_bits, False)
        self._put_integer(("intmax_t", "std::intmax_t"), self.long_long_bits, True)
        self._put_integer(("uintmax_t", "std::uintmax_t"), self.long_long_bits, False)

        for bits in (8, 16, 32, 64):
            self._put_integer((f"int_least{bits}_t", f"std::int_least{bits}_t"), bits, True)
            self._put_integer((f"uint_least{bits}_t", f"std::uint_least{bits}_t"), bits, False)
            self._put_integer((f"int_fast{bits}_t", f"std::int_fast{bits}_t"), bits, True)
            self._put_integer((f"uint_fast{bits}_t", f"std::uint_fast{bits}_t"), bits, False)

        self.types[self._normalize("float")] = TypeInfo("float", "floating", 32, True)
        self.types[self._normalize("double")] = TypeInfo("double", "floating", 64, True)
        self.types[self._normalize("long double")] = TypeInfo("long double", "floating", 80, True)
        self.types[self._normalize("bool")] = TypeInfo("bool", "bool", 1, False)

    def _install_custom(self, custom: Any) -> None:
        if not isinstance(custom, Mapping):
            return
        for name, raw in custom.items():
            if isinstance(raw, str):
                self.aliases[self._normalize(str(name))] = self._normalize(raw)
                continue
            if not isinstance(raw, Mapping):
                continue
            kind = str(raw.get("kind", "unknown")).lower()
            if kind in {"signed", "unsigned", "integer"}:
                signed = bool(raw.get("signed", kind != "unsigned"))
                bits = raw.get("bits")
                if bits is not None:
                    self.types[self._normalize(str(name))] = TypeInfo(str(name), "integer", int(bits), signed)
            elif kind in {"float", "floating"}:
                self.types[self._normalize(str(name))] = TypeInfo(str(name), "floating", int(raw.get("bits", 64)), True)
            elif "alias" in raw:
                self.aliases[self._normalize(str(name))] = self._normalize(str(raw["alias"]))

    @staticmethod
    def _normalize(text: str) -> str:
        # The lightweight structural parser can conservatively include a preceding
        # preprocessor token in a return-type slice; directives are never type text.
        text = re.sub(r"#\s*include\s*[<\"].*?[>\"]", " ", text)
        text = re.sub(r"#\s*(?:define|pragma|if|ifdef|ifndef|endif|else|elif)\b[^\n]*", " ", text)
        text = text.replace("\t", " ").strip()
        for word in ("constexpr", "const", "volatile", "static", "extern", "register", "mutable", "typename"):
            text = text.replace(word, " ")
        text = text.replace(" &", "").replace("&", "").strip()
        while "  " in text:
            text = text.replace("  ", " ")
        text = text.replace(" :: ", "::").replace(" ::", "::").replace(":: ", "::")
        return text.strip()

    def register_alias(self, alias: str, target: str) -> None:
        if alias and target:
            self.aliases[self._normalize(alias)] = self._normalize(target)

    def resolve(self, type_text: str | None) -> TypeInfo:
        if not type_text:
            return TypeInfo("<unknown>", "unknown")
        raw = self._normalize(type_text)
        if "*" in raw:
            return TypeInfo(raw, "pointer", self.pointer_bits, False)
        raw = raw.replace("[", " ").split("]", 1)[0].strip()
        seen: set[str] = set()
        key = raw
        while key in self.aliases and key not in seen:
            seen.add(key)
            key = self.aliases[key]
        return self.types.get(key, TypeInfo(raw or "<unknown>", "unknown"))

    def integer_literal_type(self, value: int, suffix: str = "", base: int = 10) -> TypeInfo:
        s = suffix.lower()
        unsigned = "u" in s
        ll = "ll" in s
        l = "l" in s and not ll
        candidates: list[TypeInfo] = []
        if unsigned and ll:
            candidates = [self.resolve("unsigned long long")]
        elif unsigned and l:
            candidates = [self.resolve("unsigned long"), self.resolve("unsigned long long")]
        elif unsigned:
            candidates = [self.resolve("unsigned int"), self.resolve("unsigned long"), self.resolve("unsigned long long")]
        elif ll:
            candidates = [self.resolve("long long")]
        elif l:
            candidates = [self.resolve("long"), self.resolve("long long")]
        elif base == 10:
            candidates = [self.resolve("int"), self.resolve("long"), self.resolve("long long")]
        else:
            candidates = [
                self.resolve("int"), self.resolve("unsigned int"), self.resolve("long"),
                self.resolve("unsigned long"), self.resolve("long long"), self.resolve("unsigned long long"),
            ]
        for info in candidates:
            if info.min_value is not None and info.min_value <= value <= (info.max_value or 0):
                return info
        return candidates[-1] if candidates else self.resolve("int")


def merged_rule_config(config: Mapping[str, Any]) -> dict[str, bool]:
    out = dict(DEFAULT_RULES)
    raw = config.get("rules", {})
    if isinstance(raw, Mapping):
        for key, value in raw.items():
            if key in out:
                out[key] = bool(value)
    return out
