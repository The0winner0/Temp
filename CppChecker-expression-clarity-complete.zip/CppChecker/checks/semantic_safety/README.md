# Semantic Safety Checker — Patches 1 + 2 + 3

Pure-Python, conservative C/C++ semantic checks for legal constructs that commonly hide correctness bugs. No compiler, AST library, pip dependency, external executable, or network access is required.

## Patch 1 — numeric/type safety

- implicit integer narrowing;
- signed-to-unsigned and unsafe unsigned-to-signed conversions;
- floating-point to integer conversion;
- integer division before floating conversion;
- known function-argument and return conversion;
- constant/literal destination-range violations;
- signed/unsigned comparison hazards;
- impossible comparisons against integer ranges;
- unsigned `< 0` and `>= 0` conditions;
- `+` / `*` overflow before a later widening assignment;
- invalid shift widths;
- simple local `using`/`typedef` aliases and configurable custom scalar types.

Explicit C-style/C++ casts are treated as deliberate conversion intent. Unknown/ambiguous types or overloads are skipped rather than guessed.

## Patch 2 — common semantic mistakes

- bare assignment used as an `if`/`while`/`for` condition (`if (a = 1)`);
- intentional assignment-result comparisons such as `((p = next()) != nullptr)` are allowed;
- chained comparisons such as `0 < x < 10`;
- always-true `x != A || x != B` and impossible `x == A && x == B` patterns;
- bitwise `&`/`|` joining two boolean comparisons;
- `!flags & mask` / `!flags | mask` precedence hazards;
- unsigned reverse loops such as `for (uint32_t i=...; i >= 0; --i)`;
- loop bounds outside the loop variable's representable range;
- wrong loop update variable (`for (... i ...; ++j)`);
- literal division/modulo by zero;
- simple self-assignment (`x = x`);
- definite linear use-before-initialization for scalar/pointer locals.

## Patch 3 — arithmetic storage, precedence and loop progression

- definite constant-expression overflow/wrap **before** destination widening, e.g. `uint64_t x = 100000 * 100000` on a 32-bit `int` model;
- subtraction-before-widening hazards such as `uint64_t x = a32 - b32`;
- left-shift-before-widening hazards such as `uint64_t mask = one32 << bit`;
- compound-assignment conversion hazards (`uint8_t += uint32_t`, signed/unsigned mixes, floating result stored into integer);
- invalid compound shift counts (`x <<= 32` for a 32-bit `x`);
- bitmask/comparison precedence traps such as `flags & MASK == 0`;
- zero-step loops (`i += 0` / `i -= 0`);
- loops whose known constant step moves away from a known terminating bound;
- definite `++` / `--` or constant compound-update overflow from a known straight-line value;
- division/modulo by a variable known to be zero in the same straight-line region.

The small constant-state pass intentionally forgets values at branches, loops, nested blocks and opaque calls. It is not a general data-flow engine; this keeps findings high-confidence.

## Rule configuration

Every rule can be individually disabled under `checks.semantic_safety.rules` in `checker_config.json`. Type widths and custom scalar types remain configurable under `platform` and `custom_types`.
