from __future__ import annotations

from typing import Any, Mapping

from core.api import Checker, CheckerMetadata
from core.diagnostics import Finding
from core.source_context import ProjectContext

from .analyzer import SemanticSafetyAnalyzer


class SemanticSafetyChecker(Checker):
    metadata = CheckerMetadata(
        name="semantic_safety",
        description=(
            "Detects high-confidence legal-C/C++ mistakes involving implicit numeric "
            "conversion, ranges, arithmetic, conditions, loops, and initialization."
        ),
        version="1.1",
    )

    def run(self, context: ProjectContext, config: Mapping[str, Any]) -> list[Finding]:
        return SemanticSafetyAnalyzer(config).analyze(context)


def create_checker() -> Checker:
    return SemanticSafetyChecker()
