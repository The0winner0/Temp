"""Semantic safety checker package."""
