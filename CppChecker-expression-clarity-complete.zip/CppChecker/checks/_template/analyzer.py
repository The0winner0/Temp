from __future__ import annotations

from typing import Any, Mapping

from core.diagnostics import Finding
from core.source_context import ProjectContext


class TemplateAnalyzer:
    """Domain logic belongs here; this template intentionally reports nothing."""

    def __init__(self, config: Mapping[str, Any]) -> None:
        self.config = config

    def analyze(self, context: ProjectContext) -> list[Finding]:
        findings: list[Finding] = []

        # Common data available to every checker:
        #   context.files
        #   context.functions
        #   context.classes
        #   context.comments
        #   context.symbols
        #
        # For per-file access:
        #   source.tokens
        #   source.lines
        #   source.functions
        #   source.classes
        #   source.global_variables
        #
        # Add rule logic here and append core.diagnostics.Finding objects.

        return findings
