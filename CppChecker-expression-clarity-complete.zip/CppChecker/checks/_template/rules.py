"""Keep checker-specific rule defaults/constants here.

Copy checks/_template to checks/<new_checker>, rename metadata/config entries,
and implement logic without changing main.py or the core runner.
"""

DEFAULTS = {
    "enabled": False,
}
