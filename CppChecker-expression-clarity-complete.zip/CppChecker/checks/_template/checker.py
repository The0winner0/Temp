from __future__ import annotations

from typing import Any, Mapping

from core.api import Checker, CheckerMetadata
from core.diagnostics import Finding
from core.source_context import ProjectContext

from .analyzer import TemplateAnalyzer


class TemplateChecker(Checker):
    metadata = CheckerMetadata(
        name="template",
        description="Template showing the stable checker API.",
        version="1.0",
    )

    def run(self, context: ProjectContext, config: Mapping[str, Any]) -> list[Finding]:
        analyzer = TemplateAnalyzer(config)
        return analyzer.analyze(context)


def create_checker() -> Checker:
    return TemplateChecker()
