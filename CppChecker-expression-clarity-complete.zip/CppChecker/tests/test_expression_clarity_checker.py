from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.context_builder import ProjectContextBuilder
from core.config import load_config
from checks.expression_clarity.checker import ExpressionClarityChecker


DEFAULT_CONFIG = {
    "target_cpp": None,
    "check_if": True,
    "check_while": True,
    "check_for_condition": True,
    "check_switch": False,
    "check_return_expressions": False,
    "check_assignment_rhs": False,
    "require_comparison_grouping_in_logical": True,
    "require_bitwise_grouping": True,
    "require_arithmetic_grouping": True,
    "require_ternary_grouping": True,
    "analyze_header_definitions": False,
    "max_expression_tokens": 512,
}


class ExpressionClarityCheckerTests(unittest.TestCase):
    def analyze(self, source: str, config: dict | None = None):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "main.cpp").write_text(source, encoding="utf-8")
            cfg = load_config(None)
            cfg["project"]["extensions"] = [".cpp", ".hpp"]
            cfg["project"]["exclude"] = []
            context = ProjectContextBuilder().build(root, cfg)
            return ExpressionClarityChecker().run(context, config or DEFAULT_CONFIG)

    def rules(self, source: str) -> list[str]:
        return [f.rule for f in self.analyze(source)]

    def test_simple_additive_chain_is_allowed(self):
        self.assertEqual([], self.analyze("void f(int a,int b,int c,int d){ if(a+b+c+d){} }"))

    def test_bitwise_and_equality_mix_is_flagged(self):
        findings = self.analyze("void f(int var1,int var2){ if(var1 ^ var2 | 1 == 1){} }")
        self.assertTrue(any(f.rule == "EXPR102" for f in findings))

    def test_fully_grouped_bitwise_expression_is_allowed(self):
        src = "void f(int var1,int var2){ if((((var1 ^ var2) | 1) == 1)){} }"
        self.assertEqual([], self.analyze(src))

    def test_arithmetic_precedence_mix_is_flagged(self):
        findings = self.analyze("void f(int a,int b,int c,int d){ if(a*b + c/d){} }")
        self.assertTrue(any(f.rule == "EXPR105" for f in findings))

    def test_grouped_arithmetic_is_allowed(self):
        src = "void f(int a,int b,int c,int d){ if((a*b) + (c/d)){} }"
        self.assertEqual([], self.analyze(src))

    def test_logical_same_operator_chain_is_allowed(self):
        self.assertEqual([], self.analyze("void f(bool a,bool b,bool c){ if(a&&b&&c){} }"))

    def test_logical_mixed_precedence_is_flagged(self):
        findings = self.analyze("void f(bool a,bool b,bool c){ if(a&&b||c){} }")
        self.assertTrue(any(f.rule == "EXPR101" for f in findings))

    def test_grouped_logical_mix_is_allowed(self):
        self.assertEqual([], self.analyze("void f(bool a,bool b,bool c){ if((a&&b)||c){} }"))

    def test_comparison_inside_logical_requires_grouping_by_default(self):
        findings = self.analyze("void f(int a,int b,int c,int d){ if(a<b && c<d){} }")
        self.assertTrue(any(f.rule == "EXPR104" for f in findings))

    def test_grouped_comparisons_are_allowed(self):
        src = "void f(int a,int b,int c,int d){ if((a<b) && (c<d)){} }"
        self.assertEqual([], self.analyze(src))

    def test_function_arguments_are_independent(self):
        src = "bool foo(int,int); void f(int a,int b,int c,int d){ if(foo(a+b,c*d)){} }"
        self.assertEqual([], self.analyze(src))

    def test_mixed_precedence_inside_one_function_argument_is_flagged(self):
        src = "bool foo(int); void f(int a,int b,int c){ if(foo(a+b*c)){} }"
        self.assertTrue(any(f.rule == "EXPR105" for f in self.analyze(src)))

    def test_for_condition_is_checked(self):
        src = "void f(int n,bool ok){ for(int i=0; i<n && ok; ++i){} }"
        self.assertTrue(any(f.rule == "EXPR104" for f in self.analyze(src)))


    def test_nested_parentheses_do_not_hide_unparenthesized_mixed_precedence(self):
        src = "void f(int a,int b,bool c){ if((a<b && c)){} }"
        self.assertTrue(any(f.rule == "EXPR104" for f in self.analyze(src)))

    def test_template_call_does_not_look_like_relational_expression(self):
        src = "template<class T> bool foo(T,T); void f(int a,int b){ if(foo<int>(a,b)){} }"
        self.assertEqual([], self.analyze(src))

    def test_assignment_rhs_can_be_enabled(self):
        config = dict(DEFAULT_CONFIG)
        config["check_assignment_rhs"] = True
        findings = self.analyze("void f(int a,int b,int c){ int x; x=a+b*c; }", config)
        self.assertTrue(any(f.rule == "EXPR105" and f.metadata.get("context") == "assignment-rhs" for f in findings))

    def test_return_expression_can_be_enabled(self):
        config = dict(DEFAULT_CONFIG)
        config["check_return_expressions"] = True
        findings = self.analyze("int f(int a,int b,int c){ return a+b*c; }", config)
        self.assertTrue(any(f.rule == "EXPR105" and f.metadata.get("context") == "return" for f in findings))


if __name__ == "__main__":
    unittest.main()
