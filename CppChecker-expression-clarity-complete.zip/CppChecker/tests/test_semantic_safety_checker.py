from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.context_builder import ProjectContextBuilder
from core.config import load_config
from checks.semantic_safety.checker import SemanticSafetyChecker


BASE = {
    "target_cpp": "main.cpp",
    "platform": {
        "char_bits": 8, "short_bits": 16, "int_bits": 32, "long_bits": 32,
        "long_long_bits": 64, "pointer_bits": 64, "size_t_bits": 64,
        "plain_char_signed": True,
    },
    "custom_types": {"unit_t": {"kind": "unsigned", "bits": 32}},
}


class SemanticSafetyPatch1Tests(unittest.TestCase):
    def analyze(self, cpp: str, hpp: str = ""):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            (root / "main.cpp").write_text(cpp, encoding="utf-8")
            if hpp:
                (root / "api.hpp").write_text(hpp, encoding="utf-8")
            cfg = load_config(None)
            cfg["project"]["extensions"] = [".cpp", ".hpp"]
            cfg["project"]["exclude"] = []
            context = ProjectContextBuilder().build(root, cfg)
            return SemanticSafetyChecker().run(context, BASE)

    def rules(self, findings):
        return [f.rule for f in findings]

    def test_uint32_to_uint8_is_narrowing(self):
        findings = self.analyze("""
            #include <stdint.h>
            uint32_t get_value() { return 1000; }
            int main() { uint8_t small = get_value(); return 0; }
        """)
        self.assertIn("SEM100", self.rules(findings))

    def test_explicit_cast_suppresses_narrowing(self):
        findings = self.analyze("""
            #include <stdint.h>
            uint32_t get_value() { return 1000; }
            int main() { uint8_t small = (uint8_t)get_value(); return 0; }
        """)
        self.assertNotIn("SEM100", self.rules(findings))

    def test_literal_out_of_range(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint8_t small = 300; return 0; }
        """)
        self.assertIn("SEM200", self.rules(findings))

    def test_signed_unsigned_comparison(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { int32_t a = -1; uint32_t b = 3; if (a < b) return 1; return 0; }
        """)
        self.assertIn("SEM110", self.rules(findings))

    def test_unsigned_less_than_zero(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t a = 3; if (a < 0) return 1; return 0; }
        """)
        self.assertIn("SEM202", self.rules(findings))

    def test_impossible_type_range_comparison(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint8_t a = 3; if (a > 300) return 1; return 0; }
        """)
        self.assertIn("SEM201", self.rules(findings))

    def test_integer_division_assigned_to_double(self):
        findings = self.analyze("""
            int main() { int a = 1; int b = 2; double x = a / b; return 0; }
        """)
        self.assertIn("SEM104", self.rules(findings))

    def test_overflow_before_widening(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t w = 1; uint32_t h = 2; uint64_t area = w * h; return 0; }
        """)
        self.assertIn("SEM301", self.rules(findings))

    def test_cast_operand_prevents_pre_widening_warning(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t w = 1; uint32_t h = 2; uint64_t area = (uint64_t)w * h; return 0; }
        """)
        self.assertNotIn("SEM301", self.rules(findings))

    def test_invalid_shift_width(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t x = 1; uint32_t y = x << 32; return (int)y; }
        """)
        self.assertIn("SEM303", self.rules(findings))

    def test_function_argument_narrowing_from_header(self):
        findings = self.analyze(
            '#include "api.hpp"\nint main(){ uint32_t x=500; set_level(x); return 0; }',
            '#include <stdint.h>\nvoid set_level(uint8_t value);'
        )
        self.assertIn("SEM105", self.rules(findings))

    def test_return_narrowing(self):
        findings = self.analyze("""
            #include <stdint.h>
            uint8_t get_small() { uint32_t x = 500; return x; }
            int main() { return 0; }
        """)
        self.assertIn("SEM106", self.rules(findings))

    def test_typedef_alias_is_resolved(self):
        findings = self.analyze("""
            #include <stdint.h>
            typedef uint32_t unit_t;
            uint32_t get_value() { return 1000; }
            int main() { uint8_t small = get_value(); unit_t ok = get_value(); return (int)ok; }
        """)
        self.assertIn("SEM100", self.rules(findings))


class SemanticSafetyPatch2Tests(SemanticSafetyPatch1Tests):
    def test_assignment_in_condition(self):
        findings = self.analyze("""
            int main() { int a = 0; if (a = 1) return 1; return 0; }
        """)
        self.assertIn("SEM001", self.rules(findings))

    def test_explicit_assignment_result_comparison_is_allowed(self):
        findings = self.analyze("""
            int next_value();
            int main() { int a = 0; if ((a = next_value()) != 0) return 1; return 0; }
        """)
        self.assertNotIn("SEM001", self.rules(findings))

    def test_chained_comparison(self):
        findings = self.analyze("""
            int main() { int x = 5; if (0 < x < 10) return 1; return 0; }
        """)
        self.assertIn("SEM002", self.rules(findings))

    def test_always_true_not_equal_or(self):
        findings = self.analyze("""
            int main() { int x = 1; if (x != 1 || x != 2) return 1; return 0; }
        """)
        self.assertIn("SEM003", self.rules(findings))

    def test_impossible_equal_and(self):
        findings = self.analyze("""
            int main() { int x = 1; if (x == 1 && x == 2) return 1; return 0; }
        """)
        self.assertIn("SEM003", self.rules(findings))

    def test_bitwise_between_boolean_comparisons(self):
        findings = self.analyze("""
            int main() { int a = 1, b = 2; if ((a == 1) & (b == 2)) return 1; return 0; }
        """)
        self.assertIn("SEM004", self.rules(findings))

    def test_not_bitmask_precedence(self):
        findings = self.analyze("""
            int main() { unsigned flags = 1; unsigned mask = 1; if (!flags & mask) return 1; return 0; }
        """)
        self.assertIn("SEM005", self.rules(findings))

    def test_unsigned_reverse_loop(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t n = 10; for (uint32_t i = n - 1; i >= 0; --i) { } return 0; }
        """)
        self.assertIn("SEM204", self.rules(findings))

    def test_loop_bound_outside_uint8_range(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { for (uint8_t i = 0; i < 300; ++i) { } return 0; }
        """)
        self.assertIn("SEM205", self.rules(findings))

    def test_wrong_for_update_variable(self):
        findings = self.analyze("""
            int main() { int j = 0; for (int i = 0; i < 10; ++j) { } return j; }
        """)
        self.assertIn("SEM403", self.rules(findings))

    def test_division_by_literal_zero(self):
        findings = self.analyze("""
            int main() { int x = 10; int y = x / 0; return y; }
        """)
        self.assertIn("SEM310", self.rules(findings))

    def test_self_assignment(self):
        findings = self.analyze("""
            int main() { int x = 1; x = x; return x; }
        """)
        self.assertIn("SEM402", self.rules(findings))

    def test_definite_use_before_initialization(self):
        findings = self.analyze("""
            int main() { int x; int y = x + 1; return y; }
        """)
        self.assertIn("SEM400", self.rules(findings))

    def test_initialized_variable_not_reported(self):
        findings = self.analyze("""
            int main() { int x; x = 2; int y = x + 1; return y; }
        """)
        self.assertNotIn("SEM400", self.rules(findings))


class SemanticSafetyPatch3Tests(SemanticSafetyPatch2Tests):
    def test_constant_expression_overflow_before_widening(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint64_t x = 100000 * 100000; return (int)x; }
        """)
        self.assertIn("SEM300", self.rules(findings))

    def test_widened_operand_prevents_constant_expression_overflow(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint64_t x = (uint64_t)100000 * 100000; return (int)x; }
        """)
        self.assertNotIn("SEM300", self.rules(findings))

    def test_subtraction_can_underflow_before_widening(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t a=5; uint32_t b=7; uint64_t x = a - b; return (int)x; }
        """)
        self.assertIn("SEM301", self.rules(findings))

    def test_shift_before_widening(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t one=1; uint32_t bit=20; uint64_t mask = one << bit; return (int)mask; }
        """)
        self.assertIn("SEM304", self.rules(findings))

    def test_wide_left_shift_operand_is_allowed(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint64_t one=1; uint32_t bit=20; uint64_t mask = one << bit; return (int)mask; }
        """)
        self.assertNotIn("SEM304", self.rules(findings))

    def test_compound_assignment_wider_rhs(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint8_t small=1; uint32_t large=300; small += large; return small; }
        """)
        self.assertIn("SEM320", self.rules(findings))

    def test_compound_assignment_small_constant_not_noisy(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint8_t small=1; small += 1; return small; }
        """)
        self.assertNotIn("SEM320", self.rules(findings))

    def test_compound_shift_invalid_width(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint32_t x=1; x <<= 32; return (int)x; }
        """)
        self.assertIn("SEM303", self.rules(findings))

    def test_bitwise_comparison_precedence(self):
        findings = self.analyze("""
            int main() { unsigned flags=3; unsigned MASK=1; if (flags & MASK == 0) return 1; return 0; }
        """)
        self.assertIn("SEM006", self.rules(findings))

    def test_parenthesized_bitmask_comparison_is_allowed(self):
        findings = self.analyze("""
            int main() { unsigned flags=3; unsigned MASK=1; if ((flags & MASK) == 0) return 1; return 0; }
        """)
        self.assertNotIn("SEM006", self.rules(findings))

    def test_zero_loop_step(self):
        findings = self.analyze("""
            int main() { for (int i=0; i<10; i += 0) { } return 0; }
        """)
        self.assertIn("SEM207", self.rules(findings))

    def test_loop_direction_moves_away_from_bound(self):
        findings = self.analyze("""
            int main() { for (int i=10; i>0; ++i) { } return 0; }
        """)
        self.assertIn("SEM208", self.rules(findings))

    def test_correct_loop_direction_is_allowed(self):
        findings = self.analyze("""
            int main() { for (int i=10; i>0; --i) { } return 0; }
        """)
        self.assertNotIn("SEM208", self.rules(findings))

    def test_known_increment_overflow(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint8_t x = 255; ++x; return x; }
        """)
        self.assertIn("SEM321", self.rules(findings))

    def test_known_compound_overflow(self):
        findings = self.analyze("""
            #include <stdint.h>
            int main() { uint8_t x = 250; x += 10; return x; }
        """)
        self.assertIn("SEM321", self.rules(findings))

    def test_known_zero_variable_divisor(self):
        findings = self.analyze("""
            int main() { int divisor = 0; int x = 10 / divisor; return x; }
        """)
        self.assertIn("SEM311", self.rules(findings))

    def test_constant_state_is_dropped_at_branch(self):
        findings = self.analyze("""
            int main() { int divisor = 0; if (get_flag()) divisor = 2; int x = 10 / divisor; return x; }
        """)
        self.assertNotIn("SEM311", self.rules(findings))


if __name__ == "__main__":
    unittest.main()
