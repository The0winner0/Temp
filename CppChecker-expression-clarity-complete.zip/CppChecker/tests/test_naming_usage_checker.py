from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.config import load_config
from core.context_builder import ProjectContextBuilder
from checks.naming_usage.checker import NamingUsageChecker


BASE_CONFIG = {
    "check_naming": True,
    "check_unused": True,
    "check_unused_parameters": True,
    "check_undeclared": True,
    "rules": {
        "local_variable": r"^[a-z][a-z0-9_]*$",
        "parameter": r"^[a-z][a-z0-9_]*$",
        "class_field": r"^m_[a-z][a-z0-9_]*$",
        "static_class_field": r"^s_[a-z][a-z0-9_]*$",
        "global_variable": r"^g_[a-z][a-z0-9_]*$",
        "static_global_variable": r"^g_[a-z][a-z0-9_]*$",
        "local_constant": r"^[A-Z][A-Z0-9_]*$",
        "class_constant": r"^[A-Z][A-Z0-9_]*$",
        "global_constant": r"^[A-Z][A-Z0-9_]*$",
        "free_function": r"^[a-z][a-z0-9_]*$",
        "member_function": r"^[a-z][a-z0-9_]*$"
    }
}


class NamingUsageCheckerTests(unittest.TestCase):
    def _run(self, cpp: str, hpp: str | None = None, config: dict | None = None):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "main.cpp").write_text(cpp.strip(), encoding="utf-8")
            if hpp is not None:
                (root / "main.hpp").write_text(hpp.strip(), encoding="utf-8")
            context = ProjectContextBuilder().build(root, load_config(None))
            return NamingUsageChecker().run(context, config or BASE_CONFIG)

    def test_wide_integer_and_builtin_types_are_recognized(self):
        findings = self._run(
            r'''
            typedef unsigned int uint_t;
            typedef unsigned int unit_t;
            int work(int16_t count, uint32_t flags) {
                uint_t item_count = (uint_t)count;
                unit_t unit_count = item_count;
                int normal_value = (int)flags;
                double ratio_value = (double)normal_value;
                char char_value = 'x';
                return (int)(unit_count + ratio_value + char_value);
            }
            '''
        )
        undeclared = [f for f in findings if f.rule == "USE301"]
        self.assertEqual(undeclared, [])

    def test_naming_rules_are_category_specific(self):
        findings = self._run(
            r'''
            int BadFunction(int BadParameter) {
                int BadLocal = BadParameter;
                return BadLocal;
            }
            '''
        )
        names = {(f.rule, f.metadata.get("category"), f.metadata.get("symbol")) for f in findings}
        self.assertIn(("NAME101", "free_function", "BadFunction"), names)
        self.assertIn(("NAME102", "parameter", "BadParameter"), names)
        self.assertIn(("NAME102", "local_variable", "BadLocal"), names)

    def test_unused_local_and_parameter_are_reported(self):
        findings = self._run(
            r'''
            int work(int used_parameter, int unused_parameter) {
                int used_local = used_parameter;
                int unused_local = 10;
                return used_local;
            }
            '''
        )
        messages = {f.metadata.get("symbol"): f.rule for f in findings if f.rule.startswith("USE2")}
        self.assertEqual(messages.get("unused_local"), "USE201")
        self.assertEqual(messages.get("unused_parameter"), "USE202")
        self.assertNotIn("used_local", messages)
        self.assertNotIn("used_parameter", messages)

    def test_high_confidence_undeclared_variable_is_reported(self):
        findings = self._run(
            r'''
            int work(int input_value) {
                int output_value = input_value + missing_value;
                return output_value + missing_value;
            }
            '''
        )
        uses = [f for f in findings if f.rule == "USE301"]
        self.assertEqual(len(uses), 1)
        self.assertEqual(uses[0].metadata.get("symbol"), "missing_value")
        self.assertEqual(uses[0].metadata.get("occurrences"), 2)

    def test_functions_members_macros_enum_and_types_are_not_undeclared_variables(self):
        findings = self._run(
            r'''
            #define BUFFER_SIZE 32
            struct Item { int value; };
            enum Mode { mode_a, mode_b };
            int work(Item* item, Mode mode) {
                int value = ExternalApi(BUFFER_SIZE);
                item->value = value;
                if (mode == mode_a) value += 1;
                return value;
            }
            '''
        )
        undeclared = [f.metadata.get("symbol") for f in findings if f.rule == "USE301"]
        self.assertEqual(undeclared, [])

    def test_class_fields_and_member_function_rules(self):
        findings = self._run(
            r'''
            #include "main.hpp"
            int Data::BadMethod(int input_value) {
                m_value += input_value;
                return m_value;
            }
            ''',
            r'''
            struct Data {
                int m_value;
                int BadMethod(int input_value);
            };
            '''
        )
        symbols = {(f.metadata.get("category"), f.metadata.get("symbol")) for f in findings if f.rule.startswith("NAME")}
        self.assertIn(("member_function", "BadMethod"), symbols)
        # m_value follows configured field convention and should not be a naming finding.
        self.assertNotIn(("class_field", "m_value"), symbols)
        undeclared = [f for f in findings if f.rule == "USE301"]
        self.assertEqual(undeclared, [])

    def test_structured_binding_is_treated_as_declared(self):
        findings = self._run(
            r'''
            struct PairLike { int first; int second; };
            PairLike make_pair_like();
            int work() {
                auto [left_value, right_value] = make_pair_like();
                return left_value + right_value;
            }
            '''
        )
        self.assertEqual([f for f in findings if f.rule == "USE301"], [])
        self.assertEqual([f for f in findings if f.rule in {"USE201", "USE202"}], [])

    def test_if_initializer_variable_is_treated_as_declared(self):
        findings = self._run(
            r'''
            struct Node { int value; };
            Node* get_node();
            int work() {
                if (Node* node = get_node()) {
                    return node->value;
                }
                return 0;
            }
            '''
        )
        self.assertEqual([f for f in findings if f.rule == "USE301"], [])

    def test_target_cpp_limits_naming_scope_but_other_files_remain_context(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "main.cpp").write_text("int good_name() { int good_value = 1; return good_value; }", encoding="utf-8")
            (root / "other.cpp").write_text("int BadFunction() { int BadValue = 2; return BadValue; }", encoding="utf-8")
            context = ProjectContextBuilder().build(root, load_config(None))
            config = dict(BASE_CONFIG)
            config["target_cpp"] = "main.cpp"
            findings = NamingUsageChecker().run(context, config)
            self.assertFalse(any(f.metadata.get("symbol") in {"BadFunction", "BadValue"} for f in findings))


    def test_direct_initialization_variable_is_recognized(self):
        findings = self._run(
            r"""
            struct Box { Box(int); int value; };
            int work() {
                Box box_value(3);
                int count_value(2);
                return box_value.value + count_value;
            }
            """
        )
        self.assertEqual([f for f in findings if f.rule == "USE301"], [])
        self.assertFalse(any(f.rule == "USE201" and f.metadata.get("symbol") in {"box_value", "count_value"} for f in findings))

    def test_function_pointer_variable_is_recognized(self):
        findings = self._run(
            r"""
            int handler(int value) { return value; }
            int work(int value) {
                int (*callback)(int) = handler;
                return callback(value);
            }
            """
        )
        self.assertEqual([f for f in findings if f.rule == "USE301"], [])
        self.assertFalse(any(f.rule == "USE201" and f.metadata.get("symbol") == "callback" for f in findings))



if __name__ == "__main__":
    unittest.main()
