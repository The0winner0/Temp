from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.config import load_config
from core.context_builder import ProjectContextBuilder
from checks.language.checker import LanguageChecker
from checks.language.rules import load_dictionary


BASE_CONFIG = {
    "check_comments": True,
    "check_strings": True,
    "check_spelling": True,
    "check_grammar": True,
    "min_word_length": 3,
    "max_edit_distance": 2,
    "max_suggestions": 3,
    "report_unknown_without_suggestion": False,
    "ignore_words": [],
}


class LanguageCheckerTests(unittest.TestCase):
    def _run(self, cpp: str, hpp: str | None = None, config: dict | None = None):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "main.cpp").write_text(cpp.strip(), encoding="utf-8")
            if hpp is not None:
                (root / "main.hpp").write_text(hpp.strip(), encoding="utf-8")
            context = ProjectContextBuilder().build(root, load_config(None))
            return LanguageChecker().run(context, config or BASE_CONFIG)

    def test_dictionary_files_are_loaded(self):
        dictionary, files = load_dictionary()
        self.assertTrue(files)
        self.assertIn("function", dictionary)
        self.assertIn("allocator", dictionary)

    def test_comment_spelling_error_is_reported(self):
        findings = self._run(
            r'''
            int work() {
                // Calculate the lenght of the buffer.
                return 0;
            }
            '''
        )
        spelling = [f for f in findings if f.rule == "LANG101"]
        self.assertTrue(any(f.metadata.get("word", "").casefold() == "lenght" for f in spelling))
        hit = next(f for f in spelling if f.metadata.get("word", "").casefold() == "lenght")
        self.assertIn("length", hit.metadata.get("suggestions", []))

    def test_printf_string_is_checked(self):
        findings = self._run(
            r'''
            int printf(const char*, ...);
            int work() {
                printf("Allocation complted successfully: %d bytes", 4);
                return 0;
            }
            '''
        )
        words = {f.metadata.get("word", "").casefold() for f in findings if f.rule == "LANG101"}
        self.assertIn("complted", words)
        self.assertNotIn("printf", words)

    def test_code_identifier_mentioned_in_comment_is_not_spelling_error(self):
        findings = self._run(
            r'''
            int work() {
                int frameBuffr = 1;
                // frameBuffr stores the current value.
                return frameBuffr;
            }
            '''
        )
        words = {f.metadata.get("word", "").casefold() for f in findings if f.rule == "LANG101"}
        self.assertNotIn("framebuffr", words)

    def test_snake_identifier_in_comment_is_not_spelling_error(self):
        findings = self._run(
            r'''
            int work() {
                int packet_lenght = 1;
                // packet_lenght is provided by the caller.
                return packet_lenght;
            }
            '''
        )
        words = {f.metadata.get("word", "").casefold() for f in findings if f.rule == "LANG101"}
        self.assertNotIn("lenght", words)
        self.assertNotIn("packet", words)

    def test_paths_urls_and_format_specifiers_are_ignored(self):
        findings = self._run(
            r'''
            int printf(const char*, ...);
            int work() {
                // See https://example.com/docs/foo_bar and src/core/foo.cpp.
                printf("Read %zu bytes from C:\\temp\\foo.bin", 4);
                return 0;
            }
            '''
        )
        spell = [f for f in findings if f.rule == "LANG101"]
        bad = {f.metadata.get("word", "").casefold() for f in spell}
        self.assertFalse({"https", "example", "foo", "src", "cpp", "temp", "bin", "zu"} & bad)

    def test_then_than_rule(self):
        findings = self._run(
            r'''
            int work() {
                // This value is greater then the previous value.
                return 0;
            }
            '''
        )
        hits = [f for f in findings if f.rule == "LANG201"]
        self.assertEqual(len(hits), 1)
        self.assertIn("greater than", hits[0].suggestion)

    def test_correct_than_is_not_reported(self):
        findings = self._run(
            r'''
            int work() {
                // This value is greater than the previous value.
                return 0;
            }
            '''
        )
        self.assertEqual([f for f in findings if f.rule == "LANG201"], [])

    def test_repeated_word_and_modal_of_rules(self):
        findings = self._run(
            r'''
            int work() {
                // The the pointer should of been released here.
                return 0;
            }
            '''
        )
        rules = {f.rule for f in findings}
        self.assertIn("LANG200", rules)
        self.assertIn("LANG206", rules)

    def test_basic_tense_rules(self):
        findings = self._run(
            r'''
            int work() {
                // The function did not returned the value and does not uses the buffer.
                return 0;
            }
            '''
        )
        rules = {f.rule for f in findings}
        self.assertIn("LANG215", rules)
        self.assertIn("LANG216", rules)

    def test_raw_and_prefixed_raw_strings_are_checked(self):
        findings = self._run(
            r'''
            int work() {
                const char* a = R"(This mesage is visible)";
                const char* b = u8R"tag(Another mesage is visible)tag";
                return a[0] + b[0];
            }
            '''
        )
        words = [f.metadata.get("word", "").casefold() for f in findings if f.rule == "LANG101"]
        self.assertGreaterEqual(words.count("mesage"), 2)

    def test_grammar_can_be_disabled(self):
        config = dict(BASE_CONFIG)
        config["check_grammar"] = False
        findings = self._run(
            r'''
            int work() {
                // This value is greater then the other value.
                return 0;
            }
            ''',
            config=config,
        )
        self.assertFalse(any(f.rule.startswith("LANG2") for f in findings))


if __name__ == "__main__":
    unittest.main()
