from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from core.config import load_config
from core.context_builder import ProjectContextBuilder
from core.path_utils import ensure_within_root
from core.tokenizer import CppTokenizer, TokenKind


class TokenizerTests(unittest.TestCase):
    def test_comment_markers_inside_string_are_not_comments(self):
        source = 'const char* url = "https://example.test/a//b"; // real comment\n'
        tokens = CppTokenizer().tokenize(source)
        comments = [t for t in tokens if t.kind == TokenKind.COMMENT_LINE]
        strings = [t for t in tokens if t.kind == TokenKind.STRING]
        self.assertEqual(len(strings), 1)
        self.assertEqual(len(comments), 1)
        self.assertEqual(comments[0].value, "// real comment")


class PathSafetyTests(unittest.TestCase):
    def test_parent_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "root"
            root.mkdir()
            outside = Path(tmp) / "outside.cpp"
            outside.write_text("int x;", encoding="utf-8")
            with self.assertRaises(ValueError):
                ensure_within_root(outside, root)


class StructureTests(unittest.TestCase):
    def test_project_context_extracts_core_structure(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "sample.hpp").write_text(
                """
#pragma once
struct Buffer {
    char* data;
    int size;
    Buffer(int requested_size);
    ~Buffer();
};
int helper(const char* text, int count);
""".strip(),
                encoding="utf-8",
            )
            (root / "sample.cpp").write_text(
                """
#include \"sample.hpp\"
Buffer::Buffer(int requested_size) {
    data = nullptr;
    size = requested_size;
}
Buffer::~Buffer() {}
int helper(const char* text, int count) {
    int local_value = count;
    if (text) {
        char* copy = nullptr;
        for (int i = 0; i < count; ++i) {
            int nested_value = i;
        }
    }
    // real comment
    return local_value;
}
""".strip(),
                encoding="utf-8",
            )

            context = ProjectContextBuilder().build(root, load_config(None))
            self.assertEqual(len(context.classes), 1)
            cls = context.classes[0]
            self.assertEqual(cls.name, "Buffer")
            self.assertEqual({v.name for v in cls.fields}, {"data", "size"})

            definitions = {fn.qualified_name: fn for fn in context.function_definitions}
            self.assertIn("Buffer::Buffer", definitions)
            self.assertIn("Buffer::~Buffer", definitions)
            self.assertIn("helper", definitions)
            self.assertEqual(definitions["Buffer::Buffer"].owner_class, "Buffer")

            helper = definitions["helper"]
            names = {v.name for v in helper.local_variables}
            self.assertTrue({"local_value", "copy", "i", "nested_value", "text", "count"}.issubset(names))
            self.assertEqual(len(context.comments), 1)
            self.assertEqual(context.comments[0].file, "sample.cpp")

            declarations = {fn.qualified_name for fn in context.function_declarations}
            self.assertIn("helper", declarations)
            self.assertIn("Buffer::Buffer", declarations)
            self.assertIn("Buffer::~Buffer", declarations)


if __name__ == "__main__":
    unittest.main()
