from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from checks.memory.analyzer import MemoryAnalyzer
from core.config import load_config
from core.context_builder import ProjectContextBuilder


class MemoryCheckerTests(unittest.TestCase):
    def _analyze(self, files: dict[str, str], memory_config: dict | None = None):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for name, text in files.items():
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(text.strip(), encoding="utf-8")
            context = ProjectContextBuilder().build(root, load_config(None))
            config = {"enabled": True, "target_cpp": None, "custom_apis": []}
            if memory_config:
                config.update(memory_config)
            return MemoryAnalyzer(config).analyze(context)

    def test_local_malloc_leak_and_early_return(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void use(char* p);
                void f(bool fail) {
                    char* p = (char*)malloc(128);
                    if (fail) {
                        return;
                    }
                    free(p);
                }
            '''
        })
        leaks = [f for f in findings if f.rule == "MEM001"]
        self.assertEqual(len(leaks), 1)
        self.assertIn("p", leaks[0].message)

    def test_balanced_malloc_has_no_leak(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f() {
                    char* p = (char*)malloc(128);
                    free(p);
                }
            '''
        })
        self.assertFalse(any(f.rule == "MEM001" for f in findings))

    def test_new_array_requires_delete_array(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f(int n) {
                    int* p = new int[n];
                    delete p;
                }
            '''
        })
        self.assertTrue(any(f.rule == "MEM003" for f in findings))
        self.assertTrue(any(f.rule == "MEM001" for f in findings))

    def test_indexed_2d_allocation_cleanup_loops_pair(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f(int rows, int cols) {
                    int** a = new int*[rows];
                    for (int i = 0; i < rows; ++i) {
                        a[i] = new int[cols];
                    }
                    for (int i = 0; i < rows; ++i) {
                        delete[] a[i];
                    }
                    delete[] a;
                }
            '''
        })
        relevant = [f for f in findings if f.rule in {"MEM001", "MEM002", "MEM003"}]
        self.assertEqual(relevant, [])

    def test_indexed_2d_missing_inner_cleanup_is_reported(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f(int rows, int cols) {
                    int** a = new int*[rows];
                    for (int i = 0; i < rows; ++i) {
                        a[i] = new int[cols];
                    }
                    delete[] a;
                }
            '''
        })
        leaks = [f for f in findings if f.rule == "MEM001"]
        self.assertTrue(any("a[*]" in f.message for f in leaks))

    def test_custom_return_allocator(self):
        findings = self._analyze(
            {
                "sample.cpp": r'''
                    void* PoolAlloc(int size, int offset);
                    void PoolFree(void* p);
                    void f() {
                        void* p = PoolAlloc(64, 0);
                        PoolFree(p);
                    }
                '''
            },
            {
                "custom_apis": [
                    {
                        "allocator": "PoolAlloc",
                        "deallocator": "PoolFree",
                        "allocation_mode": "return"
                    }
                ]
            },
        )
        self.assertFalse(any(f.rule == "MEM001" for f in findings))

    def test_custom_out_arg_allocator(self):
        findings = self._analyze(
            {
                "sample.cpp": r'''
                    void BufferInit(char** p, int size, int offset);
                    void BufferDestroy(char** p);
                    void f() {
                        char* p = nullptr;
                        BufferInit(&p, 64, 4);
                        BufferDestroy(&p);
                    }
                '''
            },
            {
                "custom_apis": [
                    {
                        "allocator": "BufferInit",
                        "deallocator": "BufferDestroy",
                        "allocation_mode": "out_arg",
                        "target_arg": 0,
                        "deallocator_target_arg": 0
                    }
                ]
            },
        )
        self.assertFalse(any(f.rule == "MEM001" for f in findings))

    def test_class_field_can_be_freed_by_destructor_from_header_context(self):
        findings = self._analyze({
            "buffer.hpp": r'''
                class Buffer {
                    char* data;
                public:
                    Buffer();
                    ~Buffer();
                };
            ''',
            "buffer.cpp": r'''
                #include "buffer.hpp"
                Buffer::Buffer() {
                    data = (char*)malloc(100);
                }
                Buffer::~Buffer() {
                    free(data);
                }
            ''',
        })
        self.assertFalse(any(f.rule == "MEM007" for f in findings))

    def test_class_field_missing_release_is_reported(self):
        findings = self._analyze({
            "buffer.hpp": r'''
                class Buffer {
                    char* data;
                public:
                    Buffer();
                    ~Buffer();
                };
            ''',
            "buffer.cpp": r'''
                #include "buffer.hpp"
                Buffer::Buffer() {
                    data = (char*)malloc(100);
                }
                Buffer::~Buffer() {}
            ''',
        })
        self.assertTrue(any(f.rule == "MEM007" and "data" in f.message for f in findings))

    def test_borrowed_parameter_free_is_reported(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f(char* external) {
                    free(external);
                }
            '''
        })
        self.assertTrue(any(f.rule == "MEM006" for f in findings))


    def test_calloc_and_alias_free_pair(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f() {
                    int* p = (int*)calloc(10, sizeof(int));
                    int* q = p;
                    free(q);
                }
            '''
        })
        self.assertFalse(any(f.rule == "MEM001" for f in findings))

    def test_overwrite_before_free_is_reported(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f() {
                    char* p = (char*)malloc(10);
                    p = (char*)malloc(20);
                    free(p);
                }
            '''
        })
        self.assertTrue(any(f.rule == "MEM002" for f in findings))

    def test_double_free_is_reported(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f() {
                    char* p = (char*)malloc(10);
                    free(p);
                    free(p);
                }
            '''
        })
        self.assertTrue(any(f.rule == "MEM004" for f in findings))


    def test_constructor_initializer_list_allocation_is_tracked(self):
        findings = self._analyze({
            "buffer.hpp": r'''
                class Buffer {
                    int* data;
                public:
                    Buffer(int n);
                    ~Buffer();
                };
            ''',
            "buffer.cpp": r'''
                #include "buffer.hpp"
                Buffer::Buffer(int n) : data(new int[n]) {}
                Buffer::~Buffer() { delete[] data; }
            ''',
        })
        self.assertFalse(any(f.rule in {"MEM003", "MEM007"} for f in findings))

    def test_constructor_initializer_list_missing_release_is_reported(self):
        findings = self._analyze({
            "buffer.hpp": r'''
                class Buffer {
                    int* data;
                public:
                    Buffer(int n);
                    ~Buffer();
                };
            ''',
            "buffer.cpp": r'''
                #include "buffer.hpp"
                Buffer::Buffer(int n) : data(new int[n]) {}
                Buffer::~Buffer() {}
            ''',
        })
        self.assertTrue(any(f.rule == "MEM007" for f in findings))

    def test_class_release_mismatch_is_reported(self):
        findings = self._analyze({
            "buffer.hpp": r'''
                class Buffer {
                    int* data;
                public:
                    Buffer(int n);
                    ~Buffer();
                };
            ''',
            "buffer.cpp": r'''
                #include "buffer.hpp"
                Buffer::Buffer(int n) {
                    data = new int[n];
                }
                Buffer::~Buffer() {
                    delete data;
                }
            ''',
        })
        self.assertTrue(any(f.rule == "MEM003" for f in findings))
        self.assertTrue(any(f.rule == "MEM007" for f in findings))

    def test_nested_index_family_cleanup(self):
        findings = self._analyze({
            "sample.cpp": r'''
                void f(int n, int m, int k) {
                    int*** a = new int**[n];
                    for (int i = 0; i < n; ++i) {
                        a[i] = new int*[m];
                        for (int j = 0; j < m; ++j) {
                            a[i][j] = new int[k];
                        }
                    }
                    for (int i = 0; i < n; ++i) {
                        for (int j = 0; j < m; ++j) {
                            delete[] a[i][j];
                        }
                        delete[] a[i];
                    }
                    delete[] a;
                }
            '''
        })
        self.assertFalse(any(f.rule in {"MEM001", "MEM002", "MEM003"} for f in findings))

    def test_multiple_cpp_requires_target_when_no_unique_main(self):
        findings = self._analyze({
            "a.cpp": "void a() {}",
            "b.cpp": "void b() {}",
        })
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0].rule, "MEM000")

    def test_explicit_target_ignores_other_cpp_allocations(self):
        findings = self._analyze(
            {
                "a.cpp": "void a() { char* p = (char*)malloc(20); }",
                "b.cpp": "void b() { char* q = (char*)malloc(20); free(q); }",
            },
            {"target_cpp": "b.cpp"},
        )
        self.assertFalse(any(f.rule == "MEM001" for f in findings))


if __name__ == "__main__":
    unittest.main()
