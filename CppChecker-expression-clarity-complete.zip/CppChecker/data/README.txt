Checker-specific static data can live here or inside its checker folder.
Examples for later phases:
- english_words.txt
- cpp_words.txt
- project_words.txt

No runtime download mechanism is part of the backbone.
