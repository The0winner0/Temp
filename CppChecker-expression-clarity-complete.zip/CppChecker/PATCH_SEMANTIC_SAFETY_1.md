# Semantic Safety — Patch 1/2

Apply this patch first.

Adds the semantic-safety checker foundation and high-value numeric/type checks:

- deterministic built-in/fixed-width integer model;
- configurable platform widths and custom scalar types;
- local `using` / `typedef` alias resolution;
- conservative expression type inference;
- explicit-cast intent recognition;
- integer narrowing and signedness conversion checks;
- float-to-integer conversion;
- integer division before float conversion;
- function argument and return conversion checks when signatures are known;
- literal/range impossibility checks;
- signed/unsigned comparison hazard;
- `unsigned < 0` / `unsigned >= 0`;
- overflow-before-widening for `+` / `*`;
- invalid shift count.

Patch 2 builds common operator, loop, and initialization mistakes on this type engine.
