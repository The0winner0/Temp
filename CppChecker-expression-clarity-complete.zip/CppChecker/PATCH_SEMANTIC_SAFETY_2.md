# Semantic Safety — Patch 2/2

Apply after Patch 1.

Extends the same `checks/semantic_safety/` module with high-confidence common-mistake detection:

- `if (a = 1)` / assignment-as-condition;
- chained comparisons (`0 < x < 10`);
- contradictory/tautological equality logic;
- bitwise-vs-logical boolean mistakes;
- `!` + bitmask precedence traps;
- unsigned reverse-loop nontermination;
- loop bounds outside loop-variable range;
- wrong variable updated by a `for` loop;
- literal divide/modulo by zero;
- self-assignment;
- definite use-before-initialization.

Patch 2 intentionally reuses the Patch 1 type engine. It does not add a second parser or duplicate type logic.
