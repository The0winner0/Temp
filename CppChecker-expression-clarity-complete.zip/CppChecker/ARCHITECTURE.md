# Backbone architecture

## `main.py`
CLI only. Loads configuration, builds one shared project context, loads enabled checker plugins, runs them, filters findings, and reports results.

## `core/config.py`
Standard-library JSON configuration loader with defaults and deep merge.

## `core/path_utils.py`
Recursive file discovery and root-boundary enforcement. Paths outside the selected root are rejected. Symlinks are ignored unless explicitly enabled.

## `core/tokenizer.py`
Stateful C/C++ lexical tokenizer. Separates comments and string/character literals so checker logic does not confuse source-like text inside them with actual code. Handles preprocessor directives, raw strings, common multi-character operators, identifiers, and numbers.

## `core/structure_parser.py`
Conservative parser over tokens. Extracts class/struct bodies, function definitions, parameters, and a conservative subset of variable declarations. It deliberately does not claim complete C++ parsing.

## `core/source_context.py`
Shared data model visible to checker modules: comments, variables, functions, classes, source files, symbol index, and project context.

## `core/symbol_index.py`
Builds cross-file lookup tables for discovered functions, classes, and variables.

## `core/expression_utils.py`
Neutral token helpers such as delimiter-aware splitting and token text reconstruction. Domain-specific checker rules do not belong here.

## `core/api.py`
Stable plugin API. Every checker subclasses `Checker` and exposes metadata plus `run(context, config)`.

## `core/registry.py`
Dynamically loads only enabled checker packages. A new checker requires no edit to `main.py`.

## `core/runner.py`
Runs each checker independently. One checker exception is captured and does not stop the remaining checks.

## `core/diagnostics.py`
Common severity/confidence enums and `Finding` format.

## `core/reporter.py`
Human-readable console output and optional JSON report output.

## Checker boundary

A checker may depend on `core.*` APIs. The core must never import a concrete checker. Checker-specific state machines, regexes, spelling logic, ownership rules, etc. stay inside that checker package.

Recommended checker layout:

```text
checks/name/
├── __init__.py
├── checker.py   # API adapter
├── analyzer.py  # domain logic
└── rules.py     # constants/default rule definitions
```

The `rules.py` file is optional; 2-file modules are valid where sufficient.


## Memory checker

`checks/memory/` is the first concrete checker and remains outside the core. The only backbone change required for it was a structural-parser correction for constructor initializer lists so definitions such as `A::A() : p(new T) {}` are identified as constructors rather than as a false function named `p`. Ownership/path state, allocator rules, indexed-family handling, custom APIs, and memory diagnostics remain entirely inside the memory checker package.


## Naming/usage checker

`checks/naming_usage/` is a concrete checker that consumes the existing structural model without making `main.py` checker-aware. Its `rules.py` owns configurable regex categories and known C/C++ type/keyword definitions; `analyzer.py` owns naming classification, extra conservative declaration recognition, reference counting, and undeclared-variable filtering. Ambiguous symbols are skipped rather than guessed.


## Language checker

`checks/language/` consumes comment and string tokens directly from the shared tokenizer. `rules.py` owns dictionary discovery and narrow grammar patterns; `analyzer.py` owns identifier suppression, prose masking, spelling suggestions, and grammar diagnostics. Every `.txt` recursively under the checker directory is loaded as a newline-delimited dictionary, so project terminology can be added without changing Python/config. The checker intentionally does not attempt general NLP grammar analysis.

The tokenizer also recognizes prefixed raw string literals (`u8R`, `uR`, `UR`, `LR`) so language checking covers these without special-case source scanning.

## Semantic safety checker

`checks/semantic_safety/` is a pure-Python conservative semantic layer for legal C/C++ constructs that can silently change values or behavior. It consumes the existing token/structure model and does not require compiler semantics. Patch 1 provides scalar type resolution, typedef/using aliases, expression inference, conversion/range analysis, function signature lookup, and arithmetic-width checks. Patch 2 adds high-confidence condition/operator/loop/state rules. Patch 3 adds constant-expression overflow, compound-assignment conversion checks, bitmask/comparison precedence, shift/subtraction-before-widening, loop-progress validation, and a deliberately limited straight-line constant-state pass.

The checker must skip unknown/ambiguous types, unresolved overloads, macros requiring expansion, and complex user-defined expressions rather than guess. Explicit casts represent deliberate conversion intent and suppress implicit-conversion diagnostics.


## Expression clarity module

`checks/expression_clarity/` is independent from semantic correctness analysis. It uses tokenizer output to identify expression sites and checks whether explicit parentheses separate different precedence families. It must not guess intended semantics or rewrite expressions automatically. `main.py` remains unaware of the module and discovers it through the normal checker registry.
