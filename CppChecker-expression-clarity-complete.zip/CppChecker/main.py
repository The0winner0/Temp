from __future__ import annotations

import argparse
from pathlib import Path

from core.config import load_config
from core.context_builder import ProjectContextBuilder
from core.diagnostics import Confidence, Severity, filter_findings
from core.registry import CheckerRegistry
from core.path_utils import ensure_within_root
from core.reporter import print_console, write_json
from core.runner import run_checkers


def _csv_set(value: str | None) -> set[str] | None:
    if value is None:
        return None
    return {part.strip() for part in value.split(",") if part.strip()}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Offline modular C/C++ source checker backbone."
    )
    parser.add_argument(
        "root",
        nargs="?",
        default=".",
        help="Analysis root. Recursive access is confined to this directory.",
    )
    parser.add_argument(
        "--config",
        default="checker_config.json",
        help="JSON configuration file. Defaults to checker_config.json.",
    )
    parser.add_argument(
        "--only",
        help="Comma-separated checker names. Overrides enabled flags.",
    )
    parser.add_argument(
        "--disable",
        help="Comma-separated checker names to disable for this run.",
    )
    parser.add_argument(
        "--list-checkers",
        action="store_true",
        help="List discovered checker packages and exit.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    launch_root = Path.cwd().resolve()
    try:
        root = ensure_within_root(Path(args.root), launch_root)
    except ValueError as exc:
        print(f"[ERROR] {exc}")
        return 2
    if not root.is_dir():
        print(f"[ERROR] Analysis root is not a directory: {root}")
        return 2

    registry = CheckerRegistry()
    if args.list_checkers:
        for name in registry.available():
            print(name)
        return 0

    config_path = Path(args.config)
    if not config_path.is_absolute():
        config_path = root / config_path
    try:
        config_path = ensure_within_root(config_path, launch_root)
    except ValueError as exc:
        print(f"[ERROR] {exc}")
        return 2

    if config_path.exists():
        effective_config = config_path
    elif args.config == "checker_config.json":
        bundled_config = Path(__file__).resolve().parent / "checker_config.json"
        try:
            bundled_config = ensure_within_root(bundled_config, launch_root)
        except ValueError:
            bundled_config = None
        effective_config = bundled_config if bundled_config and bundled_config.exists() else None
    else:
        effective_config = config_path

    try:
        config = load_config(effective_config)
    except (OSError, ValueError) as exc:
        print(f"[ERROR] Could not load configuration: {exc}")
        return 2

    try:
        context = ProjectContextBuilder().build(root, config)
    except OSError as exc:
        print(f"[ERROR] Could not read source tree: {exc}")
        return 2
    checkers = registry.load_enabled(
        config.get("checks", {}),
        only=_csv_set(args.only),
        disabled=_csv_set(args.disable) or set(),
    )

    findings, checker_errors = run_checkers(context, checkers)

    reporting = config.get("reporting", {})
    findings = filter_findings(
        findings,
        minimum_severity=Severity.parse(reporting.get("minimum_severity", "info")),
        minimum_confidence=Confidence.parse(reporting.get("minimum_confidence", "low")),
    )

    definition_count = sum(1 for fn in context.functions if fn.is_definition)
    declaration_count = len(context.functions) - definition_count
    print(
        f"Analyzed {len(context.files)} source/header file(s), "
        f"{definition_count} function definition(s), "
        f"{declaration_count} declaration(s), "
        f"{len(context.classes)} class/struct definition(s)."
    )
    print_console(findings, show_summary=bool(reporting.get("show_summary", True)))

    for error in checker_errors:
        print(f"[CHECKER ERROR] {error}")

    json_output = reporting.get("json_output")
    if json_output:
        output_path = Path(json_output)
        if not output_path.is_absolute():
            output_path = root / output_path
        try:
            output_path = ensure_within_root(output_path, launch_root)
        except ValueError as exc:
            print(f"[ERROR] {exc}")
            return 2
        write_json(findings, output_path)

    return 1 if checker_errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
