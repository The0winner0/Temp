from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

from .path_utils import discover_source_files, normalize_root, relative_posix
from .source_context import CommentInfo, ProjectContext, SourceFileContext, SymbolIndex
from .structure_parser import StructureParser
from .symbol_index import build_symbol_index
from .tokenizer import CppTokenizer, TokenKind


class ProjectContextBuilder:
    def __init__(self) -> None:
        self.tokenizer = CppTokenizer()
        self.parser = StructureParser()

    def build(self, root: str | Path, config: Mapping[str, Any]) -> ProjectContext:
        root_path = normalize_root(root)
        project_config = config.get("project", {})
        files = discover_source_files(
            root_path,
            extensions=project_config.get("extensions", []),
            exclude_patterns=project_config.get("exclude", []),
            follow_symlinks=bool(project_config.get("follow_symlinks", False)),
        )
        encoding = str(project_config.get("encoding", "utf-8"))

        contexts: list[SourceFileContext] = []
        for path in files:
            try:
                source = path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                source = path.read_text(encoding=encoding, errors="replace")

            tokens = self.tokenizer.tokenize(source)
            parsed = self.parser.parse(tokens)
            comments = self._comments_from_tokens(tokens)
            relative_path = relative_posix(path, root_path)
            self._annotate_file(relative_path, parsed.classes, parsed.functions, parsed.globals, comments)
            contexts.append(
                SourceFileContext(
                    path=path,
                    relative_path=relative_path,
                    source=source,
                    lines=source.splitlines(),
                    tokens=tokens,
                    comments=comments,
                    functions=parsed.functions,
                    classes=parsed.classes,
                    global_variables=parsed.globals,
                )
            )

        self._resolve_cross_file_method_owners(contexts)
        project = ProjectContext(root=root_path, files=contexts, symbols=SymbolIndex())
        project.symbols = build_symbol_index(project)
        return project

    @staticmethod
    def _annotate_file(relative_path, classes, functions, globals_, comments) -> None:
        for comment in comments:
            comment.file = relative_path
        for cls in classes:
            cls.file = relative_path
            for field in cls.fields:
                field.file = relative_path
        for function in functions:
            function.file = relative_path
            for parameter in function.parameters:
                parameter.file = relative_path
            for variable in function.local_variables:
                variable.file = relative_path
        for variable in globals_:
            variable.file = relative_path

    @staticmethod
    def _resolve_cross_file_method_owners(contexts: list[SourceFileContext]) -> None:
        classes_by_name = {
            cls.name: cls
            for source in contexts
            for cls in source.classes
        }
        for source in contexts:
            for function in source.functions:
                if function.owner_class is None and "::" in function.qualified_name:
                    candidate = function.qualified_name.split("::")[-2]
                    if candidate in classes_by_name:
                        function.owner_class = candidate
                if function.owner_class and function.is_definition:
                    cls = classes_by_name.get(function.owner_class)
                    if cls is not None and function not in cls.methods:
                        cls.methods.append(function)

    @staticmethod
    def _comments_from_tokens(tokens):
        comments: list[CommentInfo] = []
        for token in tokens:
            if token.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK}:
                continue
            end_line = token.line + token.value.count("\n")
            comments.append(
                CommentInfo(
                    kind="line" if token.kind == TokenKind.COMMENT_LINE else "block",
                    text=token.value,
                    line=token.line,
                    column=token.column,
                    end_line=end_line,
                )
            )
        return comments
