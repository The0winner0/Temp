from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable

from .tokenizer import Token


@dataclass(slots=True)
class CommentInfo:
    kind: str
    text: str
    line: int
    column: int
    end_line: int
    file: str = ""


@dataclass(slots=True)
class ParameterInfo:
    name: str | None
    type_text: str
    line: int
    column: int
    file: str = ""


@dataclass(slots=True)
class VariableInfo:
    name: str
    type_text: str
    category: str  # local, parameter, field, global, unknown
    line: int
    column: int
    const: bool = False
    constexpr: bool = False
    static: bool = False
    pointer_depth: int = 0
    reference: bool = False
    array: bool = False
    owner_function: str | None = None
    owner_class: str | None = None
    confidence: str = "high"
    file: str = ""


@dataclass(slots=True)
class FunctionInfo:
    name: str
    qualified_name: str
    return_type: str
    parameters: list[ParameterInfo]
    start_line: int
    end_line: int
    body_start_token: int
    body_end_token: int
    signature_start_token: int
    signature_end_token: int
    owner_class: str | None = None
    is_constructor: bool = False
    is_destructor: bool = False
    is_definition: bool = True
    local_variables: list[VariableInfo] = field(default_factory=list)
    file: str = ""


@dataclass(slots=True)
class ClassInfo:
    name: str
    kind: str  # class or struct
    start_line: int
    end_line: int
    body_start_token: int
    body_end_token: int
    fields: list[VariableInfo] = field(default_factory=list)
    methods: list[FunctionInfo] = field(default_factory=list)
    file: str = ""


@dataclass(slots=True)
class SourceFileContext:
    path: Path
    relative_path: str
    source: str
    lines: list[str]
    tokens: list[Token]
    comments: list[CommentInfo] = field(default_factory=list)
    functions: list[FunctionInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    global_variables: list[VariableInfo] = field(default_factory=list)

    def line_text(self, line: int) -> str:
        if line < 1 or line > len(self.lines):
            return ""
        return self.lines[line - 1]


@dataclass(slots=True)
class SymbolIndex:
    functions_by_name: dict[str, list[FunctionInfo]] = field(default_factory=dict)
    classes_by_name: dict[str, list[ClassInfo]] = field(default_factory=dict)
    variables_by_name: dict[str, list[VariableInfo]] = field(default_factory=dict)

    def add_function(self, function: FunctionInfo) -> None:
        self.functions_by_name.setdefault(function.name, []).append(function)
        if function.qualified_name != function.name:
            self.functions_by_name.setdefault(function.qualified_name, []).append(function)

    def add_class(self, cls: ClassInfo) -> None:
        self.classes_by_name.setdefault(cls.name, []).append(cls)

    def add_variable(self, variable: VariableInfo) -> None:
        self.variables_by_name.setdefault(variable.name, []).append(variable)


@dataclass(slots=True)
class ProjectContext:
    root: Path
    files: list[SourceFileContext]
    symbols: SymbolIndex

    @property
    def functions(self) -> list[FunctionInfo]:
        return [fn for file in self.files for fn in file.functions]

    @property
    def function_definitions(self) -> list[FunctionInfo]:
        return [fn for fn in self.functions if fn.is_definition]

    @property
    def function_declarations(self) -> list[FunctionInfo]:
        return [fn for fn in self.functions if not fn.is_definition]

    @property
    def classes(self) -> list[ClassInfo]:
        return [cls for file in self.files for cls in file.classes]

    @property
    def comments(self) -> list[CommentInfo]:
        return [comment for file in self.files for comment in file.comments]

    def source_file(self, relative_path: str) -> SourceFileContext | None:
        normalized = relative_path.replace("\\", "/")
        for source in self.files:
            if source.relative_path == normalized:
                return source
        return None

    def iter_files(self, extensions: Iterable[str] | None = None):
        if extensions is None:
            yield from self.files
            return
        wanted = {ext.lower() for ext in extensions}
        for file in self.files:
            if file.path.suffix.lower() in wanted:
                yield file
