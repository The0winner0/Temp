from __future__ import annotations

import importlib
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .api import Checker


@dataclass(slots=True)
class LoadedChecker:
    name: str
    checker: Checker
    config: Mapping[str, Any]


class CheckerRegistry:
    """Loads checker packages without requiring changes to main.py."""

    def __init__(self, package: str = "checks") -> None:
        self.package = package

    def available(self) -> list[str]:
        package_module = importlib.import_module(self.package)
        package_paths = list(getattr(package_module, "__path__", []))
        names: set[str] = set()
        for package_path in package_paths:
            root = Path(package_path)
            if not root.exists():
                continue
            for child in root.iterdir():
                if not child.is_dir() or child.name.startswith("_"):
                    continue
                if (child / "checker.py").exists():
                    names.add(child.name)
        return sorted(names)

    def load_enabled(
        self,
        checks_config: Mapping[str, Any],
        *,
        only: set[str] | None = None,
        disabled: set[str] | None = None,
    ) -> list[LoadedChecker]:
        disabled = disabled or set()
        result: list[LoadedChecker] = []

        for name, raw_config in checks_config.items():
            if name.startswith("_"):
                continue
            config = raw_config if isinstance(raw_config, dict) else {"enabled": bool(raw_config)}
            enabled = bool(config.get("enabled", False))
            if only is not None:
                enabled = name in only
            if name in disabled:
                enabled = False
            if not enabled:
                continue

            module = importlib.import_module(f"{self.package}.{name}.checker")
            factory = getattr(module, "create_checker", None)
            if factory is None:
                raise RuntimeError(
                    f"Checker '{name}' must expose create_checker() in checks/{name}/checker.py"
                )
            checker = factory()
            if not isinstance(checker, Checker):
                raise TypeError(f"Checker '{name}' does not implement core.api.Checker")
            result.append(LoadedChecker(name=name, checker=checker, config=config))

        return result
