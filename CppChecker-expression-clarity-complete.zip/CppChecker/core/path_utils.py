from __future__ import annotations

import fnmatch
from pathlib import Path
from typing import Iterable


DEFAULT_EXTENSIONS = (
    ".c", ".cc", ".cpp", ".cxx",
    ".h", ".hh", ".hpp", ".hxx",
)


def normalize_root(root: str | Path) -> Path:
    resolved = Path(root).resolve()
    if not resolved.exists():
        raise FileNotFoundError(f"Analysis root does not exist: {resolved}")
    if not resolved.is_dir():
        raise NotADirectoryError(f"Analysis root is not a directory: {resolved}")
    return resolved


def ensure_within_root(path: str | Path, root: str | Path) -> Path:
    resolved_root = Path(root).resolve()
    resolved_path = Path(path).resolve()
    try:
        resolved_path.relative_to(resolved_root)
    except ValueError as exc:
        raise ValueError(
            f"Path escapes analysis root and is not allowed: {resolved_path}"
        ) from exc
    return resolved_path


def relative_posix(path: str | Path, root: str | Path) -> str:
    path = ensure_within_root(path, root)
    root = Path(root).resolve()
    return path.relative_to(root).as_posix()


def _matches_any(relative_path: str, patterns: Iterable[str]) -> bool:
    path = relative_path.replace("\\", "/")
    for pattern in patterns:
        normalized = pattern.replace("\\", "/")
        if fnmatch.fnmatch(path, normalized):
            return True
        # Make directory-style exclusions such as "build/**" practical.
        prefix = normalized[:-3] if normalized.endswith("/**") else None
        if prefix and (path == prefix or path.startswith(prefix + "/")):
            return True
    return False


def discover_source_files(
    root: str | Path,
    *,
    extensions: Iterable[str] = DEFAULT_EXTENSIONS,
    exclude_patterns: Iterable[str] = (),
    follow_symlinks: bool = False,
) -> list[Path]:
    root = normalize_root(root)
    ext_set = {ext.lower() if ext.startswith(".") else f".{ext.lower()}" for ext in extensions}
    found: list[Path] = []

    for candidate in root.rglob("*"):
        if candidate.is_symlink() and not follow_symlinks:
            continue
        if not candidate.is_file():
            continue

        try:
            resolved = ensure_within_root(candidate, root)
        except ValueError:
            continue

        rel = resolved.relative_to(root).as_posix()
        if _matches_any(rel, exclude_patterns):
            continue
        if resolved.suffix.lower() not in ext_set:
            continue
        found.append(resolved)

    return sorted(found, key=lambda p: p.as_posix().lower())
