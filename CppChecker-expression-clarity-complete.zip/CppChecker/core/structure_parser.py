from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from .expression_utils import last_identifier, matching_pairs, split_top_level, tokens_to_compact_text
from .source_context import ClassInfo, FunctionInfo, ParameterInfo, VariableInfo
from .tokenizer import Token, TokenKind


_CONTROL_NAMES = {
    "if", "for", "while", "switch", "catch", "sizeof", "alignof",
    "decltype", "static_assert", "return", "new", "delete",
}

_DECLARATION_SKIP_PREFIXES = {
    "return", "break", "continue", "goto", "throw", "using", "typedef",
    "static_assert", "case", "default", "delete", "class", "struct", "enum",
    "namespace", "union",
}

_TYPE_QUALIFIERS = {
    "const", "constexpr", "volatile", "static", "extern", "mutable", "register",
    "inline", "thread_local", "signed", "unsigned", "short", "long", "typename",
}


@dataclass(slots=True)
class ParseResult:
    classes: list[ClassInfo]
    functions: list[FunctionInfo]
    globals: list[VariableInfo]


class StructureParser:
    """Conservative structural parser for checker support, not a C++ compiler."""

    def parse(self, tokens: Sequence[Token]) -> ParseResult:
        brace_pairs = matching_pairs(tokens, "{", "}")
        paren_pairs = matching_pairs(tokens, "(", ")")

        classes = self._parse_classes(tokens, brace_pairs)
        functions = self._parse_functions(tokens, brace_pairs, paren_pairs, classes)
        declarations = self._parse_function_declarations(tokens, paren_pairs, classes, functions)
        functions.extend(declarations)
        globals_ = self._parse_variables(tokens, classes, functions)

        self._attach_functions_to_classes(functions, classes)
        self._attach_variables(tokens, classes, functions, globals_)

        return ParseResult(classes=classes, functions=functions, globals=globals_)

    def _parse_classes(self, tokens: Sequence[Token], brace_pairs: dict[int, int]) -> list[ClassInfo]:
        classes: list[ClassInfo] = []
        for i, token in enumerate(tokens):
            if token.value not in {"class", "struct"}:
                continue
            name_token = self._next_identifier(tokens, i + 1)
            if name_token is None:
                continue
            name_index, name = name_token
            open_index = self._next_value(tokens, name_index + 1, "{", stop_values={";"})
            if open_index is None or open_index not in brace_pairs:
                continue
            close_index = brace_pairs[open_index]
            classes.append(
                ClassInfo(
                    name=name.value,
                    kind=token.value,
                    start_line=token.line,
                    end_line=tokens[close_index].line,
                    body_start_token=open_index,
                    body_end_token=close_index,
                )
            )
        return classes

    def _parse_functions(
        self,
        tokens: Sequence[Token],
        brace_pairs: dict[int, int],
        paren_pairs: dict[int, int],
        classes: list[ClassInfo],
    ) -> list[FunctionInfo]:
        functions: list[FunctionInfo] = []

        for open_brace, close_brace in sorted(
            ((a, b) for a, b in brace_pairs.items() if a < b), key=lambda pair: pair[0]
        ):
            if open_brace == 0:
                continue
            close_paren = self._definition_parameter_close(
                tokens, open_brace, paren_pairs
            )
            if close_paren is None:
                continue
            open_paren = paren_pairs.get(close_paren)
            if open_paren is None:
                continue

            name_index = self._function_name_index(tokens, open_paren)
            if name_index is None:
                continue
            name_token = tokens[name_index]
            if name_token.value in _CONTROL_NAMES:
                continue

            # Reject lambda captures and obvious expression blocks.
            if name_token.value in {"operator"}:
                continue

            signature_start = self._signature_start(tokens, name_index)
            return_tokens = list(tokens[signature_start:name_index])
            qualified_name = self._qualified_function_name(tokens, name_index)
            owner_class = self._owner_class_for_token(open_brace, classes)
            simple_name = name_token.value

            is_destructor = name_index > 0 and tokens[name_index - 1].value == "~"
            if is_destructor:
                simple_name = "~" + simple_name

            qualified_owner = None
            if "::" in qualified_name:
                qualified_owner = qualified_name.split("::")[-2]
                if owner_class is None and any(cls.name == qualified_owner for cls in classes):
                    owner_class = qualified_owner

            class_name_for_ctor = owner_class or qualified_owner

            constructor = class_name_for_ctor is not None and simple_name == class_name_for_ctor
            destructor = class_name_for_ctor is not None and simple_name == f"~{class_name_for_ctor}"

            if constructor or destructor:
                return_type = ""
            else:
                return_type = tokens_to_compact_text(return_tokens).strip()
                if not return_type:
                    # Most ordinary function definitions have a return type. Empty here is likely a false parse.
                    continue

            parameters = self._parse_parameters(tokens[open_paren + 1:close_paren])

            functions.append(
                FunctionInfo(
                    name=simple_name,
                    qualified_name=qualified_name,
                    return_type=return_type,
                    parameters=parameters,
                    start_line=tokens[signature_start].line,
                    end_line=tokens[close_brace].line,
                    body_start_token=open_brace,
                    body_end_token=close_brace,
                    signature_start_token=signature_start,
                    signature_end_token=close_paren,
                    owner_class=owner_class,
                    is_constructor=constructor,
                    is_destructor=destructor,
                )
            )

        return self._remove_nested_false_functions(functions)

    def _parse_function_declarations(
        self,
        tokens: Sequence[Token],
        paren_pairs: dict[int, int],
        classes: list[ClassInfo],
        definitions: list[FunctionInfo],
    ) -> list[FunctionInfo]:
        """Parse conservative function/method prototypes outside function bodies."""
        declarations: list[FunctionInfo] = []
        definition_bodies = [
            (fn.body_start_token, fn.body_end_token)
            for fn in definitions
            if fn.is_definition and fn.body_start_token >= 0
        ]

        statement_start = 0
        for semi_index, token in enumerate(tokens):
            if token.value != ";":
                continue
            if any(start < semi_index < end for start, end in definition_bodies):
                continue

            segment_start = statement_start
            # Start after the nearest structural boundary if one is present.
            for j in range(semi_index - 1, statement_start - 1, -1):
                if tokens[j].value in {";", "{", "}"}:
                    segment_start = j + 1
                    break
            segment = list(tokens[segment_start:semi_index])
            if not segment:
                statement_start = semi_index + 1
                continue

            # Ignore preprocessor/comment tokens for structural matching.
            significant = [
                (segment_start + k, t)
                for k, t in enumerate(segment)
                if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}
            ]
            if not significant:
                statement_start = semi_index + 1
                continue

            open_parens = [idx for idx, t in significant if t.value == "("]
            if not open_parens:
                statement_start = semi_index + 1
                continue
            open_paren = open_parens[-1]
            close_paren = paren_pairs.get(open_paren)
            if close_paren is None or close_paren >= semi_index:
                statement_start = semi_index + 1
                continue

            name_index = self._function_name_index(tokens, open_paren)
            if name_index is None or name_index < segment_start:
                statement_start = semi_index + 1
                continue
            name_token = tokens[name_index]
            if name_token.value in _CONTROL_NAMES:
                statement_start = semi_index + 1
                continue

            owner_class = self._owner_class_for_token(semi_index, classes)
            qualified_name = self._qualified_function_name(tokens, name_index)
            simple_name = name_token.value
            if name_index > 0 and tokens[name_index - 1].value == "~":
                simple_name = "~" + simple_name

            if owner_class and "::" not in qualified_name:
                qualified_name = f"{owner_class}::{simple_name}"

            qualified_owner = None
            if "::" in qualified_name:
                qualified_owner = qualified_name.split("::")[-2]
            class_name_for_ctor = owner_class or qualified_owner
            constructor = class_name_for_ctor is not None and simple_name == class_name_for_ctor
            destructor = class_name_for_ctor is not None and simple_name == f"~{class_name_for_ctor}"

            signature_start = segment_start
            while signature_start < name_index and tokens[signature_start].kind in {
                TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR
            }:
                signature_start += 1

            return_tokens = list(tokens[signature_start:name_index])
            if owner_class and return_tokens:
                # Access specifiers can precede the first declaration in a class chunk.
                while return_tokens and return_tokens[0].value in {"public", "private", "protected", ":"}:
                    return_tokens.pop(0)

            if constructor or destructor:
                return_type = ""
            else:
                return_type = tokens_to_compact_text(return_tokens).strip()
                if not return_type:
                    statement_start = semi_index + 1
                    continue

            parameters = self._parse_parameters(tokens[open_paren + 1:close_paren])
            start_line = tokens[signature_start].line if signature_start < len(tokens) else name_token.line
            declarations.append(
                FunctionInfo(
                    name=simple_name,
                    qualified_name=qualified_name,
                    return_type=return_type,
                    parameters=parameters,
                    start_line=start_line,
                    end_line=token.line,
                    body_start_token=-1,
                    body_end_token=-1,
                    signature_start_token=signature_start,
                    signature_end_token=close_paren,
                    owner_class=owner_class,
                    is_constructor=constructor,
                    is_destructor=destructor,
                    is_definition=False,
                )
            )
            statement_start = semi_index + 1

        return declarations

    def _remove_nested_false_functions(self, functions: list[FunctionInfo]) -> list[FunctionInfo]:
        # Lambdas and local classes can look like nested definitions. Keep explicit methods/functions,
        # but discard identical-span duplicates caused by conservative parsing.
        seen: set[tuple[int, int, str]] = set()
        out: list[FunctionInfo] = []
        for fn in functions:
            key = (fn.body_start_token, fn.body_end_token, fn.qualified_name)
            if key not in seen:
                seen.add(key)
                out.append(fn)
        return out

    def _attach_functions_to_classes(self, functions: list[FunctionInfo], classes: list[ClassInfo]) -> None:
        for fn in functions:
            if fn.owner_class:
                for cls in classes:
                    if cls.name == fn.owner_class:
                        cls.methods.append(fn)
                        break

    def _attach_variables(
        self,
        tokens: Sequence[Token],
        classes: list[ClassInfo],
        functions: list[FunctionInfo],
        globals_: list[VariableInfo],
    ) -> None:
        for fn in functions:
            if fn.is_definition and fn.body_start_token >= 0:
                body = tokens[fn.body_start_token + 1:fn.body_end_token]
                fn.local_variables.extend(
                    self._declarations_from_region(
                        body,
                        category="local",
                        owner_function=fn.qualified_name,
                        owner_class=fn.owner_class,
                    )
                )
                fn.local_variables.extend(
                    self._for_loop_variables(
                        body,
                        owner_function=fn.qualified_name,
                        owner_class=fn.owner_class,
                    )
                )
            for parameter in fn.parameters:
                if parameter.name:
                    fn.local_variables.append(
                        VariableInfo(
                            name=parameter.name,
                            type_text=parameter.type_text,
                            category="parameter",
                            line=parameter.line,
                            column=parameter.column,
                            pointer_depth=parameter.type_text.count("*"),
                            reference="&" in parameter.type_text,
                            owner_function=fn.qualified_name,
                            owner_class=fn.owner_class,
                        )
                    )

        for cls in classes:
            body_tokens = tokens[cls.body_start_token + 1:cls.body_end_token]
            method_ranges = [
                (fn.body_start_token, fn.body_end_token)
                for fn in functions
                if fn.owner_class == cls.name and fn.is_definition and fn.body_start_token >= 0
            ]
            class_start = cls.body_start_token + 1
            filtered: list[Token] = []
            for local_index, tok in enumerate(body_tokens):
                absolute_index = class_start + local_index
                if any(start <= absolute_index <= end for start, end in method_ranges):
                    continue
                filtered.append(tok)
            cls.fields.extend(
                self._declarations_from_region(
                    filtered,
                    category="field",
                    owner_class=cls.name,
                )
            )

    def _for_loop_variables(
        self,
        tokens: Sequence[Token],
        *,
        owner_function: str,
        owner_class: str | None,
    ) -> list[VariableInfo]:
        out: list[VariableInfo] = []
        i = 0
        while i < len(tokens):
            if tokens[i].value != "for":
                i += 1
                continue
            open_index = i + 1
            while open_index < len(tokens) and tokens[open_index].kind in {
                TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR
            }:
                open_index += 1
            if open_index >= len(tokens) or tokens[open_index].value != "(":
                i += 1
                continue

            depth = 0
            close_index = None
            first_separator = None
            separator_value = None
            j = open_index
            while j < len(tokens):
                v = tokens[j].value
                if v == "(":
                    depth += 1
                elif v == ")":
                    depth -= 1
                    if depth == 0:
                        close_index = j
                        break
                elif depth == 1 and first_separator is None and v in {";", ":"}:
                    first_separator = j
                    separator_value = v
                j += 1

            if close_index is None or first_separator is None:
                i += 1
                continue

            init = list(tokens[open_index + 1:first_separator])
            if separator_value in {";", ":"}:
                parsed = self._parse_declaration_statement(
                    init,
                    category="local",
                    owner_function=owner_function,
                    owner_class=owner_class,
                )
                out.extend(parsed)
            i = close_index + 1

        # De-duplicate declarations already found by the generic pass.
        unique: dict[tuple[str, int, int], VariableInfo] = {}
        for var in out:
            unique[(var.name, var.line, var.column)] = var
        return list(unique.values())

    def _parse_variables(
        self,
        tokens: Sequence[Token],
        classes: list[ClassInfo],
        functions: list[FunctionInfo],
    ) -> list[VariableInfo]:
        excluded_ranges: list[tuple[int, int]] = []
        excluded_ranges.extend((cls.body_start_token, cls.body_end_token) for cls in classes)
        excluded_ranges.extend(
            (fn.body_start_token, fn.body_end_token)
            for fn in functions
            if fn.is_definition and fn.body_start_token >= 0
        )

        filtered: list[Token] = []
        for i, token in enumerate(tokens):
            if any(start <= i <= end for start, end in excluded_ranges):
                continue
            filtered.append(token)
        return self._declarations_from_region(filtered, category="global")

    def _declarations_from_region(
        self,
        tokens: Sequence[Token],
        *,
        category: str,
        owner_function: str | None = None,
        owner_class: str | None = None,
    ) -> list[VariableInfo]:
        variables: list[VariableInfo] = []
        statement: list[Token] = []
        depth_round = depth_square = depth_curly = 0

        for token in tokens:
            v = token.value
            if v == "(":
                depth_round += 1
            elif v == ")" and depth_round:
                depth_round -= 1
            elif v == "[":
                depth_square += 1
            elif v == "]" and depth_square:
                depth_square -= 1
            elif v == "{":
                depth_curly += 1
            elif v == "}" and depth_curly:
                depth_curly -= 1

            statement.append(token)
            if v == ";" and depth_round == depth_square == 0:
                variables.extend(
                    self._parse_declaration_statement(
                        statement[:-1],
                        category=category,
                        owner_function=owner_function,
                        owner_class=owner_class,
                    )
                )
                statement = []

        return variables

    def _parse_declaration_statement(
        self,
        tokens: Sequence[Token],
        *,
        category: str,
        owner_function: str | None,
        owner_class: str | None,
    ) -> list[VariableInfo]:
        tokens = [t for t in tokens if t.kind not in {TokenKind.COMMENT_LINE, TokenKind.COMMENT_BLOCK, TokenKind.PREPROCESSOR}]
        tokens = self._trim_block_prefix(tokens)
        while tokens and tokens[0].value in {"public", "private", "protected", ":"}:
            tokens = tokens[1:]
        if not tokens:
            return []
        if tokens[0].value in _DECLARATION_SKIP_PREFIXES:
            return []

        # Function calls/prototypes are too ambiguous for a conservative declaration pass.
        if any(t.value == "(" for t in tokens):
            # Allow direct-list/value initialization only when an '=' appears before '('.
            first_paren = next(i for i, t in enumerate(tokens) if t.value == "(")
            first_eq = next((i for i, t in enumerate(tokens) if t.value == "="), None)
            if first_eq is None or first_paren < first_eq:
                return []

        groups = split_top_level(tokens, ",")
        if not groups:
            return []

        first_name_index = self._candidate_decl_name_index(groups[0])
        if first_name_index is None:
            return []

        type_tokens = list(groups[0][:first_name_index])
        if not type_tokens:
            return []

        # Reject common expression statements such as obj.field = value;
        if any(t.value in {".", "->"} for t in type_tokens):
            return []
        if type_tokens[0].value in _CONTROL_NAMES:
            return []

        type_text = tokens_to_compact_text(type_tokens).strip()
        if not type_text:
            return []

        variables: list[VariableInfo] = []
        for group_index, group in enumerate(groups):
            name_index = first_name_index if group_index == 0 else self._candidate_decl_name_index(group)
            if name_index is None or name_index >= len(group):
                continue
            name_tok = group[name_index]
            if name_tok.kind != TokenKind.IDENTIFIER:
                continue

            prefix = group[:name_index]
            effective_type_tokens = type_tokens if group_index else prefix
            combined_type = tokens_to_compact_text(effective_type_tokens).strip() or type_text
            all_type_tokens = list(type_tokens) + list(prefix if group_index else [])
            values = [t.value for t in all_type_tokens]
            pointer_depth = sum(1 for t in prefix if t.value == "*")
            if group_index == 0:
                pointer_depth = sum(1 for t in type_tokens if t.value == "*")
            reference = any(t.value in {"&", "&&"} for t in prefix)
            if group_index == 0:
                reference = any(t.value in {"&", "&&"} for t in type_tokens)

            after_name = group[name_index + 1:]
            variables.append(
                VariableInfo(
                    name=name_tok.value,
                    type_text=combined_type,
                    category=category,
                    line=name_tok.line,
                    column=name_tok.column,
                    const="const" in values,
                    constexpr="constexpr" in values,
                    static="static" in values,
                    pointer_depth=pointer_depth,
                    reference=reference,
                    array=any(t.value == "[" for t in after_name),
                    owner_function=owner_function,
                    owner_class=owner_class,
                    confidence="medium",
                )
            )

        return variables

    def _trim_block_prefix(self, tokens: Sequence[Token]) -> list[Token]:
        tokens = list(tokens)
        if not tokens:
            return []

        # A semicolon-delimited chunk can begin with control syntax from an enclosing
        # block, e.g. `if (x) { int value = 1;`. Keep only the declaration tail.
        control_prefixes = {"if", "else", "for", "while", "switch", "catch", "do", "try"}
        if tokens[0].value in control_prefixes:
            last_open = max((i for i, t in enumerate(tokens) if t.value == "{"), default=-1)
            if last_open >= 0:
                tokens = tokens[last_open + 1:]

        while tokens and tokens[0].value in {"{", "}"}:
            tokens = tokens[1:]
        return tokens

    def _candidate_decl_name_index(self, tokens: Sequence[Token]) -> int | None:
        if not tokens:
            return None
        stop = next((i for i, t in enumerate(tokens) if t.value in {"=", "{"}), len(tokens))
        left = tokens[:stop]
        for i in range(len(left) - 1, -1, -1):
            token = left[i]
            if token.kind != TokenKind.IDENTIFIER:
                continue
            if token.value in _TYPE_QUALIFIERS:
                continue
            # Namespace/type component followed by :: is not the variable name.
            if i + 1 < len(left) and left[i + 1].value == "::":
                continue
            return i
        return None

    def _parse_parameters(self, tokens: Sequence[Token]) -> list[ParameterInfo]:
        result: list[ParameterInfo] = []
        groups = split_top_level(tokens, ",")
        if len(groups) == 1 and groups[0] and tokens_to_compact_text(groups[0]).strip() == "void":
            return []

        for group in groups:
            group = [t for t in group if t.value != "..."]
            if not group:
                continue
            eq = next((i for i, t in enumerate(group) if t.value == "="), len(group))
            core = group[:eq]
            candidate = self._candidate_decl_name_index(core)
            if candidate is None:
                result.append(
                    ParameterInfo(
                        name=None,
                        type_text=tokens_to_compact_text(core).strip(),
                        line=core[0].line if core else 0,
                        column=core[0].column if core else 0,
                    )
                )
                continue
            name_tok = core[candidate]
            type_tokens = core[:candidate] + core[candidate + 1:]
            result.append(
                ParameterInfo(
                    name=name_tok.value,
                    type_text=tokens_to_compact_text(type_tokens).strip(),
                    line=name_tok.line,
                    column=name_tok.column,
                )
            )
        return result

    def _definition_parameter_close(
        self,
        tokens: Sequence[Token],
        open_brace: int,
        paren_pairs: dict[int, int],
    ) -> int | None:
        """Find the function parameter ')' immediately preceding a definition.

        Constructor initializer lists can end in another call-like ')' right before
        the body (`A::A() : p(new T) {}`). In that case the function parameter
        list is the last matched ')' before the top-level initializer-list colon.
        """
        boundary = 0
        for i in range(open_brace - 1, -1, -1):
            if tokens[i].value in {";", "{", "}"}:
                boundary = i + 1
                break

        depth_round = depth_square = 0
        initializer_colon = None
        i = boundary
        while i < open_brace:
            v = tokens[i].value
            if v == "(":
                depth_round += 1
            elif v == ")" and depth_round:
                depth_round -= 1
            elif v == "[":
                depth_square += 1
            elif v == "]" and depth_square:
                depth_square -= 1
            elif v == ":" and depth_round == depth_square == 0:
                initializer_colon = i
                break
            i += 1

        search_end = initializer_colon if initializer_colon is not None else open_brace
        for i in range(search_end - 1, boundary - 1, -1):
            if tokens[i].value != ")":
                continue
            open_index = paren_pairs.get(i)
            if open_index is None or open_index < boundary:
                continue
            name_index = self._function_name_index(tokens, open_index)
            if name_index is None or tokens[name_index].value in _CONTROL_NAMES:
                continue
            return i
        return None

    def _function_name_index(self, tokens: Sequence[Token], open_paren: int) -> int | None:
        i = self._previous_non_ignorable_index(tokens, open_paren - 1)
        if i is None:
            return None

        # foo(...), Class::foo(...), ~Class(...)
        if tokens[i].kind == TokenKind.IDENTIFIER:
            return i
        return None

    def _qualified_function_name(self, tokens: Sequence[Token], name_index: int) -> str:
        parts = [tokens[name_index].value]
        i = name_index - 1
        if i >= 0 and tokens[i].value == "~":
            parts[0] = "~" + parts[0]
            i -= 1
        while i >= 1 and tokens[i].value == "::" and tokens[i - 1].kind == TokenKind.IDENTIFIER:
            parts.insert(0, "::")
            parts.insert(0, tokens[i - 1].value)
            i -= 2
        return "".join(parts)

    def _signature_start(self, tokens: Sequence[Token], name_index: int) -> int:
        i = name_index - 1
        while i >= 0:
            if tokens[i].value in {";", "{", "}"}:
                return i + 1
            i -= 1
        return 0

    def _owner_class_for_token(self, token_index: int, classes: Sequence[ClassInfo]) -> str | None:
        candidates = [
            cls for cls in classes
            if cls.body_start_token < token_index < cls.body_end_token
        ]
        if not candidates:
            return None
        smallest = min(candidates, key=lambda c: c.body_end_token - c.body_start_token)
        return smallest.name

    @staticmethod
    def _next_identifier(tokens: Sequence[Token], start: int) -> tuple[int, Token] | None:
        for i in range(start, len(tokens)):
            if tokens[i].kind == TokenKind.IDENTIFIER:
                return i, tokens[i]
            if tokens[i].value in {";", "{"}:
                return None
        return None

    @staticmethod
    def _next_value(
        tokens: Sequence[Token],
        start: int,
        value: str,
        *,
        stop_values: set[str] | None = None,
    ) -> int | None:
        stop_values = stop_values or set()
        for i in range(start, len(tokens)):
            if tokens[i].value == value:
                return i
            if tokens[i].value in stop_values:
                return None
        return None

    @staticmethod
    def _previous_non_ignorable_index(tokens: Sequence[Token], start: int) -> int | None:
        for i in range(start, -1, -1):
            if tokens[i].kind not in {
                TokenKind.COMMENT_LINE,
                TokenKind.COMMENT_BLOCK,
                TokenKind.PREPROCESSOR,
            }:
                return i
        return None
