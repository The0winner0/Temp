from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any


DEFAULT_CONFIG: dict[str, Any] = {
    "project": {
        "extensions": [".c", ".cc", ".cpp", ".cxx", ".h", ".hh", ".hpp", ".hxx"],
        "exclude": ["build/**", ".git/**", "__pycache__/**"],
        "follow_symlinks": False,
        "encoding": "utf-8",
    },
    "reporting": {
        "minimum_severity": "info",
        "minimum_confidence": "low",
        "show_summary": True,
        "json_output": None,
    },
    "checks": {},
}


def _deep_merge(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
    out = deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(out.get(key), dict):
            out[key] = _deep_merge(out[key], value)
        else:
            out[key] = value
    return out


def load_config(path: str | Path | None) -> dict[str, Any]:
    if path is None:
        return deepcopy(DEFAULT_CONFIG)

    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    with config_path.open("r", encoding="utf-8") as handle:
        user_config = json.load(handle)

    if not isinstance(user_config, dict):
        raise ValueError("Top-level config must be a JSON object.")

    return _deep_merge(DEFAULT_CONFIG, user_config)
