from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Iterable


class Severity(IntEnum):
    INFO = 10
    STYLE = 20
    WARNING = 30
    ERROR = 40

    @classmethod
    def parse(cls, value: str | int | "Severity") -> "Severity":
        if isinstance(value, Severity):
            return value
        if isinstance(value, int):
            return Severity(value)
        normalized = value.strip().upper()
        try:
            return Severity[normalized]
        except KeyError as exc:
            raise ValueError(f"Unknown severity: {value!r}") from exc


class Confidence(IntEnum):
    LOW = 10
    MEDIUM = 20
    HIGH = 30
    CERTAIN = 40

    @classmethod
    def parse(cls, value: str | int | "Confidence") -> "Confidence":
        if isinstance(value, Confidence):
            return value
        if isinstance(value, int):
            return Confidence(value)
        normalized = value.strip().upper()
        try:
            return Confidence[normalized]
        except KeyError as exc:
            raise ValueError(f"Unknown confidence: {value!r}") from exc


@dataclass(frozen=True, slots=True)
class SourceLocation:
    file: str
    line: int
    column: int = 1


@dataclass(slots=True)
class Finding:
    checker: str
    rule: str
    severity: Severity
    confidence: Confidence
    location: SourceLocation
    message: str
    details: str = ""
    suggestion: str = ""
    evidence: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "checker": self.checker,
            "rule": self.rule,
            "severity": self.severity.name.lower(),
            "confidence": self.confidence.name.lower(),
            "file": self.location.file,
            "line": self.location.line,
            "column": self.location.column,
            "message": self.message,
            "details": self.details,
            "suggestion": self.suggestion,
            "evidence": list(self.evidence),
            "tags": list(self.tags),
            "metadata": dict(self.metadata),
        }


def filter_findings(
    findings: Iterable[Finding],
    *,
    minimum_severity: Severity = Severity.INFO,
    minimum_confidence: Confidence = Confidence.LOW,
) -> list[Finding]:
    return [
        finding
        for finding in findings
        if finding.severity >= minimum_severity
        and finding.confidence >= minimum_confidence
    ]
