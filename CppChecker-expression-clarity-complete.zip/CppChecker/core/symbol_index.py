from __future__ import annotations

from .source_context import ProjectContext, SymbolIndex


def build_symbol_index(project: ProjectContext) -> SymbolIndex:
    index = SymbolIndex()
    for source in project.files:
        for cls in source.classes:
            index.add_class(cls)
            for field in cls.fields:
                index.add_variable(field)
        for function in source.functions:
            index.add_function(function)
            for variable in function.local_variables:
                index.add_variable(variable)
        for variable in source.global_variables:
            index.add_variable(variable)
    return index
