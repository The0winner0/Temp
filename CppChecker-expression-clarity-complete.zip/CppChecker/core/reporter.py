from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Iterable

from .diagnostics import Finding


def print_console(findings: Iterable[Finding], *, show_summary: bool = True) -> None:
    findings = list(findings)
    for finding in findings:
        loc = finding.location
        print(
            f"[{finding.severity.name}/{finding.confidence.name}] "
            f"{finding.rule} {loc.file}:{loc.line}:{loc.column}"
        )
        print(f"  {finding.message}")
        if finding.details:
            for line in finding.details.splitlines():
                print(f"  {line}")
        if finding.evidence:
            print("  Evidence:")
            for item in finding.evidence:
                print(f"    - {item}")
        if finding.suggestion:
            print(f"  Suggestion: {finding.suggestion}")
        print()

    if show_summary:
        counts = Counter(f.severity.name for f in findings)
        print(
            "Summary: "
            + ", ".join(f"{name.lower()}={counts.get(name, 0)}" for name in ("ERROR", "WARNING", "STYLE", "INFO"))
            + f", total={len(findings)}"
        )


def write_json(findings: Iterable[Finding], output_path: str | Path) -> None:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = [finding.to_dict() for finding in findings]
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
