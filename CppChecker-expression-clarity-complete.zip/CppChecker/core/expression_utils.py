from __future__ import annotations

from collections.abc import Iterable, Sequence

from .tokenizer import Token, TokenKind


IGNORABLE_KINDS = {
    TokenKind.COMMENT_LINE,
    TokenKind.COMMENT_BLOCK,
    TokenKind.PREPROCESSOR,
}


def significant_tokens(tokens: Iterable[Token]) -> list[Token]:
    return [token for token in tokens if token.kind not in IGNORABLE_KINDS]


def matching_pairs(tokens: Sequence[Token], opener: str, closer: str) -> dict[int, int]:
    stack: list[int] = []
    pairs: dict[int, int] = {}
    for index, token in enumerate(tokens):
        if token.value == opener:
            stack.append(index)
        elif token.value == closer and stack:
            start = stack.pop()
            pairs[start] = index
            pairs[index] = start
    return pairs


def split_top_level(tokens: Sequence[Token], delimiter: str = ",") -> list[list[Token]]:
    if not tokens:
        return []

    parts: list[list[Token]] = []
    current: list[Token] = []
    depth_round = depth_square = depth_curly = depth_angle = 0

    for token in tokens:
        v = token.value
        if v == "(":
            depth_round += 1
        elif v == ")" and depth_round:
            depth_round -= 1
        elif v == "[":
            depth_square += 1
        elif v == "]" and depth_square:
            depth_square -= 1
        elif v == "{":
            depth_curly += 1
        elif v == "}" and depth_curly:
            depth_curly -= 1
        elif v == "<":
            depth_angle += 1
        elif v == ">" and depth_angle:
            depth_angle -= 1
        elif v == ">>" and depth_angle:
            depth_angle = max(0, depth_angle - 2)

        if (
            v == delimiter
            and depth_round == depth_square == depth_curly == depth_angle == 0
        ):
            parts.append(current)
            current = []
        else:
            current.append(token)

    parts.append(current)
    return parts


def tokens_to_compact_text(tokens: Sequence[Token]) -> str:
    if not tokens:
        return ""
    pieces: list[str] = []
    previous: Token | None = None
    no_space_before = {",", ";", ")", "]", "}", "::", ".", "->"}
    no_space_after = {"(", "[", "{", "::", ".", "->"}
    for token in tokens:
        if previous is not None:
            if token.value not in no_space_before and previous.value not in no_space_after:
                pieces.append(" ")
        pieces.append(token.value)
        previous = token
    return "".join(pieces)


def last_identifier(tokens: Sequence[Token]) -> Token | None:
    for token in reversed(tokens):
        if token.kind == TokenKind.IDENTIFIER:
            return token
    return None
