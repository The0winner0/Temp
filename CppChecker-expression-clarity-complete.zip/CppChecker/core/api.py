from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Mapping

from .diagnostics import Finding


@dataclass(frozen=True, slots=True)
class CheckerMetadata:
    name: str
    description: str
    version: str = "1.0"


class Checker(ABC):
    """Stable API implemented by every modular checker."""

    metadata: CheckerMetadata

    @abstractmethod
    def run(self, context: "ProjectContext", config: Mapping[str, Any]) -> list[Finding]:
        raise NotImplementedError


# Imported only for static type checking to avoid a runtime cycle.
try:
    from typing import TYPE_CHECKING
    if TYPE_CHECKING:
        from .source_context import ProjectContext
except ImportError:
    pass
