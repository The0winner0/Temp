from __future__ import annotations

from typing import Any, Mapping

from .diagnostics import Finding
from .registry import LoadedChecker
from .source_context import ProjectContext


def run_checkers(
    context: ProjectContext,
    checkers: list[LoadedChecker],
) -> tuple[list[Finding], list[str]]:
    findings: list[Finding] = []
    errors: list[str] = []

    for loaded in checkers:
        try:
            produced = loaded.checker.run(context, loaded.config)
            findings.extend(produced)
        except Exception as exc:
            # A broken optional checker must not prevent every other checker from running.
            errors.append(f"Checker '{loaded.name}' failed: {type(exc).__name__}: {exc}")

    findings.sort(
        key=lambda f: (
            f.location.file.lower(),
            f.location.line,
            f.location.column,
            -int(f.severity),
            f.rule,
        )
    )
    return findings, errors
