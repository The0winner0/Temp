from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto


class TokenKind(Enum):
    IDENTIFIER = auto()
    NUMBER = auto()
    STRING = auto()
    CHAR = auto()
    RAW_STRING = auto()
    COMMENT_LINE = auto()
    COMMENT_BLOCK = auto()
    PREPROCESSOR = auto()
    OPERATOR = auto()
    PUNCTUATION = auto()


@dataclass(frozen=True, slots=True)
class Token:
    kind: TokenKind
    value: str
    line: int
    column: int
    offset: int
    end_offset: int


_MULTI_OPERATORS = (
    "<=>", "<<=", ">>=", "->*", "...",
    "::", "->", "++", "--", "&&", "||", "==", "!=", "<=", ">=",
    "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<", ">>",
    ".*", "##",
)

_PUNCTUATION = set("{}()[];,?:")
_SINGLE_OPERATORS = set("+-*/%&|^~!=<>.#")


class CppTokenizer:
    def tokenize(self, source: str) -> list[Token]:
        tokens: list[Token] = []
        i = 0
        line = 1
        column = 1
        line_has_nonspace = False
        n = len(source)

        def advance_char(ch: str) -> None:
            nonlocal line, column, line_has_nonspace
            if ch == "\n":
                line += 1
                column = 1
                line_has_nonspace = False
            else:
                column += 1
                if ch not in " \t\r":
                    line_has_nonspace = True

        def consume_to(end: int) -> None:
            nonlocal i
            while i < end:
                ch = source[i]
                advance_char(ch)
                i += 1

        while i < n:
            ch = source[i]

            if ch.isspace():
                advance_char(ch)
                i += 1
                continue

            start = i
            start_line = line
            start_col = column

            # Preprocessor directive at first non-whitespace position on a line.
            if ch == "#" and not line_has_nonspace:
                end = i
                while end < n:
                    nl = source.find("\n", end)
                    if nl == -1:
                        end = n
                        break
                    # Continue on backslash-escaped newline.
                    back = nl - 1
                    while back >= start and source[back] == "\r":
                        back -= 1
                    if back >= start and source[back] == "\\":
                        end = nl + 1
                        continue
                    end = nl
                    break
                value = source[start:end]
                tokens.append(Token(TokenKind.PREPROCESSOR, value, start_line, start_col, start, end))
                consume_to(end)
                continue

            if source.startswith("//", i):
                end = source.find("\n", i + 2)
                if end == -1:
                    end = n
                value = source[start:end]
                tokens.append(Token(TokenKind.COMMENT_LINE, value, start_line, start_col, start, end))
                consume_to(end)
                continue

            if source.startswith("/*", i):
                close = source.find("*/", i + 2)
                end = n if close == -1 else close + 2
                value = source[start:end]
                tokens.append(Token(TokenKind.COMMENT_BLOCK, value, start_line, start_col, start, end))
                consume_to(end)
                continue

            # C++ raw string literals, including encoding prefixes:
            # R"(...)" / u8R"(...)" / uR"(...)" / UR"(...)" / LR"(...)".
            raw_prefix = None
            for candidate in ("u8R\"", "uR\"", "UR\"", "LR\"", "R\""):
                if source.startswith(candidate, i):
                    raw_prefix = candidate
                    break
            if raw_prefix is not None:
                delim_start = i + len(raw_prefix)
                delim_end = source.find("(", delim_start, min(n, delim_start + 18))
                if delim_end != -1:
                    delimiter = source[delim_start:delim_end]
                    terminator = ")" + delimiter + '"'
                    close = source.find(terminator, delim_end + 1)
                    end = n if close == -1 else close + len(terminator)
                    value = source[start:end]
                    tokens.append(Token(TokenKind.RAW_STRING, value, start_line, start_col, start, end))
                    consume_to(end)
                    continue

            # Normal/prefixed strings and character literals. Prefix handling is conservative.
            prefix_len = 0
            quote = None
            for prefix in ("u8", "u", "U", "L", ""):
                pos = i + len(prefix)
                if source.startswith(prefix, i) and pos < n and source[pos] in ('"', "'"):
                    prefix_len = len(prefix)
                    quote = source[pos]
                    break
            if quote is not None:
                end = i + prefix_len + 1
                escaped = False
                while end < n:
                    c = source[end]
                    if escaped:
                        escaped = False
                    elif c == "\\":
                        escaped = True
                    elif c == quote:
                        end += 1
                        break
                    end += 1
                kind = TokenKind.STRING if quote == '"' else TokenKind.CHAR
                value = source[start:end]
                tokens.append(Token(kind, value, start_line, start_col, start, end))
                consume_to(end)
                continue

            if ch.isalpha() or ch == "_":
                end = i + 1
                while end < n and (source[end].isalnum() or source[end] == "_"):
                    end += 1
                value = source[start:end]
                tokens.append(Token(TokenKind.IDENTIFIER, value, start_line, start_col, start, end))
                consume_to(end)
                continue

            if ch.isdigit() or (ch == "." and i + 1 < n and source[i + 1].isdigit()):
                end = i + 1
                while end < n and (source[end].isalnum() or source[end] in "._'"):
                    end += 1
                value = source[start:end]
                tokens.append(Token(TokenKind.NUMBER, value, start_line, start_col, start, end))
                consume_to(end)
                continue

            matched = None
            for op in _MULTI_OPERATORS:
                if source.startswith(op, i):
                    matched = op
                    break
            if matched:
                end = i + len(matched)
                tokens.append(Token(TokenKind.OPERATOR, matched, start_line, start_col, start, end))
                consume_to(end)
                continue

            if ch in _PUNCTUATION:
                end = i + 1
                tokens.append(Token(TokenKind.PUNCTUATION, ch, start_line, start_col, start, end))
                consume_to(end)
                continue

            if ch in _SINGLE_OPERATORS:
                end = i + 1
                tokens.append(Token(TokenKind.OPERATOR, ch, start_line, start_col, start, end))
                consume_to(end)
                continue

            # Unknown single character: retain it as punctuation rather than losing position info.
            end = i + 1
            tokens.append(Token(TokenKind.PUNCTUATION, ch, start_line, start_col, start, end))
            consume_to(end)

        return tokens
