# Semantic Safety — Patch 3

Apply this after Semantic Safety Patch 2.

## Added checks

- `SEM006` — unparenthesized bitwise/comparison precedence trap, e.g. `flags & MASK == 0`.
- `SEM207` — zero-step `for` loop.
- `SEM208` — loop update moves away from a known bound.
- `SEM300` — constant arithmetic overflows/wraps its evaluation type before destination conversion.
- `SEM301` — Patch 1 pre-widening arithmetic check now also covers subtraction.
- `SEM304` — left shift evaluated in a narrower type before widening.
- `SEM311` — straight-line variable is known to be zero when used as divisor/modulus.
- `SEM320` — compound assignment can narrow/change signedness or discard floating data.
- `SEM321` — definite overflow/wrap from a known constant `++`, `--`, or compound update.

## Conservative behavior

- explicit casts still represent deliberate conversion intent;
- unknown types are skipped;
- constant state is discarded at control-flow boundaries, nested scopes and opaque function calls;
- generic compound warnings are suppressed when a stronger definite `SEM321` finding exists on the same line.
