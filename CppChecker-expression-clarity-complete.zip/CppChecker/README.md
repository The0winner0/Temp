# CppChecker backbone

Pure-Python, offline, modular C/C++ source-checking framework. It uses only the Python standard library.

## Design constraints

- No network access or runtime downloads.
- No compiler, Clang, GCC, external process, or pip dependency.
- Analysis is confined to the selected root directory and its descendants.
- `.c/.cc/.cpp/.cxx/.h/.hh/.hpp/.hxx` files are discovered recursively.
- `main.py` is checker-agnostic and should remain unchanged when new checks are added.
- Each checker is a package under `checks/<name>/` and exposes `create_checker()`.
- All checkers consume the same `ProjectContext` and return `Finding` objects.
- The structural parser is intentionally conservative; it is a source-analysis aid, not a full C++ compiler frontend.

## Run

You can either copy the checker contents directly into the C/C++ root and run:

```bash
python main.py .
```

or keep the checker in a subfolder of the C/C++ root and launch it from the C/C++ root:

```bash
python CppChecker/main.py .
```

The second form still keeps source discovery confined to the directory from which the command was launched. If `checker_config.json` is not present at the analysis root, the bundled config beside `main.py` is used when it is still inside that boundary.

List discovered checker packages:

```bash
python main.py . --list-checkers
```

Run only selected configured checkers:

```bash
python main.py . --only naming_usage,memory,language
```

Temporarily disable selected configured checkers:

```bash
python main.py . --disable comments
```

## Adding a checker

1. Copy `checks/_template` to `checks/<name>`.
2. Implement `checker.py`, `analyzer.py`, and optionally `rules.py`.
3. Add configuration:

```json
"checks": {
  "memory": {
    "enabled": true
  }
}
```

No `main.py` change is required.

## Common checker API

Every checker implements:

```python
class MyChecker(Checker):
    def run(self, context, config) -> list[Finding]:
        ...
```

Every checker package exposes:

```python
def create_checker() -> Checker:
    return MyChecker()
```

## ProjectContext

Main shared data:

```text
ProjectContext
├── root
├── files[]
│   ├── source
│   ├── lines
│   ├── tokens
│   ├── comments
│   ├── functions
│   ├── classes
│   └── global_variables
├── functions
├── classes
├── comments
└── symbols
```

Functions expose their parameters and conservatively detected local variables. Classes expose methods and conservatively detected fields.

## Parser philosophy

The parser extracts only structures useful to later checkers. Ambiguous syntax should be skipped rather than guessed. Individual checker modules should apply their own confidence policy on top of this representation.

## Implemented checker modules

`checks/memory/` analyzes project-specific local/class memory ownership, allocation/release pairing, indexed allocation families, early-return paths, custom allocation APIs, and release mismatches. See `checks/memory/README.md`.

`checks/naming_usage/` provides per-symbol-category regex naming rules plus conservative declared-but-unused and used-but-not-declared variable analysis. It recognizes fixed-width C integer types, discovered custom types/aliases, direct initialization, structured bindings, common function-pointer declarations, and opaque dependency calls. See `checks/naming_usage/README.md`.

`checks/language/` spell-checks comments and string literals using only local newline-delimited `.txt` dictionaries. Every `.txt` anywhere below that checker directory is automatically loaded, and code identifiers are excluded from spelling diagnostics. It also includes a deliberately small high-confidence grammar pass for common mistakes such as comparative `then/than`, repeated words, modal `... of`, selected homophones, agreement, and basic tense forms. See `checks/language/README.md`.

Additional independent packages can be added without changing `main.py`, for example:

```text
checks/pointer_safety/
checks/c_memory/
checks/comments/
checks/function_quality/
```

## Validation

Run the included standard-library tests from the checker directory:

```bash
python -m unittest discover -s tests -v
```

## Root boundary

The CLI treats the process working directory as the hard filesystem boundary. The requested analysis root, config file, discovered C/C++ files, and JSON report output must remain at or below that directory. Parent-directory traversal and resolved symlink escapes are rejected.

### Semantic safety

The optional `semantic_safety` checker detects high-confidence legal-C/C++ mistakes such as narrowing conversions, signed/unsigned hazards, impossible range comparisons, integer division before floating conversion, arithmetic overflow before widening, invalid shifts, condition/operator mistakes, loop progression errors, compound-assignment conversion hazards, constant-expression overflow, and conservative straight-line constant-state errors. Platform integer widths and custom scalar aliases can be configured in `checker_config.json`.


## Expression clarity checker

`checks/expression_clarity/` enforces explicit grouping for mixed-precedence expressions. It is intended to catch legal-but-easy-to-misread code such as `var1 ^ var2 | 1 == 1`, `a * b + c / d`, or `a < b && c < d`. Same-precedence chains such as `a + b + c + d` remain valid. See `PATCH_EXPRESSION_CLARITY_1.md` and `checks/expression_clarity/README.md`.
