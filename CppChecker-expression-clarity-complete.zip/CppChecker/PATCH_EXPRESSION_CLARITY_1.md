# Expression Clarity Checker — Patch 1

Adds the independent `expression_clarity` checker.

## Goal

Require explicit parentheses when an expression mixes C/C++ operator precedence levels, so the intended evaluation order is readable without relying on memorized precedence rules.

This checker is intentionally stricter than the compiler. Legal expressions can still be reported when their grouping is visually ambiguous.

## Default analysis scope

Enabled contexts:

- `if (...)`
- `while (...)`
- the condition segment of `for (init; condition; update)`

Available but disabled by default:

- `switch (...)`
- return expressions
- assignment right-hand sides

## Examples

No finding:

```cpp
if (a + b + c + d) { }
if (a * b / c * d) { }
if (a && b && c) { }
if (((var1 ^ var2) | 1) == 1) { }
if ((a * b) + (c / d)) { }
if ((a < b) && (c < d)) { }
```

Finding:

```cpp
if (var1 ^ var2 | 1 == 1) { }
if (a * b + c / d) { }
if (a < b && c < d) { }
if (a && b || c) { }
if (flags & MASK == 0) { }
if (x << n + 1) { }
```

The checker does not infer the intended rewrite. It reports the operator groups and asks the developer to add explicit grouping.

## Rules

- `EXPR101`: generic mixed precedence
- `EXPR102`: bitwise mixed with comparison/logical or different bitwise precedence levels
- `EXPR103`: ternary mixed with another precedence level
- `EXPR104`: comparison mixed with logical operators
- `EXPR105`: arithmetic/shift precedence mix

## Implementation notes

The checker operates on tokenizer output only and has no compiler dependency. It recursively analyzes explicit `()` and `[]` groups. Top-level function arguments are treated as independent expressions, avoiding false relationships between operators in separate arguments.

Template/cast angle brackets are conservatively masked when strong template/cast syntax is present so constructs such as `foo<int>(a, b)` are not treated as comparisons.
